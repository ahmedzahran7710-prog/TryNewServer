# فحص الثغرات وتحصين سيرفر Rappelz 9.1 المحلي
**تاريخ:** 2026-11-10 · **الحالة:** سيرفر محلي (Loopback) — الهدف حاليًا: تأمينه قبل أي فتح للشبكة أو للعامة.

---

## 0) الخلاصة في 5 سطور

1. سيرفرك **حاليًا محلي فقط** واللاعب يدخل على `127.0.0.1` — يعني مافيش ثغرة "عن بُعد" مفتوحة للإنترنت **إلا** لو الجهاز متصل بشبكة والجدار الناري سايب البورتات.
2. أخطر نقطة عندك: **SQL Server على 1433** + حساب `rappelz` (وحساب `sa` موجود) — لازم يتقفل على الشبكة.
3. البورتات `1996 / 4502 / 4514 / 4616 / 4617 / 5000` كلها بتسمع على `0.0.0.0` ⇒ أي جهاز على نفس الواي فاي يقدر يلمسها.
4. البورت `5000` هو **سيرفر ويب** (أيقونات النقابات) = أكبر سطح هجوم عندك.
5. التحصين الصحيح مش "برنامج أنتي فيرس" — هو **3 حاجات**: جدار ناري على البورتات + حسابات SQL قوية ومحدودة الصلاحية + إغلاق أي منفذ مش محتاجه.

---

## 1) خريطة المنافذ الحالية ودرجة الخطر

| المنفذ | الخدمة | يسمع على | الخطر | ملاحظة |
|---|---|---|---|---|
| 1433 | SQL Server | 0.0.0.0 (غالبًا) | 🔴 عالي جدًا | أخطر منفذ في المنظومة |
| 5000 | rzauth icon/upload web | 0.0.0.0 | 🔴 عالي | سيرفر HTTP بدون TLS |
| 1996 | rzauth — دخول اللاعبين | 0.0.0.0 | 🟠 متوسط | بروتوكول خاص؛ كراش/إغراق ممكن |
| 4502 | rzauth ↔ GameServer | 0.0.0.0 | 🟠 متوسط | لازم يكون محلي فقط |
| 4514 | GameServer acceptor | 0.0.0.0 | 🟠 متوسط | دخول اللاعب للعالم |
| 4616 / 4617 | UploadServer | 0.0.0.0 | 🟢 منخفض | مش لازم يسمع للخارج |
| 4501 | rzauth admin console (telnet) | 127.0.0.1 | 🟢 جيد | سايبه كده ✅ |
| 65528 | GameServer console | 127.0.0.1 + باسورد | 🟢 جيد | سايبه كده ✅ |

**القاعدة:** كل بورت مش محتاجينه من بره ⇒ `127.0.0.1`. البورتات الأربعة اللي بيفضلوا `0.0.0.0` هي بتاعة اللاعبين، ودي تتقفل بالجدار الناري.

---

## 2) التحصين الفوري (نفّذ بالترتيب)

### الخطوة 1 — اقفل كل البورتات على الجدار الناري (أهم خطوة)
افتح **CMD كمسؤول** والصق كـ **سطر واحد**:

```cmd
netsh advfirewall firewall add rule name="RZ-LOCK" dir=in action=block protocol=TCP localport=1433,1996,4501,4502,4514,4616,4617,5000,65528
```

هذا يمنع أي اتصال من بره — **ولا يمنع** اللاعب المحلي (127.0.0.1) من اللعب، لأن الـ loopback ما بيمرّش على الجدار الناري أصلًا.

**تحقق:**
```cmd
netsh advfirewall firewall show rule name="RZ-LOCK"
```
لازم تشوف `Enabled: Yes` و`Direction: In` و`Action: Block`.

### الخطوة 2 — خلي خدمات السيرفر تسمع محلي فقط
في `auth.opt` بدّل الأسطر دي (لو مش موجودة ضيفها):

```
auth.clients.ip:127.0.0.1
auth.gameserver.ip:127.0.0.1
upload.clients.ip:127.0.0.1
upload.iconserver.ip:127.0.0.1
```

> ⚠️ لو ناوي تلعب من جهاز تاني على نفس الشبكة، سيب `auth.clients.ip` و`upload.clients.ip` = `0.0.0.0` بس، وخلي `auth.gameserver.ip` و`upload.iconserver.ip` = `127.0.0.1`.

**تحقق:** بعد إعادة تشغيل `rzauth.exe`:
```cmd
netstat -ano | findstr ":4502 :5000 :1996"
```
لازم تشوف `127.0.0.1:` بدل `0.0.0.0:` في 4502 و5000.

### الخطوة 3 — حسابات SQL
الوضع الحالي: `rzauth` داخل بـ `rappelz` وباسورد **فاضي** — وقاعدة البيانات فيها `AUTH` و`TELECASTER1` و`ARCADIAINFO`. لو الجهاز ده على شبكة، ده باب مفتوح.

**أ) اتأكد من حالة الحسابات:**
```sql
SELECT name, type_desc, is_disabled, create_date, modify_date
FROM sys.server_principals
WHERE type IN ('S','U','G') AND name NOT LIKE '##%' ORDER BY is_disabled, name;

-- مين sysadmin؟
SELECT p.name FROM sys.server_role_members m
JOIN sys.server_principals r ON r.principal_id = m.role_principal_id
JOIN sys.server_principals p ON p.principal_id = m.member_principal_id
WHERE r.name = 'sysadmin';

-- إعدادات خطيرة لازم تكون 0
SELECT name, value_in_use FROM sys.configurations
WHERE name IN ('xp_cmdshell','Ole Automation Procedures','clr enabled','remote admin connections','Ad Hoc Distributed Queries');
```

**ب) أنشئ حساب مخصص لـ rzauth بدل `rappelz`** (باسورد قوي بدّل `Str0ng!Pass#2026`):

```sql
USE master;
CREATE LOGIN rz_app WITH PASSWORD = 'Str0ng!Pass#2026', CHECK_POLICY = ON;
GO
USE Auth;
CREATE USER rz_app FOR LOGIN rz_app;
ALTER ROLE db_datareader ADD MEMBER rz_app;
ALTER ROLE db_datawriter ADD MEMBER rz_app;
GRANT EXECUTE TO rz_app;
GO
```
ثم في `auth.opt`:
```
auth.db.account:rz_app
auth.db.password:Str0ng!Pass#2026
```

> ⚠️ **حاسب:** الـ GameServer كمان بيدخل SQL، وفي `GameServer.opt` الحساب `db.user.account`/`db.c.account`. لو غيرت واحد لازم تظبط التاني، وإلا السيرفر مش هيقوم. نفّذ التغيير ده في جلسة لوحدها واختبر الدخول قبل أي حاجة تانية.

**ج) تعطيل `sa` بعد ما تتأكد إن مافيش حاجة بتستخدمه:**
```sql
ALTER LOGIN sa DISABLE;
```
لو أي حاجة وقعت بعدها ⇒ `ALTER LOGIN sa ENABLE;` وارجع لحساب `rappelz` مؤقتًا.

### الخطوة 4 — نسخ احتياطي قبل أي تجربة
```cmd
sqlcmd -S . -E -b -Q "BACKUP DATABASE Auth TO DISK='F:\AhmedZahran\rz-backup\Auth.bak' WITH INIT, COMPRESSION" -b
```
كررها على `Telecaster1` و`ArcadiaInfo` و`Billing` — أو شغّل `backup-rz.cmd` مرة واحدة وبيعمل الأربعة. الثغرات الحقيقية مش في الكود — في "جربت أعمل تعديل ومعرفتش أرجع".

---

## 3) فحص الثغرات: إزاي تتأكد بنفسك (اختبارات عملية)

### أ) اختبار من بره (أهم اختبار)
من **جهاز تاني** على نفس الشبكة، افتح PowerShell:

```powershell
Test-NetConnection 192.168.1.X -Port 1996    # لازم False بعد التحصين
Test-NetConnection 192.168.1.X -Port 1433    # لازم False
Test-NetConnection 192.168.1.X -Port 5000    # لازم False
```
(بدّل `192.168.1.X` بـ IP جهاز السيرفر من `ipconfig`.)

لو أي واحد طلع `True` ⇒ الجدار الناري مش شغال على البورت ده.

### ب) اختبار من الداخل
```cmd
netstat -ano | findstr LISTENING
```
راجع كل بورت `0.0.0.0` — أي واحد مش في الجدول فوق؟ اسأل نفسه: محتاجه؟

وتأكد مين ماسك كل بورت:
```cmd
netstat -ano | findstr ":1996 :4502 :4514 :4616 :4617 :5000"
tasklist | findstr /I "rzauth CaptainHerlock LogServer sqlservr"
```

### ج) مراجعة الحسابات المشبوهة
```sql
SELECT account_id, login_name, block, auth_ok, age, last_login_server_idx
FROM Auth.dbo.Accounts
WHERE login_name NOT IN ('test2')   -- ضيف حساباتك الشرعية
ORDER BY account_id;
```
أي حساب مش عارفه ⇒ `block = 1` فورًا.

### د) مراجعة السجلات (هنا بتظهر محاولات الاستغلال)
- `Game_bin\Log\*.log` — أخطاء DB وأوامر غريبة.
- `Auth_bin\` — لوج rzauth (بيطبع كل محاولة دخول + سبب الرفض).
- **`rzauth` traffic dump:** لو شغّلته (`trafficdump` في `auth.opt`) بيطلع ملفات باكيتات — سيبها **مقفولة** في التشغيل العادي (بتاكل مساحة وقد تحتوي بيانات دخول).
- ابحث في اللوج عن: `Login failed`, `Invalid`, `overflow`, `Unknown packet`, `disconnect`.

### هـ) فحص التحديثات/الملفات
- كل ملفات السيرفر من مصدر واحد موثوق (الباك الرسمي). أي `.exe`/`.dll` جاي من منتدى = احتمال باب خلفي.
- خُد بصمة الملفات مرة واحدة واحفظها، وأي تغيير مفاجئ = إنذار:
```cmd
certutil -hashfile CaptainHerlockServer.exe MD5
certutil -hashfile rzauth.exe MD5
```

---

## 4) ثغرات وبجات معروفة في سيرفرات Rappelz الخاصة (راقبها)

| النوع | الوصف | الوقاية |
|---|---|---|
| **باكيتات Auth مصنوعة** | كانت بتكرّش `PrincessAuroraServer.exe` (إنت عانيت منها) | `rzauth` أحدث وأصرم — ما ترجعش للرسمي |
| **IMBC Autologin** | `rzauth` بيدعم دخول بدون باسورد عبر توكن الكلاينت | للأمان: اقفله (`auth.clients.enableimbc:false`) قبل أي فتح للعامة |
| **SQL Injection في الأسماء** | أسماء الشخصيات/النقابات بتتحفظ عبر procs؛ بعض الـ procs القديمة بتجمّع استعلامات نصية | ما تسمحش بأسماء فيها `'` أو `--`؛ راجع `smp_*` اللي بتاخد نص |
| **التكرار (Dupe)** | أشهر بج في سيرفرات خاصة: نقل/تخزين/مزاد بيعمل نسخة من الأيتم عند قطع الاتصال | اختبر: خد أيتم → حطه في التخزين → اقطع النت في نص العملية → راجع `Telecaster1.dbo.Item` |
| **GM Command Abuse** | لو حد عرف حساب GM، أو لو `console._password` اتسرّب | GM منفصل، باسورد مختلف، ومراجعة لوج الأوامر |
| **إغراق الدخول (Flood)** | آلاف اتصالات على 1996 | `auth.clients` limits + جدار ناري + fail2ban لو لينكس |
| **ملفات كلاينت معدّلة** | `sframe`/`data.001` معدّلة = جي إم/سبيد هاك | `game.ignore_client_binary:0` + تحقق من `game.version` |

---

## 5) ترتيب التنفيذ المقترح (لا تعملهم كلهم مرة واحدة)

1. **الخطوة 1 (الجدار الناري)** — 30 ثانية، بدون أي تأثير على اللعب. ✅ ابدأ بيها.
2. **الخطوة 2 (`127.0.0.1` في `auth.opt`)** — اختبار دخول بعدها.
3. **نسخة احتياطية** للقواعد.
4. **حساب SQL مخصص** — جلسة لوحدها + اختبار دخول.
5. تعطيل `sa`.
6. اختبار المنافذ من جهاز تاني.
7. مراجعة اللوجات والحسابات (أسبوعيًا).

---

## 6) حالة "الملف ده اتعمل ليه"
كل التحصين الموصوف هنا قابل للتنفيذ على تركيبك الحالي بدون إعادة تثبيت وبدون لمس `PrincessAuroraServer.exe` أو `UploadServer.exe` (اللي هما أصلًا خارج الترتيب). لو أي خطوة كسرت الدخول، الرجوع بسطر واحد (`ALTER LOGIN sa ENABLE` أو حذف قاعدة الجدار الناري):

```cmd
netsh advfirewall firewall delete rule name="RZ-LOCK"
```
