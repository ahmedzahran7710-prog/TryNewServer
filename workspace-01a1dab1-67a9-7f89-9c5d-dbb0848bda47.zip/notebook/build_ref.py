# -*- coding: utf-8 -*-
import json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

NAVY="1F3550"; GOLD="C8952A"; GREY="F7F9FB"; LIGHT="EEF3F8"; TECH="2A6FA8"
thin=Side(style="thin",color="C9D4E0"); border=Border(left=thin,right=thin,top=thin,bottom=thin)
H_FONT=Font(name="Segoe UI",bold=True,color="FFFFFF",size=11)
B_FONT=Font(name="Segoe UI",size=10.5,color="1B2430")

wb=Workbook()

def head(ws, cols, widths, title, note=None):
    ws.cell(row=1,column=1,value=title).font=Font(name="Segoe UI",bold=True,size=15,color="1B2430")
    ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=len(cols))
    ws.cell(row=1,column=1).fill=PatternFill("solid",fgColor=LIGHT)
    ws.cell(row=1,column=1).alignment=Alignment(horizontal="right",vertical="center")
    ws.row_dimensions[1].height=32
    r=2
    if note:
        ws.cell(row=2,column=1,value=note).font=Font(name="Segoe UI",size=10,italic=True,color="44546A")
        ws.merge_cells(start_row=2,start_column=1,end_row=2,end_column=len(cols))
        ws.cell(row=2,column=1).alignment=Alignment(horizontal="right",vertical="center",wrap_text=True)
        ws.row_dimensions[2].height=30
        r=4
    for i,c in enumerate(cols,1):
        cell=ws.cell(row=r,column=i,value=c)
        cell.font=H_FONT; cell.fill=PatternFill("solid",fgColor=NAVY); cell.border=border
        cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
    ws.row_dimensions[r].height=26
    ws.freeze_panes=ws.cell(row=r+1,column=1)
    ws.sheet_view.rightToLeft=True
    return r

def body(ws,start,rows,zebra=True):
    for j,row in enumerate(rows):
        rr=start+1+j
        for i,v in enumerate(row,1):
            c=ws.cell(row=rr,column=i,value=v)
            c.font=B_FONT; c.border=border
            c.alignment=Alignment(horizontal="right",vertical="center",wrap_text=True)
            if zebra and j%2==1: c.fill=PatternFill("solid",fgColor=GREY)
        ws.row_dimensions[rr].height=19

# ---------------- 1
ws=wb.active; ws.title="ابدأ من هنا"; ws.sheet_view.rightToLeft=True
for col,w in (("A",3),("B",28),("C",100)): ws.column_dimensions[col].width=w
ws["B2"]="المرجع الحقيقي — سيرفر أمل الشعوب 9.1"
ws["B2"].font=Font(name="Segoe UI",bold=True,size=18,color="FFFFFF")
ws["B2"].fill=PatternFill("solid",fgColor=NAVY); ws.merge_cells("B2:C2")
ws["B2"].alignment=Alignment(horizontal="right",vertical="center"); ws.row_dimensions[2].height=40
rows=[
 ("إيه ده؟","شيتات فيها القيم والأسماء الحقيقية اللي طلعت من فحص ملفات السيرفر نفسها — مش أمثلة ولا تخمين."),
 ("إيه الحقيقي هنا؟","أسماء الصفات (str/vit/dex/agi/int/men/luk) · أسماء ١٠٤ عمود في جدول الأدوات · ٦٢ جدول موارد · ٤٢ سكربت Lua بأسمائها ودوالها · ٢٧٧١ اسم أيقونة حقيقية في ٧٣ عائلة · ٣٨٣٩ صف أرقام من جدول StatResource · القيم الافتراضية للبورتات والنسب."),
 ("إيه اللي مش موجود؟","★ الأسماء العربية/الإنجليزية للأدوات نفسها (زي «خاتم القوة») — دي محفوظة في الكلاينت مش في السيرفر. السيرفر بيحفظ رقم (name_id) بس. شوف شيت «إزاي تلاقي الاسم»."),
 ("طريقة الاستخدام","١) تدوّر على اللي إنت عايزه في شيت «الفهرس» ٢) تروح للشيت ٣) تنسخ القيمة ٤) تحطها في الدفتر بتاعك (ملف rappelz-modding-notebook.xlsx)."),
 ("مصدر البيانات","ملفات الحزمة الرسمية 9.1: ItemResource.rdu · StatResource.rdu · CaptainHerlockServer.exe · مجلد Resource\\Script · ملفات .opt"),
 ("تاريخ الفحص","١٠ نوفمبر ٢٠٢٥"),
]
r=4
for k,v in rows:
    a=ws.cell(row=r,column=2,value=k); a.font=Font(bold=True,size=11,color="FFFFFF"); a.fill=PatternFill("solid",fgColor=GOLD)
    a.alignment=Alignment(horizontal="right",vertical="center"); a.border=border
    b=ws.cell(row=r,column=3,value=v); b.font=B_FONT; b.border=border
    b.alignment=Alignment(horizontal="right",vertical="center",wrap_text=True)
    ws.row_dimensions[r].height=32 if len(v)<150 else 60
    r+=1

# ---------------- 2 الصفات الأساسية
ws=wb.create_sheet("الصفات الأساسية")
hr=head(ws,["الكود في الملفات","الاسم الإنجليزي","المعنى بالعربي","إيه اللي بيعمله في اللعبة","ملاحظة"],
        [18,18,20,52,40],"الصفات الأساسية الحقيقية (من رأس جدول StatResource)",
        "الأسماء دي مأخوذة حرفياً من أعمدة جدول الأرقام في السيرفر — مش ترجمة ولا تخمين.")
body(ws,hr,[
 ("id","id","رقم الصف","معرّف مجموعة الأرقام","كل صف في StatResource = باكدج قيم"),
 ("str","STR","القوة","تزيد الضرر البدني وسعة الحمل",""),
 ("vit","VIT","الحيوية","تزيد الصحة (HP) والدفاع","★ الحجر اللي إنت عايزه"),
 ("dex","DEX","البراعة","تزيد دقة الإصابة ومعدل الضربات الحرجة",""),
 ("agi","AGI","الرشاقة","تزيد سرعة الحركة والتهرّب",""),
 ("int","INT","الذكاء","يحدد قوة السحر (MP وقوة المهارات السحرية)",""),
 ("men","MEN","الحكمة / الإدراك","مقاومة السحر والمانا",""),
 ("luk","LUK","الحظ","يأثر على الحرج وبعض الاحتمالات",""),
],)

# ---------------- 3 عائلات الأيقونات
fam=json.load(open("icon_families.json"))
ws=wb.create_sheet("عائلات الأيقونات الحقيقية")
hr=head(ws,["العائلة","عدد الأيقونات","أمثلة أسماء حقيقية (تقدر تحطها في icon_file_name)","النوع المتوقع"],
        [22,14,74,26],"٢٧٧١ اسم أيقونة حقيقي — مجمّعة في ٧٣ عائلة",
        "دي أسماء ملفات فعلية لقيتها جوّه ItemResource.rdu. تقدر تستخدم أي واحدة منهم زي ما هي.")
kind={"ring":"خواتم","earing":"أقراط","necklace":"قلادات","belt":"أحزمة","boots":"أحذية","clothe":"دروع نسيج",
 "body":"دروع","helm":"خوذ","glove":"قفازات","shield":"دروع يد","gem":"أحجار كريمة","stone":"أحجار",
 "effectstone":"أحجار عناصر","1handswd":"سيوف يد","2handswd":"سيوف يدين","dagger":"خناجر","bow":"أقواس",
 "1handstaff":"عصي","2handstaff":"عصي يدين","1handmace":"مطارق","2handmace":"مطارق يدين","axe":"فؤوس",
 "event":"أدوات فعاليات","quest":"أدوات مهام","creature":"مرافقين","card":"كروت مهارات","etc":"متنوعات",
 "cash":"متجر كاش","arena":"أرينا","deco":"ديكور","cube":"مكعبات","donation":"تبرعات","combine":"دمج"}
rows=[]
for k,v in sorted(fam.items(), key=lambda x:-len(x[1])):
    ex=" · ".join(sorted(set(v))[:4])
    rows.append((k,len(v),ex,kind.get(k,"")))
body(ws,hr,rows)

# ---------------- 4 أعمدة ItemResource
cols=['id','name_id','tooltip_id','type','group','class','wear_type','set_id','set_part_flag','grade','rank','level',
'enhance','socket','status_flag','limit_deva','limit_asura','limit_gaia','job_depth','limit_fighter','limit_hunter',
'limit_magician','limit_summoner','use_min_level','use_max_level','target_min_level','target_max_level','range','weight',
'price','huntaholic_point','arena_point','ethereal_durability','endurance','material','summon_id','item_use_flag',
'available_period','decrease_type','throw_range']
for i in range(4): cols += [f'base_type_{i}',f'base_var1_{i}',f'base_var2_{i}']
for i in range(4): cols += [f'opt_type_{i}',f'opt_var1_{i}',f'opt_var2_{i}']
cols += ['effect_id','enhance_id','skill_id','state_id','state_level','state_time','cool_time','cool_time_group',
'model_type_dem','model_type_def','model_type_asm','model_type_asf','model_type_gam','model_type_gaf',
'deco_model_change']+[f'model_{i:02d}' for i in range(18)]+['texture_filename','drop_type','icon_id','icon_file_name',
'script_text','group_bit_set','drop_etc_pouch']
meaning={
'id':'رقم الأداة (فريد)','name_id':'★ رقم الاسم في الكلاينت','tooltip_id':'رقم الوصف في الكلاينت',
'type':'نوع الأداة','group':'تصنيف فرعي','class':'فئة الأداة','wear_type':'مكان اللبس','set_id':'مجموعة الطقم',
'set_part_flag':'جزء الطقم','grade':'الفئة/الجودة','rank':'الرتبة','level':'لفل الأداة','enhance':'درجة التطوير الحالية',
'socket':'★ عدد خانات الأحجار','status_flag':'أعلام حالة','limit_deva':'مسموح للجنس 1','limit_asura':'مسموح للجنس 2',
'limit_gaia':'مسموح للجنس 3','job_depth':'عمق التخصص','limit_fighter':'مسموح للمقاتل','limit_hunter':'مسموح للصياد',
'limit_magician':'مسموح للساحر','limit_summoner':'مسموح للمروّض','use_min_level':'★ أقل لفل للاستخدام',
'use_max_level':'أقصى لفل','target_min_level':'أقل لفل للهدف','target_max_level':'أقصى لفل للهدف','range':'المدى',
'weight':'الوزن','price':'السعر','huntaholic_point':'نقاط هنتهوليك','arena_point':'نقاط الأرينا',
'ethereal_durability':'متانة أثيرية','endurance':'التحمّل','material':'المادة','summon_id':'رقم المرافق',
'item_use_flag':'طريقة الاستخدام','available_period':'مدة الصلاحية','decrease_type':'طريقة النقصان',
'throw_range':'مدى الرمي','effect_id':'تأثير بصري','enhance_id':'★ قواعد التطوير (EnhanceResource)',
'skill_id':'مهارة يديها','state_id':'حالة (بف)','state_level':'مستوى الحالة','state_time':'مدة الحالة',
'cool_time':'وقت التهدئة','cool_time_group':'مجموعة التهدئة','deco_model_change':'تغيير ديكور',
'texture_filename':'ملف التكتشر (كلاينت)','drop_type':'نوع السقوط','icon_id':'★ رقم الأيقونة',
'icon_file_name':'★ اسم ملف الأيقونة','script_text':'نص داخلي','group_bit_set':'تصنيف بيتي','drop_etc_pouch':'شنطة الدروب'}
for i in range(4):
    meaning[f'base_type_{i}']=f'★ كود الخاصية الأساسية #{i+1}'
    meaning[f'base_var1_{i}']=f'★ قيمة الخاصية #{i+1}'
    meaning[f'base_var2_{i}']=f'قيمة مساندة للخاصية #{i+1}'
    meaning[f'opt_type_{i}']=f'★ كود الأوبشن #{i+1}'
    meaning[f'opt_var1_{i}']=f'★ قيمة الأوبشن #{i+1}'
    meaning[f'opt_var2_{i}']=f'قيمة مساندة للأوبشن #{i+1}'
for i in range(18): meaning[f'model_{i:02d}']=f'ملف موديل رقم {i}'
for g,ar in (('dem','جنس 1'),('def','جنس 2'),('asm','جنس 3'),('asf','جنس 4'),('gam','جنس 5'),('gaf','جنس 6')):
    meaning[f'model_type_{g}']=f'موديل {ar}'
ws=wb.create_sheet("أعمدة جدول الأدوات")
hr=head(ws,["رقم","اسم العمود","المعنى","ملاحظة"],
        [7,26,44,44],f"أعمدة جدول ItemResource — {len(cols)} عمود (أسماء حقيقية من الملف)",
        "اللي جنبه ★ = الأعمدة اللي هتستخدمها في ٩٠٪ من شغلك.")
rows=[(i+1,c,meaning.get(c,""),"") for i,c in enumerate(cols)]
body(ws,hr,rows)

# ---------------- 5 جداول الموارد
tbl="""AutoAuctionResource|AwakenProbabilitiesResource|AwakenResource|BanWordResource|BattleArenaBeginAreaResource|BattleArenaFieldPropResource|BattleArenaMonsterRespawnResource|BattleArenaResource|ChannelResource|ChannelUserLimitResource|CreatureFarmResource|DeathmatchResource|DecomposeResource|DropGroupLocalResource|DropGroupResource|DungeonResource|EnhanceResource|EventAreaResource|FieldPropResource|FieldPropSwitchingResource|HuntaholicHealingPropResource|HuntaholicInstanceResource|HuntaholicMonsterRespawnResource|HuntaholicResource|InstanceDungeonHealingPropResource|InstanceDungeonMonsterRespawnResource|InstanceDungeonResource|InstanceDungeonTypeResource|ItemConversionResource|ItemLocalResource|ItemResource|JobResource|LevelResource|LoadResource|LockResource|MarketResource|MixResource|MonsterCreatureResource|MonsterResource|NPCEventPeriodResource|NPCResource|PetResource|QuestLinkResource|QuestResource|RandomItemOptionResource|RandomItemPresetResource|RandomPoolResource|SetItemEffectResource|SkillJPResource|SkillResource|SkillTreeResource|StatResource|StateResource|StringLocalResource|StringResource|SummonDefaultNameResource|SummonLevelResource|SummonRandomSkillResource|SummonResource""".split("|")
d2={"ItemResource":"كل الأدوات ومواصفاتها","DropGroupResource":"جداول الدروب (١٠ خانات لكل مجموعة)",
"DropGroupLocalResource":"دروب خاصة بمنطقة","MarketResource":"الشوبات والأسعار","MixResource":"الدمج/الترقية",
"EnhanceResource":"درجات التطوير +X","StatResource":"جداول الأرقام (الصفات)","SummonResource":"المرافقين",
"RandomItemOptionResource":"الخصائص العشوائية","RandomItemPresetResource":"قوالب الخصائص العشوائية",
"RandomPoolResource":"مجموعات العشوائية","AwakenResource":"نظام الإفاقة/التنشيط","AwakenProbabilitiesResource":"نِسَب الإفاقة",
"NPCResource":"تعريفات الـ NPC","MonsterResource":"تعريفات الوحوش","SkillResource":"المهارات","SkillTreeResource":"شجرة المهارات",
"StringResource":"النصوص","StringLocalResource":"نصوص محلية","QuestResource":"المهام","QuestLinkResource":"ربط المهام",
"DungeonResource":"الدنجن","InstanceDungeonResource":"دنجن إنستانس","LevelResource":"اللفلات والخبرة","JobResource":"التخصصات",
"PetResource":"المرافقين (بيتس)","LockResource":"القفل/الختم","DecomposeResource":"التفكيك","ItemConversionResource":"تحويل الأدوات",
"SetItemEffectResource":"تأثيرات الأطقم","ChannelResource":"القنوات","BanWordResource":"كلمات محظورة","StateResource":"الحالات/البفات"}
ws=wb.create_sheet("جداول الموارد الحقيقية")
hr=head(ws,["اسم الجدول","بيتحكم في إيه","نوعه","مكانه"],
        [34,46,16,38],"٦٢ جدول موارد — دي الجداول اللي السيرفر بيقراها فعلاً",
        "أسماء حقيقية مستخرجة من داخل CaptainHerlockServer.exe. أغلبها بيتعمل لها استيراد من ملفات RDU بـ DBUpdater.")
rows=[]
for t in tbl:
    kind="موارد (RDU)" if t in ("ItemResource","DropGroupResource","DropGroupLocalResource","MarketResource","MixResource","SummonResource","StatResource","TitleConditionTypeResource","NPCEventPeriodResource") else "قاعدة البيانات"
    rows.append((t,d2.get(t,""),kind,"قاعدة Arcadia (بعد الاستيراد)" if kind.startswith("موارد") else "قاعدة Arcadia"))
body(ws,hr,rows)

# ---------------- 6 سكربتات Lua
lua=json.load(open("lua_index.json"))
descr={"BattleArena.lua":"ساحة المعارك","ETC_Script_Functions.lua":"دوال مساعدة عامة",
"ETC_dungeon_prop.lua":"أدوات/خصائص الدنجن","ETC_huntaholicprop.lua":"خصائص هنتهوليك",
"ETC_run_monster_skill.lua":"تشغيل مهارات الوحوش","NPC_Adventure_Guide.lua":"NPC دليل المغامرات",
"NPC_Auction.lua":"NPC المزاد","NPC_Buff.lua":"NPC البفات","NPC_ChipExchange.lua":"تبديل الشرائح",
"NPC_CreateGuild.lua":"إنشاء جيلد","NPC_CreatureEnchanter.lua":"تحسين المرافقين","NPC_CreatureSetup.lua":"إعداد المرافق",
"NPC_Creature_farm.lua":"مزرعة المرافقين","NPC_DarkMarket.lua":"السوق السوداء","NPC_Dungeon.lua":"NPC الدنجن",
"NPC_Event.lua":"NPC الفعاليات","NPC_FoodShop.lua":"بائع أكل","NPC_GuideTown.lua":"دليل المدن",
"NPC_ItemUP.lua":"★ الحداد: تطوير/تغيير الأدوات + الراندوم أوبشن","NPC_Jewelry.lua":"بائع المجوهرات",
"NPC_JobChange.lua":"تغيير التخصص","NPC_MerchantEquip.lua":"بائع عتاد","NPC_MerchantEtc.lua":"بائع متنوعات",
"NPC_MerchantWeapon.lua":"بائع أسلحة","NPC_QuestClient.lua":"عميل المهام","NPC_REVO_MAIN.lua":"سكربت رئيسي",
"NPC_Storage.lua":"المخزن","NPC_TeleportField.lua":"تيليورت ميداني","NPC_TeleportTown.lua":"تيليورت مدن",
"NPC_Tutorial.lua":"التعليمات","NPC_hell.lua":"منطقة الجحيم","NPC_huntaholic.lua":"هنتهوليك",
"monster_respawn.lua":"★ سباون الوحوش (كثافة/نادر/بوس)","random_respawn.lua":"★ سباون عشوائي (مناطق + وحوش + نسب)",
"monster_roaming.lua":"تجوال الوحوش","on_first_login.lua":"أول دخول","on_first_summon.lua":"أول استدعاء",
"on_login.lua":"كل دخول","on_player_dead.lua":"عند الموت","on_player_level_up.lua":"★ عند رفع اللفل",
"server_init.lua":"★ عند تشغيل السيرفر"}
ws=wb.create_sheet("سكربتات Lua الحقيقية")
hr=head(ws,["الملف","اسم الموديول","وظيفته","عدد الأسطر","عدد الدوال","أمثلة أسماء دوال حقيقية","أرقام مستخدمة جوّاه (أمثلة)"],
        [26,26,34,12,12,50,34],"٤٢ سكربت Lua حقيقي — ودي «أنظمة» السيرفر",
        "مكانها: C:\\RZ\\Server\\GameEngine\\Game_bin\\Resource\\Script — وكل ملف ليه نسخة .ela مشفّرة.")
rows=[(o['file'],o['module'],descr.get(o['file'],''),o['lines'],o['funcs']," · ".join(o['sample_funcs'][1:4])," · ".join(str(c) for c in o['codes'][:4])) for o in lua]
body(ws,hr,rows)

# ---------------- 7 أرقام حقيقية مهمة
ws=wb.create_sheet("أرقام حقيقية مهمة")
hr=head(ws,["الرقم","نوعه","معناه / سياقه","مصدره (فين لقيته)"],
        [18,26,54,44],"أرقام حقيقية لقيتها في ملفات السيرفر (تقدر تستخدمها فوراً)")
rows=[
 ("601100300 → 601100307","أرقام أدوات","أدوات «قابلة للتغيير» في سكربت الحداد (بتتحوّل لنسخ 601100354 → 601100361)","NPC_ItemUP.lua"),
 ("700000585 → 700000822","أرقام أدوات","أداة تانية في نفس السكربت بتتحوّل لرقم مختلف","NPC_ItemUP.lua"),
 ("96 + 512 / 96 + 1024","أكواد راندوم أوبشن","أكواد شفتها جوّه set_item_random_option — بتستخدم لقيم مضاعفة","NPC_ItemUP.lua"),
 ("@90010002","رقم نص","نص «إغلاق» في نوافذ الحوار","كل سكربتات الـ NPC"),
 ("@90606096","رقم نص","نص «اختر الأداة» في الحداد","NPC_ItemUP.lua"),
 ("@90606097","رقم نص","نص «مفيش أداة قابلة للتغيير»","NPC_ItemUP.lua"),
 ("@90702500","رقم نص","اسم NPC البف","NPC_Buff.lua"),
 ("0 → 7","خانات اللبس","الخانات اللي get_wear_item_handle بيقرأ منها","NPC_ItemUP.lua / NPC_Buff.lua"),
 ("10000","مقياس النسبة","drop_percentage غالباً من 10000 (يعني 500 = 5%)","DropGroupResource.rdu"),
 ("1996 / 4514 / 1433","بورتات","Auth / اللعبة / SQL","authserver.opt · GameServer.opt"),
 ("42 / 50 / 20 / 180","قيم افتراضية","خبرة ×42 · جولد ×50 · دروب ×20 · أقصى لفل 180","GameServer.opt الأصلي"),
 ("A4&8zx209z&8zx267Ope","مفتاح تشفير","مفتاح MD5 لباسوردات الحسابات","authserver.opt"),
]
body(ws,hr,rows)

# ---------------- 8 StatResource
srows=json.load(open("stat_rows.json"))
ws=wb.create_sheet("بيانات StatResource")
hr=head(ws,["id","STR","VIT","DEX","AGI","INT","MEN","LUK"],
        [10,10,10,10,10,10,10,10],f"StatResource الحقيقي — {len(srows)} صف",
        "كل صف = باكدج أرقام للصفات الأساسية. استخدمه كمرجع للتوازن أو لما تختار قيم لأداة.")
body(ws,hr,srows,zebra=False)

# ---------------- 9 القيم الافتراضية
ws=wb.create_sheet("القيم الافتراضية الحقيقية")
hr=head(ws,["الإعداد","القيمة الأصلية في الحزمة","موجود في","معناه"],
        [34,26,34,50],"قيم الحزمة الأصلية زي ما هي قبل أي تعديل")
rows=[
 ("game.exp_rate","42","GameServer.opt","مضاعف الخبرة"),
 ("game.gold_drop_rate","50","GameServer.opt","مضاعف الذهب"),
 ("game.item_drop_rate","20","GameServer.opt","مضاعف نسبة الدروب"),
 ("game.max_level","180","GameServer.opt","أقصى لفل"),
 ("game.min_global_chat_usable_level","80","GameServer.opt","أقل لفل للشات العام"),
 ("game.item_hold_time","2500","GameServer.opt","زمن الإمساك بالأداة"),
 ("game.enhance_fail_type","2","GameServer.opt","نوع فشل التطوير"),
 ("io.port","4514","GameServer.opt","بورت اللعبة"),
 ("io.ip_address","127.0.0.1","GameServer.opt","العنوان اللي اللاعب بيوصل بيه"),
 ("auth.server_idx","1","GameServer.opt","رقم السيرفر"),
 ("game.update.version","24","GameServer.opt","إصدار تحديث البيانات"),
 ("io.auth.port","1996","authserver.opt","بورت دخول اللاعبين"),
 ("db.auth.md5_key","A4&8zx209z&8zx267Ope","authserver.opt","مفتاح تشفير الباسورد"),
 ("db.auth.name","AU-1n2T4rX9o0&345B","authserver.opt","اسم قاعدة الحسابات (غيّره لـ Auth)"),
 ("db.auth.use_md5","1","authserver.opt","استخدام MD5"),
 ("auth.user_rate_mod","20","authserver.opt","مضاعف سعر الوقت"),
 ("auth.max_client_per_ip","9999","authserver.opt","أقصى اتصالات من IP"),
 ("console.port (auth)","1995","authserver.opt","كونسول الـ Auth"),
 ("console.port (game)","65528","GameServer.opt","كونسول اللعبة"),
]
body(ws,hr,rows)

# ---------------- 10 إزاي تلاقي الاسم
ws=wb.create_sheet("إزاي تلاقي الاسم الحقيقي")
hr=head(ws,["الخطوة","تعمل إيه","النتيجة"],
        [10,64,54],"الأسماء العربية/الإنجليزية للأدوات مش في السيرفر — دي طريقة الحصول عليها")
rows=[
 ("1","السيرفر بيحفظ name_id (رقم) و icon_file_name (اسم ملف وصفي زي icon_ring_7rank_ringofsalamander)","عندك وصف إنجليزي وصفي فوراً"),
 ("2","افتح SSMS واستعلم: SELECT id, name_id, icon_file_name FROM ItemResource WHERE icon_file_name LIKE 'icon_ring%'","قائمة خواتم بأرقامها"),
 ("3","في اللعبة: خد الأداة اللي عايز تعرف رقمها، وشوف اسمها في الشات/التولتيب","تربط الاسم العربي بالرقم يدويًا"),
 ("4","لو معاك أداة GM تعرض رقم الأداة — أسرع طريقة","تكتب الرقم في الدفتر"),
 ("5","للعرض الكامل (كل الأسماء): محتاج تعديل الكلاينت (data.001) — شوف دليل الكلاينت","أسماء منسّقة عربي/إنجليزي"),
]
body(ws,hr,rows)

for s in wb.worksheets:
    s.sheet_properties.tabColor = GOLD if s.title in ("ابدأ من هنا","أرقام حقيقية مهمة") else TECH

wb.save("/home/user/rappelz-real-reference.xlsx")
print("saved", len(wb.worksheets), "sheets")
