# -*- coding: utf-8 -*-
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter

NAVY   = "1F3550"
BLUE   = "2A6FA8"
GOLD   = "C8952A"
LIGHT  = "EEF3F8"
GREY   = "F7F9FB"
OK_G   = "E6F4EA"

thin = Side(style="thin", color="C9D4E0")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
H_FONT = Font(name="Segoe UI", bold=True, color="FFFFFF", size=11)
B_FONT = Font(name="Segoe UI", size=10.5, color="1B2430")
T_FONT = Font(name="Segoe UI", bold=True, size=15, color="FFFFFF")

wb = Workbook()

def head(ws, cols, widths, title=None, start_row=1):
    r = start_row
    if title:
        ws.cell(row=1, column=1, value=title)
        ws.cell(row=1, column=1).font = Font(name="Segoe UI", bold=True, size=14, color="1B2430")
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(cols))
        ws.cell(row=1, column=1).fill = PatternFill("solid", fgColor=LIGHT)
        ws.cell(row=1, column=1).alignment = Alignment(horizontal="right", vertical="center")
        ws.row_dimensions[1].height = 30
        r = 3
    for i, c in enumerate(cols, start=1):
        cell = ws.cell(row=r, column=i, value=c)
        cell.font = H_FONT; cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[r].height = 26
    ws.freeze_panes = ws.cell(row=r+1, column=1)
    ws.sheet_view.rightToLeft = True
    return r

def body(ws, start_row, n_cols, rows, zebra=True):
    for j, row in enumerate(rows):
        rr = start_row + 1 + j
        for i in range(1, n_cols+1):
            v = row[i-1] if i-1 < len(row) else None
            c = ws.cell(row=rr, column=i, value=v)
            c.font = B_FONT; c.border = border
            c.alignment = Alignment(horizontal="right", vertical="center", wrap_text=True)
            if zebra and j % 2 == 1:
                c.fill = PatternFill("solid", fgColor=GREY)
        ws.row_dimensions[rr].height = 20

def empty_rows(ws, start_row, n_cols, n, zebra=True):
    for j in range(n):
        rr = start_row + 1 + j
        for i in range(1, n_cols+1):
            c = ws.cell(row=rr, column=i)
            c.border = border; c.font = B_FONT
            c.alignment = Alignment(horizontal="right", vertical="center")
            if zebra and j % 2 == 1: c.fill = PatternFill("solid", fgColor=GREY)
        ws.row_dimensions[rr].height = 20

# ---------------------------------------------------------------- 1
ws = wb.active; ws.title = "ابدأ من هنا"
ws.sheet_view.rightToLeft = True
ws.column_dimensions["A"].width = 4
ws.column_dimensions["B"].width = 30
ws.column_dimensions["C"].width = 95
ws["B2"] = "دفتر تطوير السيرفر — أمل الشعوب (Rappelz 9.1)"
ws["B2"].font = Font(name="Segoe UI", bold=True, size=18, color="FFFFFF")
ws["B2"].fill = PatternFill("solid", fgColor=NAVY)
ws["B2"].alignment = Alignment(horizontal="right", vertical="center")
ws.merge_cells("B2:C2"); ws.row_dimensions[2].height = 42

intro = [
    ("ده إيه؟", "دفتر واحد تحفظ فيه كل رقم/كود/معلومة تكتشفها وإنت بتطوّر السيرفر. القاعدة الذهبية: «كل رقم مش فاهمه = خزّنه الأول، وافهمه بعدين»."),
    ("ليه؟", "لأن أصعب حاجة في التطوير مش البرمجة — دي إنك تنسى إن كود 1 = حيوية، أو إن الأداة 910001 عملتها إمتى وبأي إعداد."),
    ("إزاي تستخدمه؟", "الشيتات اللي تحتها ألوانها زرقا = «مرجع» جاهز مني (متعدلوش). الشيتات البيضا = بتاعتك تملاها."),
    ("قاعدة الأمان ١", "قبل أي تعديل: انسخ الملف/الفولدر في C:\\RZ\\Backups\\ واكتب سطر في شيت «سجل التجارب»."),
    ("قاعدة الأمان ٢", "لو عدّلت كلاينت (data.001): اشتغل على C:\\RZ\\Client_Test مش على كلاينت اللاعبين."),
    ("قاعدة الأمان ٣", "تعديل واحد في المرة — عشان تعرف إيه اللي بوّظ لو حصلت مشكلة."),
    ("قاعدة الأمان ٤", "اقفل الـ Game Server قبل تعديل الداتابيز، واعمل restart بعد أي تعديل جداول/سكربتات."),
    ("نطاقات الأرقام المقترحة", "خاتم/حجر جديد: 910000–920999 · أيقونات جديدة: 990000–990999 · نصوص جديدة: 900000–900999. المهم: تسجّل كل رقم استخدمته هنا."),
]
r = 5
for k, v in intro:
    ws.cell(row=r, column=2, value=k).font = Font(name="Segoe UI", bold=True, size=11, color="1B2430")
    ws.cell(row=r, column=2).fill = PatternFill("solid", fgColor=GOLD)
    ws.cell(row=r, column=2).font = Font(name="Segoe UI", bold=True, size=11, color="FFFFFF")
    ws.cell(row=r, column=2).alignment = Alignment(horizontal="right", vertical="center")
    ws.cell(row=r, column=2).border = border
    c = ws.cell(row=r, column=3, value=v)
    c.font = B_FONT; c.border = border
    c.alignment = Alignment(horizontal="right", vertical="center", wrap_text=True)
    ws.row_dimensions[r].height = 34 if len(v) < 120 else 48
    r += 1

ws.cell(row=r+1, column=2, value="ترتيب الشيتات").font = Font(bold=True, size=12, color=NAVY)
order = [
    ("١", "أكواد الخصائص", "أهم شيت — أكواد الحيوية/القوة/الرشاقة/البراعة والمعاني"),
    ("٢", "الأدوات ItemResource", "كل أداة عملتها (خاتم/سلاح/درع) بمواصفاتها"),
    ("٣", "الأحجار", "أحجار السفك: كود الخاصية + القيمة + الأيقونة"),
    ("٤", "الدروب", "مجموعات الدروب: أنهي وحش بينزّل إيه وبنسبة كام"),
    ("٥", "الوحوش والمناطق", "أرقام الوحوش وإحداثيات المناطق والكثافة"),
    ("٦", "سجل التجارب", "كل تجربة: عملت إيه، النتيجة، الخطأ، الحل"),
    ("٧", "أفكار وتطويرات", "قائمة أفكارك مرتبة بالأولوية"),
    ("٨", "مرجع جداول الموارد", "٦٢ جدول Resource موجودين في السيرفر — علّم اللي استكشفته"),
    ("٩", "مرجع المسارات والبورتات", "مسارات ملفاتك + البورتات + إعدادات .opt"),
    ("١٠", "مرجع أعمدة ItemResource", "معنى أعمدة جدول الأدوات"),
]
rr = r + 2
for n, name, desc in order:
    ws.cell(row=rr, column=1, value=n).alignment = Alignment(horizontal="center")
    ws.cell(row=rr, column=1).font = B_FONT; ws.cell(row=rr, column=1).border = border
    a = ws.cell(row=rr, column=2, value=name); a.font = Font(bold=True, size=10.5); a.border = border
    a.alignment = Alignment(horizontal="right", vertical="center")
    b = ws.cell(row=rr, column=3, value=desc); b.font = B_FONT; b.border = border
    b.alignment = Alignment(horizontal="right", vertical="center")
    rr += 1

# ---------------------------------------------------------------- 2  أكواد الخصائص
ws = wb.create_sheet("أكواد الخصائص")
cols = ["كود (رقم)", "نوعه", "المعنى بالعربي", "أقل قيمة شفتها", "أعلى قيمة شفتها", "من أنهي أداة/حجر استخرجته (رقم)", "مصدر المعلومة", "الحالة", "تاريخ", "ملاحظات"]
w    = [12, 14, 26, 16, 16, 30, 18, 12, 12, 34]
hr = head(ws, cols, w, "أكواد الخصائص — أهم شيت في الدفتر")
body(ws, hr, len(cols), [
    ("1", "base", "(مثال) حيوية — امسحني واكتب الصح", 50, 300, "510001 (حجر حيوية)", "مقارنة أداة في اللعبة", "مكتشف", "2025-11-10", "اتأكدت منه بمقارنة 3 أحجار"),
    ("96", "opt", "(مثال) خاصية أوبشن — رقم 96 شفناه في سكربت NPC_ItemUP", "-", "-", "سكربت التطوير", "من كود اللعبة", "مجرّب", "2025-11-10", "اتستخدم مع subtype 512 و 1024"),
], )
empty_rows(ws, hr+3, len(cols), 45)
dv = DataValidation(type="list", formula1='"مكتشف,مجرّب,شغّال,فشل"', allow_blank=True)
ws.add_data_validation(dv); dv.add(f"H{hr+1}:H{hr+80}")

# ---------------------------------------------------------------- 3 الأدوات
ws = wb.create_sheet("الأدوات ItemResource")
cols = ["رقم الأداة id", "الاسم في اللعبة", "name_id", "icon_id / icon_file_name", "type", "group", "class", "wear_type",
        "level", "use_min_level", "socket", "enhance_id", "base_type_0", "base_var1_0", "base_type_1", "base_var1_1",
        "opt_type_0", "opt_var1_0", "النسخة الأصلية (رقمها)", "الحالة", "تاريخ الإنشاء", "ملاحظات"]
w = [14, 22, 10, 26, 8, 8, 8, 10, 8, 12, 9, 12, 12, 12, 12, 12, 12, 12, 20, 11, 14, 34]
hr = head(ws, cols, w, "سجل الأدوات اللي عملتها")
body(ws, hr, len(cols), [
    ("910001", "(مثال) خاتم اللهب الأبدي", 4412, "icon_ring_7rank_ringofsalamander", "؟", "؟", "؟", "؟", 185, 185, 3, "؟", 1, 500, 2, 400, 5, 10, "4412", "شغال", "2025-11-10", "امسح الصف ده بعد ما تفهم الشكل"),
])
empty_rows(ws, hr+2, len(cols), 40)
dv2 = DataValidation(type="list", formula1='"قيد التنفيذ,شغال,فشل,مسحوب"', allow_blank=True)
ws.add_data_validation(dv2); dv2.add(f"T{hr+1}:T{hr+60}")

# ---------------------------------------------------------------- 4 الأحجار
ws = wb.create_sheet("الأحجار")
cols = ["رقم الحجر", "الاسم", "نوعه (type/group/class من الأصل)", "كود الخاصية base_type_0", "القيمة base_var1_0",
        "opt_type / var", "أيقونة (icon_file_name / icon_id)", "use_min_level", "النسخة الأصلية (رقمها)",
        "بيتسفك في (نوع العتاد)", "طريقة الحصول (دروب/شوب/فعالية)", "الحالة", "ملاحظات"]
w = [12, 20, 26, 18, 18, 16, 28, 12, 18, 20, 24, 11, 30]
hr = head(ws, cols, w, "أحجار السفك — الجديدة")
body(ws, hr, len(cols), [
    ("920001", "(مثال) حجر الحيوية الأعظم", "زي الأصل — منقول", 1, 1000, "-", "icon_item_mygem_big / 990601", 185, "510001", "زي الأصل", "دروب 3%", "شغال", "امسحني"),
])
empty_rows(ws, hr+2, len(cols), 35)

# ---------------------------------------------------------------- 5 الدروب
ws = wb.create_sheet("الدروب")
cols = ["رقم مجموعة الدروب (DropGroup id)", "اسم الوحش / المنطقة", "رقم الوحش monster_id", "الخانة (00–09)",
        "رقم الأداة drop_item_id", "min_count", "max_count", "النسبة (من 10000)", "النسبة %", "الحالة", "ملاحظات"]
w = [26, 24, 18, 12, 20, 11, 11, 18, 11, 11, 30]
hr = head(ws, cols, w, "مجموعات الدروب")
body(ws, hr, len(cols), [
    ("1234", "(مثال) وحش تجريبي", "-", "05", 920001, 1, 1, 2000, "20%", "مجرب", "امسحني — النسبة غالباً من 10000"),
])
empty_rows(ws, hr+2, len(cols), 40)

# ---------------------------------------------------------------- 6 الوحوش والمناطق
ws = wb.create_sheet("الوحوش والمناطق")
cols = ["رقم الوحش monster_id", "اسمه", "المنطقة", "الإحداثيات (left/top/right/bottom)", "الكثافة / العدد",
        "الملف أو الجدول اللي عدّلته", "نوع الظهور (عادي/نادر/بوس)", "الحالة", "تاريخ", "ملاحظات"]
w = [20, 20, 20, 34, 16, 30, 20, 11, 14, 30]
hr = head(ws, cols, w, "الوحوش والمناطق (monster_respawn / random_respawn)")
empty_rows(ws, hr, len(cols), 35)

# ---------------------------------------------------------------- 7 سجل التجارب
ws = wb.create_sheet("سجل التجارب")
cols = ["التاريخ", "الوقت", "عملت إيه (تعديل)", "الملف/الجدول", "النسخة الاحتياطية؟", "النتيجة",
        "رسالة الخطأ (انسخها بالحرف)", "الحل اللي نفع", "اتعلمت إيه"]
w = [12, 9, 40, 26, 16, 22, 40, 30, 30]
hr = head(ws, cols, w, "سجل التجارب — دي الذاكرة بتاعة المشروع")
body(ws, hr, len(cols), [
    ("2025-11-10", "18:00", "(مثال) نسخت خاتم 4412 لرقم 910001 غيّرت use_min_level", "ItemResource", "أيوه — Backups\\r1", "شغال", "-", "حطيت use_min_level مش level بس", "اللفل بيتحكم فيه use_min_level"),
])
empty_rows(ws, hr+2, len(cols), 60)
dv3 = DataValidation(type="list", formula1='"أيوه,لأ,مش محتاج"', allow_blank=True)
ws.add_data_validation(dv3); dv3.add(f"E{hr+1}:E{hr+80}")

# ---------------------------------------------------------------- 8 أفكار
ws = wb.create_sheet("أفكار وتطويرات")
cols = ["الأولوية", "الفكرة", "النوع (أداة/نظام/خريطة/كلاينت)", "محتاج إيه", "الصعوبة", "الحالة", "ملاحظات"]
w = [12, 46, 26, 30, 12, 14, 30]
hr = head(ws, cols, w, "أفكار وتطويرات")
body(ws, hr, len(cols), [
    ("عالية", "(مثال) حجر حيوية كبير + 2 أحجار ألوان", "أداة", "أيقونات + SQL", "سهل", "قيد التنفيذ", "امسحني"),
], )
empty_rows(ws, hr+2, len(cols), 40)
dv4 = DataValidation(type="list", formula1='"عالية,متوسطة,منخفضة"', allow_blank=True)
ws.add_data_validation(dv4); dv4.add(f"A{hr+1}:A{hr+60}")
dv5 = DataValidation(type="list", formula1='"قيد التنفيذ,خلصت,مؤجل,اتلغت"', allow_blank=True)
ws.add_data_validation(dv5); dv5.add(f"F{hr+1}:F{hr+60}")

# ---------------------------------------------------------------- 9 مرجع جداول الموارد
tables = """AutoAuctionResource|AwakenProbabilitiesResource|AwakenResource|BanWordResource|BattleArenaBeginAreaResource|BattleArenaFieldPropResource|BattleArenaMonsterRespawnResource|BattleArenaResource|ChannelResource|ChannelUserLimitResource|CreatureFarmResource|DeathmatchResource|DecomposeResource|DropGroupLocalResource|DropGroupResource|DungeonResource|EnhanceResource|EventAreaResource|FieldPropResource|FieldPropSwitchingResource|HuntaholicHealingPropResource|HuntaholicInstanceResource|HuntaholicMonsterRespawnResource|HuntaholicResource|InstanceDungeonHealingPropResource|InstanceDungeonMonsterRespawnResource|InstanceDungeonResource|InstanceDungeonTypeResource|ItemConversionResource|ItemLocalResource|ItemResource|JobResource|LevelResource|LoadResource|LockResource|MarketResource|MixResource|MonsterCreatureResource|MonsterResource|NPCEventPeriodResource|NPCResource|PetResource|QuestLinkResource|QuestResource|RandomItemOptionResource|RandomItemPresetResource|RandomPoolResource|SetItemEffectResource|SkillJPResource|SkillResource|SkillTreeResource|StatResource|StateResource|StringLocalResource|StringResource|SummonDefaultNameResource|SummonLevelResource|SummonRandomSkillResource|SummonResource""".split("|")
ws = wb.create_sheet("مرجع جداول الموارد")
cols = ["اسم الجدول", "بيتحكم في إيه", "استكشفته؟", "لقيت فيه إيه (اكتب) "]
w = [34, 40, 14, 52]
hr = head(ws, cols, w, "مرجع — ٦٠ جدول موارد بيقرأهم السيرفر (لقيتها في البيناري)")
desc = {
 "ItemResource":"كل الأدوات ومواصفاتها","DropGroupResource":"جداول الدروب (10 خانات لكل مجموعة)",
 "DropGroupLocalResource":"دروب محلية حسب المنطقة","MarketResource":"الشوبات والأسعار","MixResource":"الدمج/الترقية",
 "EnhanceResource":"درجات التطوير +X","StatResource":"جداول الأرقام (ستاتس)","SummonResource":"المرافقين/الوحوش المستدعاة",
 "RandomItemOptionResource":"الخصائص العشوائية (أوبشن)","RandomItemPresetResource":"قوالب الخصائص العشوائية",
 "RandomPoolResource":"مجموعات العشوائية","AwakenResource":"نظام الإفاقة/التنشيط","AwakenProbabilitiesResource":"نِسَب الإفاقة",
 "NPCResource":"الـ NPC","MonsterResource":"الوحوش","SkillResource":"المهارات","SkillTreeResource":"شجرة المهارات",
 "StringResource":"النصوص","StringLocalResource":"نصوص محلية","QuestResource":"المهام","DungeonResource":"الدنجن",
 "LevelResource":"اللفلات والخبرة","JobResource":"التخصصات","PetResource":"المرافقين","LockResource":"القفل/الختم",
}
rows=[]
for t in tables:
    rows.append((t, desc.get(t, ""), "", ""))
body(ws, hr, len(cols), rows, zebra=True)
dv6 = DataValidation(type="list", formula1='"لأ,جزئياً,أيوه"', allow_blank=True)
ws.add_data_validation(dv6); dv6.add(f"C{hr+1}:C{hr+len(rows)+5}")

# ---------------------------------------------------------------- 10 مرجع المسارات
ws = wb.create_sheet("مرجع المسارات والبورتات")
cols = ["البند", "القيمة", "ملاحظات"]
w = [34, 52, 46]
hr = head(ws, cols, w, "مرجع — مساراتك وبورتاتك (عدّل القيم لو غيّرت مكان الملفات)")
rows = [
 ("فولدر السيرفر","C:\\RZ\\Server",""),
 ("فولدر الكلاينت","C:\\RZ\\Client",""),
 ("كلاينت التجارب","C:\\RZ\\Client_Test","اشتغل هنا قبل ما تعدّل كلاينت اللاعبين"),
 ("النسخ الاحتياطية","C:\\RZ\\Backups","قواعد + RDU + Script + opt"),
 ("الإعدادات authserver","C:\\RZ\\Server\\GameEngine\\Auth_bin\\authserver.opt",""),
 ("الإعدادات GameServer","C:\\RZ\\Server\\GameEngine\\Game_bin\\GameServer.opt",""),
 ("السكربتات","C:\\RZ\\Server\\GameEngine\\Game_bin\\Resource\\Script",""),
 ("موارد RDU","C:\\RZ\\Server\\RDU",""),
 ("اللوج","C:\\RZ\\Server\\GameEngine\\Game_bin\\Log","أول مكان تشوفه عند أي خطأ"),
 ("قاعدة الحسابات","Auth",""),
 ("قاعدة اللعبة","Arcadia","بتستقبل RDU من DBUpdater"),
 ("قاعدة اللاعبين","Telecaster1",""),
 ("قاعدة الشحن","BILLING",""),
 ("بورت Auth (دخول اللاعبين)","1996","يفتح للنت"),
 ("بورت اللعبة","4514","يفتح للنت"),
 ("بورت رفع صور الجيلد","4616 / 4617","يفضّل"),
 ("بورت SQL","1433","ممنوع يفتح على النت"),
 ("كونسول Auth","1995 (محلي فقط)",""),
 ("كونسول Game","65528 (محلي فقط)",""),
 ("مفتاح تشفير الباسوردات","A4&8zx209z&8zx267Ope","موجود في authserver.opt — لو غيّرته غيّره في الموقع كمان"),
 ("IP للتجربة المحلية","127.0.0.1","في io.ip_address واللانشر"),
 ("أمر تشغيل Auth","start_service ثم set game.open_external 1","من كونسول Auth"),
]
body(ws, hr, len(cols), rows)

# ---------------------------------------------------------------- 11 مرجع أعمدة ItemResource
cols = ["العمود", "معناه", "ملاحظات / قيم"]
w = [30, 46, 56]
ws = wb.create_sheet("مرجع أعمدة ItemResource")
hr = head(ws, cols, w, "مرجع — أعمدة جدول الأدوات (من فحص ملف ItemResource.rdu)")
fields = [
 ("id","رقم الأداة","لازم فريد — استخدم 910000+"),
 ("name_id","رقم الاسم في الكلاينت","★ الاسم مش نص هنا — رقم بيروح للكلاينت"),
 ("tooltip_id","رقم الوصف",""),
 ("type / group / class","نوع الأداة","انسخهم من أداة شغّالة"),
 ("wear_type","مكان اللبس","خاتم = خانة الإصبع"),
 ("set_id / set_part_flag","الطقم",""),
 ("grade / rank","الفئة/الرتبة",""),
 ("level","لفل الأداة",""),
 ("use_min_level / use_max_level","لفل الاستخدام","★ ده اللي بيمنع اللبس تحت لفل معين"),
 ("target_min_level / max","لفل الهدف (للأدوات اللي بتستخدم على غيرك)",""),
 ("enhance","درجة التطوير الحالية","+0 +1 …"),
 ("enhance_id","مجموعة قواعد التطوير","يروح لجدول EnhanceResource"),
 ("socket","عدد خانات الأحجار","المحرك بيدعم لحد 4"),
 ("status_flag","أعلام حالة",""),
 ("limit_deva/asura/gaia","مسموح للأجناس",""),
 ("job_depth, limit_fighter/hunter/magician/summoner","قيود التخصص",""),
 ("range / throw_range","المدى",""),
 ("weight","الوزن",""),
 ("price","السعر الأساسي",""),
 ("huntaholic_point / arena_point","نقاط الفعاليات",""),
 ("ethereal_durability / endurance / material","المتانة والمادة",""),
 ("summon_id","المرافق المرتبط",""),
 ("item_use_flag","طريقة الاستخدام",""),
 ("available_period","مدة الصلاحية",""),
 ("decrease_type","طريقة النقصان",""),
 ("base_type_0..3","★ كود الخاصية الأساسية (4 خانات)",""),
 ("base_var1_0..3 / base_var2_0..3","★ قيمة الخاصية (من/إلى)",""),
 ("opt_type_0..3","★ كود الأوبشن (4 خانات)",""),
 ("opt_var1_0..3 / opt_var2_0..3","★ قيمة الأوبشن",""),
 ("effect_id","تأثير بصري",""),
 ("skill_id","مهارة يديها",""),
 ("state_id / state_level / state_time","حالة (بف) يديها",""),
 ("cool_time / cool_time_group","وقت التهدئة",""),
 ("model_type_dem/def/asm/asf/gam/gaf","موديل لكل جنس","كلاينت"),
 ("model_00..17","ملفات الموديل","كلاينت"),
 ("texture_filename","التكتشر","كلاينت"),
 ("icon_id / icon_file_name","★ الأيقونة","كلاينت"),
 ("drop_type","نوع السقوط",""),
 ("group_bit_set","تصنيف داخلي",""),
 ("script_text","نص داخلي",""),
 ("drop_etc_pouch","شنطة الدروب",""),
]
body(ws, hr, len(cols), fields)

# styling: tab colors
colors = {"ابدأ من هنا":"C8952A","أكواد الخصائص":"2A6FA8","الأدوات ItemResource":"2A6FA8","الأحجار":"2A6FA8",
          "الدروب":"2A6FA8","الوحوش والمناطق":"2A6FA8","سجل التجارب":"C8952A","أفكار وتطويرات":"C8952A",
          "مرجع جداول الموارد":"6B7C93","مرجع المسارات والبورتات":"6B7C93","مرجع أعمدة ItemResource":"6B7C93"}
for s in wb.worksheets:
    s.sheet_properties.tabColor = colors.get(s.title, "6B7C93")

wb.save("/home/user/rappelz-modding-notebook.xlsx")
print("saved")
