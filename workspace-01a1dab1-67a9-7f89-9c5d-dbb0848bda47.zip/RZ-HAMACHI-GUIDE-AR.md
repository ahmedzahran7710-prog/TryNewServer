# تشغيل السيرفر على Hamachi وإرسال الكلاينت لصاحبك
**Rappelz 9.1 · Revolution pack + rzauth v6.5 · Windows · 2026-11-10**

---

## 0) القاعدة الذهبية قبل أي حرف

> **التغيير الوحيد على السيرفر = سطر واحد في `GameServer.opt`.**
> كل الباقي على الكلاينت والجدار الناري وحساب صاحبك. `auth.opt` **مش هيتلمس**.

اعمل النسخة الاحتياطية دي الأول (سطر واحد في CMD):

```cmd
copy "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin\GameServer.opt" "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin\GameServer.opt.BEFORE-HAMACHI" & copy "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin\GameServer.eop" "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin\GameServer.eop.BEFORE-HAMACHI"
```

> لو مسار السيرفر مختلف، بدّل الجزء `C:\RZ\Server\FilesOfficial-Revolution9.1` بالمسار الصح. النسخة الاحتياطية أهم خطوة في الملف كله.

---

## 1) ثبّت Hamachi واعمل شبكة

1. نزّل **LogMeIn Hamachi** على جهازك (والشبكة المجانية بتسمح حتى **5 أجهزة**).
2. افتحه → `Network` → `Create a new network`:
   - **Network ID:** `ahmed-rappelz`
   - **Password:** باسورد قوي (ده اللي هيبعته لصاحبك)
3. من فوق عند اسمك هتلاقي رقم شكل **`25.x.x.x`** ⇒ **ده عنوان السيرفر الجديد**. اكتبه.

**تحقق:** الـ Hamachi بيظهر `Online` (نقطة خضرا) جانب اسمك.

> صاحبك يعمل `Join an existing network` بنفس الـ ID والباسورد، ولازم يبقى `Online` كمان.
> هاماتشي بيعمل الاتصال عبر سيرفراتهم (Relay) ⇒ **مش محتاج تفتح بورت في الراوتر ولا IP ثابت**.

---

## 2) التعديل الوحيد على السيرفر (سطر 12)

**الخطوة أ — عدّل الملف** `GameEngine\Game_bin\GameServer.opt` في Notepad:

```
السطر القديم:   S:io.ip_address:127.0.0.1
السطر الجديد:   S:io.ip_address:25.x.x.x        ← حط IP هاماتشي بتاعك
```

> `io.ip_address` هو العنوان الوحيد اللي السيرفر بيعرّف بيه الكلاينت على **سيرفر العالم (4514)**.
> لو سيبته `127.0.0.1`، صاحبك هيدخل في اللوجن وبعدها الجيم هيقطع على شاشة التحميل.
> **ماتلمسش** `io.auth.ip` ولا `db.*` ولا `io.port` ولا `auth.server_idx`.

**الخطوة ب — أعد ضغط الملف** (السيرفر بيقرأ `.eop` مش `.opt`):

```cmd
cd /d "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin" && RappelzCompress.exe GameServer.opt
```

> نفس الخطوة اللي عملناها قبل كده. لازم يتولّد/يتحدّث `GameServer.eop` بتاريخ النهاردة.

**الخطوة ج — شغّل السيرفر** بنفس الترتيب المعتاد:
`SQL Server` → `LogServer.exe` → `rzauth.exe` → `CaptainHerlockServer.exe`

**تحقق:** في كونسول rzauth لازم تشوف `Server Login: Game001` زي كل مرة، وفي كونسول اللعبة `Connect To Auth... ok` و`Connect To Upload... ok`. لو ظهرت مشكلة في الـ IP هتبان هنا فورًا.

---

## 3) الجدار الناري — **استبدل** قاعدة أمس (مهم)

قاعدة `RZ-LOCK` اللي عملناها بتمنع **أي** اتصال خارجي، ومنها هاماتشي ⇒ لو سبتها صاحبك مش هيوصل. امسحها وحدّد النطاق:

**افتح CMD كمسؤول والصق الأسطر دي مرة واحدة:**

```cmd
netsh advfirewall firewall delete rule name="RZ-LOCK"
netsh advfirewall firewall add rule name="RZ-HAMACHI-IN" dir=in action=allow protocol=TCP localport=1996,4514 remoteip=25.0.0.0/8
netsh advfirewall firewall add rule name="RZ-BLOCK-SQL" dir=in action=block protocol=TCP localport=1433
```

| القاعدة | الوظيفة |
|---|---|
| `RZ-HAMACHI-IN` | يسمح بـ 1996 + 4514 **من شبكة هاماتشي فقط** (25.x.x.x) |
| حذف `RZ-LOCK` | عشان ما يمنعش صاحبك |
| `RZ-BLOCK-SQL` | يفضل قافل SQL 1433 على الكل (ده مش محتاج يوصل لأي حد) |

**تحقق:**
```cmd
netsh advfirewall firewall show rule name="RZ-HAMACHI-IN"
```
لازم تشوف `Enabled: Yes` و`RemoteIP: 25.0.0.0/8` و`LocalPort: 1996,4514`.

> **ملاحظة:** يفضل كمان تشيل أي قاعدة "Allow" قديمة اتعملت أوتوماتيك لـ `rzauth.exe` / `CaptainHerlockServer.exe` (بتظهر أول مرة بتسأل Allow access). لو موجودة، هتفتح كل بورتات البرنامج ومش هتفرق معاها الـ remoteip.

---

## 4) اعمل حساب لصاحبك

افتح SSMS → New Query → شغّل **`add-friend-account.sql`** (الملف في نفس المجلد ده)، وعدّل الاسم والباسورد:

| الحقل | مثال |
|---|---|
| login_name | `friend1` |
| password | `Friend2026` |

الباسورد بيتحول تلقائي لـ `md5(salt + password)` بنفس مفتاح `auth.db.salt` → `A4&8zx209z&8zx267Ope`.

**تحقق:** الاستعلام الأخير في الملف لازم يرجّع صف `friend1` بـ `block = 0` و`auth_ok = 1`.

> ابعتهوله بالاسم والباسورد **بس**. لا تبعتله `test2` ولا أي حساب تاني.

---

## 5) جهّز الكلاينت للضغط

### أ) امسح الحاجات الشخصية من نسخة الكلاينت (على النسخة اللي هتبعتها، مش الأصلية)
```
rappelz_v1.opt        ← إعدادات جرافيك/كيبورد شخصية (امسحها، هيتولد غيرها)
sframe_old.exe        ← احتياطيك القديم، مالوش لازمة عنده
Screenshot\           ← صورك
*.log  ·  *.dmp       ← لوجات
```

### ب) عدّل سطر التشغيل
افتح **`Revolution Launcher.bat`** بـ Notepad واستبدل **`127.0.0.1`** بـ IP هاماتشي بس:

```
قبل:   ... /auth_ip:127.0.0.1 /auth_port:1996 /use_nprotect:0
بعد:   ... /auth_ip:25.x.x.x   /auth_port:1996 /use_nprotect:0
```
ماتغيّرش أي حاجة تانية في السطر. ولو الملف فيه أكتر من سطر فيه `127.0.0.1`، غيّرهم كلهم.

### ج) اضغط المجلد
بـ 7-Zip: كليك يمين على مجلد الكلاينت → `7-Zip` → `Add to archive`
- Archive format: `7z`
- Compression level: **Fastest** (الفرق في الحجم بسيط والوقت بيفرق جدًا)
- `Split to volumes`: سيبه فاضي لو هترفعه على Google Drive

### د) ارفعه
ارفعه على **Google Drive** وابعتله اللينك (اعمله Share → Anyone with the link). حجم الكلاينت عادة 2–4 جيجا.

---

## 6) اللي صاحبك يعمله (ابعتهوله زي ما هو)

1. ينزّل **Hamachi** ويدخل: `Join an existing network` → نفس الـ ID والباسورد.
2. يتأكد إن اسمك `Online` جنبه.
3. يفك ضغط الكلاينت على قرص فيه **مساحة فاضية 10 جيجا على الأقل** (مش على C: لو مليان).
4. يعمل **Exclusion** لمجلد اللعبة في الأنتي فيرس (ملفات GameGuard بتتصطاد غلط).
5. يشغّل `Revolution Launcher.bat`.
6. يدخل بـ `friend1` / الباسورد.

**اختبار سريع قبل ما يحمّل 3 جيجا** — يقوله يعمل كده من PowerShell:
```powershell
Test-NetConnection 25.x.x.x -Port 1996
```
لازم `TcpTestSucceeded : True` قبل أي حاجة. لو `False` المشكلة في هاماتشي أو الجدار الناري، مش في الكلاينت.

---

## 7) لو حصلت مشكلة — الجدول ده بيحل 90%

| العرض | السبب | الحل |
|---|---|---|
| `Test-NetConnection` بيرجع False | هاماتشي مش Online / الجدار الناري | راجع الخطوة 3 + إنه في نفس الشبكة |
| بيدخل اللوجن وبعدين "Cannot connect to server" | `io.ip_address` لسه `127.0.0.1` أو `.eop` مش متحدّث | راجع الخطوة 2 (أ+ب) وأعد تشغيل السيرفر |
| `This Session is not verify version` | كلاينت/`sframe` مختلف عن بتاعك | ابعته **نفس المجلد** بالظبط، ممنوع ينزّل كلاينت تاني |
| Login failed | باسورد مش مطابق للمفتاح | أعد تشغيل `add-friend-account.sql` من غير تعديل الـ salt |
| بيدخل وبعد ثواني يقطع | Upload/Log مش شغال أو بورت 4616 مشغول | تأكد إن `UploadServer.exe` **مقفول** (rzauth هو اللي بيشغل الوظيفة دي) |
| لاج عالي جدًا | هاماتشي بيمر عبر Relay | ده طبيعي (50–150ms)، مش مشكلة سيرفر |
| الأنتي فيرس مسح ملفات | GameGuard | Exclusion للمجلد |

---

## 8) الرجوع للوضع المحلي (لو حصل أي حاجة)

**أ) السيرفر — رجّع السطر الواحد:**
```
S:io.ip_address:127.0.0.1
```
وبعدها `RappelzCompress.exe GameServer.opt` وأعد التشغيل. أو من النسخة الاحتياطية:
```cmd
copy "...\Game_bin\GameServer.opt.BEFORE-HAMACHI" "...\Game_bin\GameServer.opt" & copy "...\Game_bin\GameServer.eop.BEFORE-HAMACHI" "...\Game_bin\GameServer.eop"
```

**ب) الجدار الناري:**
```cmd
netsh advfirewall firewall delete rule name="RZ-HAMACHI-IN"
netsh advfirewall firewall add rule name="RZ-LOCK" dir=in action=block protocol=TCP localport=1433,1996,4501,4502,4514,4616,4617,5000,65528
```

**ج) حساب صاحبك (اختياري):**
```sql
UPDATE Auth.dbo.Accounts SET block = 1 WHERE login_name = N'friend1';
```

---

## 9) اللي **مش** هيتغير نهائيًا

- `auth.opt` — سايبه زي ما هو (`auth.clients.ip:0.0.0.0` أصلًا بيسمع لكل الواجهات، ومنها هاماتشي).
- `authserver.opt` / `AuthServer.eop` — مالهمش دخل.
- `auth.db.*` و`sql.db_*` — قاعدة البيانات محلية، صاحبك مش بيلمسها.
- `PrincessAuroraServer.exe` و`UploadServer.exe` — **مازالوا مقفولين**، ولا داعي لتشغيلهم.
- البورتات `4501` و`65528` (الكونسولات) — على `127.0.0.1` فقط. سيبها، ومتفتحهاش لهاماتشي أبدًا.
- `LogServer` — محلي فقط.
