-- =============================================================
--  03_online.sql
--  رجّع الداتابيز ONLINE من المكان الجديد على F:
-- =============================================================

USE [master];
GO

ALTER DATABASE [Arcadia] SET ONLINE;
GO
ALTER DATABASE [Auth] SET ONLINE;
GO
ALTER DATABASE [Billing] SET ONLINE;
GO

-- التحقق
SELECT
    DB_NAME(database_id) AS [الداتابيز],
    name                 AS [الملف],
    physical_name        AS [المسار],
    state_desc           AS [الحالة]
FROM sys.master_files
WHERE DB_NAME(database_id) IN ('Arcadia', 'Auth', 'Billing')
ORDER BY [الداتابيز], file_id;
GO

-- لازم التلاتة يطلعوا ONLINE وكل المسارات تبدأ بـ F:\SQLData\
SELECT name AS [الداتابيز], state_desc AS [الحالة]
FROM sys.databases
WHERE name IN ('Arcadia', 'Auth', 'Billing', 'Telecaster')
ORDER BY name;
GO

PRINT '>>> لو التلاتة ONLINE والمسارات F: — النقل تم بنجاح';
GO
