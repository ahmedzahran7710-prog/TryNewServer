-- =============================================================
--  01_offline_modify.sql
--  (اختياري - متقدّم) نقل ملفات الداتابيز الفيزيائية من C: لـ F:
--
--  ⚠️ اقرأ README.md في نفس الفولدر قبل ما تشغّل أي حاجة
--  ⚠️ الأفضل تعمل Backup للداتابيز قبلها
--
--  الترتيب:
--    1) شغّل الملف ده        (السيرفر بيبقى OFFLINE)
--    2) شغّل 02_move_files.ps1  (بينقل الملفات فعلياً)
--    3) شغّل 03_online.sql   (السيرفر بيرجع ONLINE من المكان الجديد)
--
--  لو حصلت مشكلة في أي خطوة: الداتابيز هتفضل OFFLINE
--  وملفاتها زي ما هي — مفيش داتا بتضيع. كمّل الخطوات بالترتيب.
-- =============================================================

USE [master];
GO

-- ---------------------------------------------------------------
-- 0) شوف الملفات الحالية (صوّر النتيجة دي!)
-- ---------------------------------------------------------------
SELECT
    DB_NAME(database_id) AS [الداتابيز],
    name                 AS [الاسم المنطقي],
    type_desc            AS [النوع],
    physical_name        AS [المسار الحالي]
FROM sys.master_files
WHERE DB_NAME(database_id) IN ('Arcadia', 'Auth', 'Billing')
ORDER BY [الداتابيز], file_id;
GO


-- ---------------------------------------------------------------
-- 1) وقّف الداتابيز التلاتة
-- ---------------------------------------------------------------
ALTER DATABASE [Arcadia] SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [Auth] SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE [Billing] SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO


-- ---------------------------------------------------------------
-- 2) غيّر المسار في SQL Server (بيتولّد تلقائي لكل ملف)
--    بيحط الملفات في:  F:\SQLData\<نفس اسم الملف>
-- ---------------------------------------------------------------
DECLARE @sql NVARCHAR(MAX) = N'';

SELECT @sql = @sql
    + N'ALTER DATABASE [' + DB_NAME(database_id) + N'] MODIFY FILE (NAME = '''
    + name + N''', FILENAME = ''F:\SQLData\'
    + RIGHT(physical_name, CHARINDEX('\', REVERSE(physical_name)) - 1)
    + N''');' + CHAR(13)
FROM sys.master_files
WHERE DB_NAME(database_id) IN ('Arcadia', 'Auth', 'Billing');

PRINT '--- الأوامر اللي هتتنفذ ---';
PRINT @sql;
PRINT '---------------------------';

EXEC sp_executesql @sql;
GO


-- ---------------------------------------------------------------
-- 3) تأكد إن المسارات اتغيرت فعلاً (لازم تشوف F:\SQLData\...)
-- ---------------------------------------------------------------
SELECT
    DB_NAME(database_id) AS [الداتابيز],
    name                 AS [الاسم المنطقي],
    physical_name        AS [المسار الجديد],
    state_desc           AS [الحالة]
FROM sys.master_files
WHERE DB_NAME(database_id) IN ('Arcadia', 'Auth', 'Billing')
ORDER BY [الداتابيز], file_id;
GO

PRINT '>>> دلوقتي شغّل: 02_move_files.ps1  ثم  03_online.sql';
GO
