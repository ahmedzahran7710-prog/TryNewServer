# 02_move_files.ps1
# ------------------------------------------------------------------
#  (اختياري - متقدّم) بينقل ملفات .mdf و .ldf من C: لـ F:\SQLData
#
#  ⚠️ شغّله بس بعد ما 01_offline_modify.sql ينجح والداتابيز تبقى OFFLINE
#  ⚠️ لو الداتابيز ONLINE، الملفات مقفولة ومش هتتنقل — واللعبة هتكسر
#
#  ملاحظة: Telecaster مش هنا — هو أصلاً بيروح على F: وقت الترجيع
# ------------------------------------------------------------------

$ErrorActionPreference = "Stop"

$src = "C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA"
$dst = "F:\SQLData"

Write-Host ""
Write-Host "=== نقل ملفات الداتابيز ===" -ForegroundColor Cyan
Write-Host "من: $src"
Write-Host "لـ: $dst"
Write-Host ""

# 1) الفولدر الهدف
if (-not (Test-Path $dst)) {
    New-Item -ItemType Directory -Force -Path $dst | Out-Null
    Write-Host "اتعمل فولدر: $dst" -ForegroundColor Green
}

# 2) تأكيد من المستخدم
Write-Host "⚠️  متأكد إن الداتابيز التلاتة OFFLINE؟" -ForegroundColor Yellow
$answer = Read-Host "اكتب  yes  للمتابعة"
if ($answer -ne "yes") {
    Write-Host "اتلغى. مفيش حاجة اتنقلت." -ForegroundColor Red
    exit
}

# 3) النقل
$dbs = @("Arcadia", "Auth", "Billing")
$count = 0

foreach ($db in $dbs) {

    $files = Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
             Where-Object {
                 ($_.Extension -eq ".mdf" -or $_.Extension -eq ".ldf") -and
                 ($_.Name -like "$db*")
             }

    if ($files.Count -eq 0) {
        Write-Host "مفيش ملفات لـ $db (يا إما مش موجود أو اتنقلت قبل كده)" -ForegroundColor DarkGray
        continue
    }

    foreach ($f in $files) {
        $target = Join-Path $dst $f.Name
        Write-Host ("بننقل: " + $f.Name + "  (" + [math]::Round($f.Length/1MB,0) + " MB)") -ForegroundColor White
        Move-Item -Path $f.FullName -Destination $target -Force
        $count++
    }
}

# 4) تحقق
Write-Host ""
Write-Host "=== الملفات في $dst ===" -ForegroundColor Cyan
Get-ChildItem $dst -File -ErrorAction SilentlyContinue |
    Select-Object Name, @{N='MB'; E={[math]::Round($_.Length/1MB,0)}} |
    Sort-Object Name |
    Format-Table -AutoSize

Write-Host "عدد الملفات اللي اتنقلت: $count" -ForegroundColor Green
Write-Host ""
Write-Host ">>> دلوقتي شغّل: 03_online.sql" -ForegroundColor Yellow
Write-Host ""
