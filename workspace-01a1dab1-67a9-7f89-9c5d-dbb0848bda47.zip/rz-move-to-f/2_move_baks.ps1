# 2_move_baks.ps1
# ------------------------------------------------------------------
#  بينقل كل ملفات .bak بتاعة المشروع من C: لـ F:\RZ\DBs
#  وبيتحقق إن كل ملف وصل سليم قبل ما يمسح الأصل.
#
#  المكسب: ~850 ميجا على C:
#  الزمن:  دقيقتين
#
#  تشغيله: كليك يمين -> Run with PowerShell
#
#  ⚠️ بعد النقل، مسار الترجيع بقى:
#        F:\RZ\DBs\Telecaster.bak
#        F:\RZ\DBs\Arcadia.bak   ... وهكذا
# ------------------------------------------------------------------

$ErrorActionPreference = "Stop"
$dst = "F:\RZ\DBs"

Write-Host ""
Write-Host "=== نقل ملفات .bak من C: لـ $dst ===" -ForegroundColor Cyan
Write-Host ""

# 1) اعمل الفولدر الهدف
if (-not (Test-Path $dst)) {
    New-Item -ItemType Directory -Force -Path $dst | Out-Null
    Write-Host "اتعمل فولدر: $dst" -ForegroundColor Green
}

# 2) المصادر المحتملة
$sources = @(
    "C:\RZ\DBs",
    "C:\RZ\Server\FilesOfficial-Revolution9.1\dbs"
)

$moved = 0

foreach ($src in $sources) {

    if (-not (Test-Path $src)) {
        Write-Host "متخطّي (مش موجود): $src" -ForegroundColor DarkGray
        continue
    }

    $files = Get-ChildItem -Path $src -Filter *.bak -File -ErrorAction SilentlyContinue

    if ($files.Count -eq 0) {
        Write-Host "مفيش .bak في: $src" -ForegroundColor DarkGray
        continue
    }

    foreach ($f in $files) {

        $target = Join-Path $dst $f.Name

        if (Test-Path $target) {
            # موجود بالفعل في F: — نتأكد من الحجم قبل ما نمسح الأصل
            $oldSize = (Get-Item $target).Length
            if ($oldSize -eq $f.Length) {
                Write-Host ("موجود بنفس الحجم، بنمسح الأصل: " + $f.Name) -ForegroundColor Yellow
                Remove-Item $f.FullName -Force
                continue
            }
            else {
                Write-Host ("⚠️ موجود بحجم مختلف — مش هنمسح حاجة: " + $f.Name) -ForegroundColor Red
                continue
            }
        }

        Write-Host ("بننقل: " + $f.Name + "  (" + [math]::Round($f.Length/1MB,0) + " MB)") -ForegroundColor White
        Move-Item -Path $f.FullName -Destination $target -Force
        $moved++
    }
}

# 3) تحقق نهائي
Write-Host ""
Write-Host "=== اللي بقى في $dst ===" -ForegroundColor Cyan
Get-ChildItem $dst -File |
    Select-Object Name, @{N='MB'; E={[math]::Round($_.Length/1MB,0)}} |
    Sort-Object Name |
    Format-Table -AutoSize

Write-Host "عدد الملفات اللي اتنقلت: $moved" -ForegroundColor Green
Write-Host ""
Write-Host "المساحة الفاضية على C: دلوقتي:" -ForegroundColor Cyan
Get-PSDrive C | Select-Object @{N='Free_GB'; E={[math]::Round($_.Free/1GB,1)}} | Format-Table -AutoSize

Write-Host ""
Write-Host "✅ خلص. لو الأربعة .bak ظاهرين فوق بحجامهم الصح — إنت جاهز." -ForegroundColor Green
Write-Host ""
