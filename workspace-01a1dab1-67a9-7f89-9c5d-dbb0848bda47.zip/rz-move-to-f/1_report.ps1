# 1_report.ps1
# ------------------------------------------------------------------
#  بيقولك إيه اللي واخد مساحة على C: وإيه اللي يستاهل النقل
#  تشغيله: كليك يمين -> Run with PowerShell   (أو من PowerShell عادي)
#  ما بينقلش ولا بيمسح أي حاجة — قراءة بس.
# ------------------------------------------------------------------

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "   المساحة الفاضية على الدرايفات" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

Get-PSDrive -PSProvider FileSystem |
    Where-Object { $_.Used -ne $null } |
    Select-Object Name,
        @{N='Used_GB'; E={[math]::Round($_.Used/1GB,1)}},
        @{N='Free_GB'; E={[math]::Round($_.Free/1GB,1)}} |
    Format-Table -AutoSize


Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "   فولدرات المشروع — واخدة كام؟" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

$paths = @(
    "C:\RZ",
    "C:\RZ\DBs",
    "C:\RZ\Server",
    "C:\xampp",
    "C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA"
)

foreach ($p in $paths) {
    if (Test-Path $p) {
        $bytes = (Get-ChildItem $p -Recurse -Force -ErrorAction SilentlyContinue |
                  Measure-Object -Property Length -Sum).Sum
        $mb = [math]::Round($bytes / 1MB, 0)
        $gb = [math]::Round($bytes / 1GB, 2)
        Write-Host ("{0,-70} {1,10} MB  ({2} GB)" -f $p, $mb, $gb)
    }
    else {
        Write-Host ("{0,-70} {1}" -f $p, "(مش موجود)")
    }
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "   أكبر 15 ملف على C:\RZ" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

if (Test-Path "C:\RZ") {
    Get-ChildItem "C:\RZ" -Recurse -File -Force -ErrorAction SilentlyContinue |
        Sort-Object Length -Descending |
        Select-Object -First 15 FullName,
            @{N='MB'; E={[math]::Round($_.Length/1MB,0)}} |
        Format-Table -AutoSize
}

Write-Host ""
Write-Host "خلص التقرير. مفيش أي حاجة اتغيرت." -ForegroundColor Green
Write-Host ""
