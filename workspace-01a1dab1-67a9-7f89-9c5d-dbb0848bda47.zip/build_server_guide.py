# -*- coding: utf-8 -*-
"""يبني دليل تسليم سيرفر Rappelz 9.1 (docx عربي RTL)."""
import sys
sys.path.insert(0, "/home/user/rz-level200")
from docx_helpers import (Doc, NAVY, BLUE, RED, GREEN, GREY, WHITE,
                          WD_ALIGN_PARAGRAPH)
from docx.shared import Pt, RGBColor, Cm
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

D = Doc()

GAME_OPT = """S:app.name:Game001
T:auth.server_idx:1
S:auth.server_name:Revolution Official
S:db.c.account:rappelz
S:db.c.name:Arcadia
S:db.c.server:127.0.0.1
S:db.user.account:rappelz
S:db.user.server:127.0.0.1
S:db.user.name:Telecaster1
N:io.port:4514
S:io.auth.ip:127.0.0.1
S:io.ip_address:127.0.0.1
S:log.chat.ip:127.0.0.1
S:log.ip:127.0.0.1
T:log.chat.working:1
T:log.working:0
F:game.exp_rate:42
F:game.ally_pcbang_bonus_rate:0.1
F:game.ally_pcbang_chaos_bonus_rate:0.1
T:game.update.version:24
F:game.gold_drop_rate:50
F:game.item_drop_rate:20
T:game.max_level:180
T:game.PKServer:1
T:game.AdultServer:0
T:game.cash_usable_server:1
N:game.local_flag:8192
T:game.min_global_chat_usable_level:80
T:game.use_auto_trap:0
T:game.use_auto_jail:0
N:CodePage:1256
T:game.ServiceServer:1
N:console.port:65528
S:console.allow_ip:127.0.0.1
S:console._password:455600000300b13015cbe8f4ea6bb5ee979a15b993f8dc9691ed74958a6b950e69c8178b959495640b7d2294b7
S:io.upload.ip:127.0.0.1
S:io.upload.port:4616
S:game.guild_icon_base_url:http://127.0.0.1/guild/
S:game.url_list:guild.url|http://127.0.0.1/login.aspx|guild_test_download.url|guild/|web_download|5.196.124.242|web_download_port|0|shop.url|http://shop.rappelz.co|ghelp_url|http://help.gamepower7.com/help/help-page/help-page.html|guild_icon_upload.ip|5.196.124.242|guild_icon_upload.port|4617

S:game.server_screenshot_url:http://rappelz.co/launcher/server.html
S:game.helpdesk_url:http://help.gamepower7.com/help/help-page/help-page.html
S:game.newbiehelp_asura_url:http://help.gamepower7.com/help/info_asura.html
S:game.newbiehelp_deva_url:http://help.gamepower7.com/help/info_deva.html
S:game.newbiehelp_gaia_url:http://help.gamepower7.com/help/info_gaia.html
S:game.local_setting_list:log.ip|log.chat.ip|io.auth.ip|io.ip_address|db.c.server|db.user.server|N game.periodical_npc_adjustment
T:game.disable_trade:0
T:game.disable_booth:0
T:game.enhance_fail_type:2
T:game.monster_pathfinding:1
T:game.monster_wandering:1
T:game.no_collision_check:0
T:game.no_skill_cooltime:0
N:game.item_hold_time:2500
T:db.user.thread:4"""

# ---------------------------------------------------------------- الغلاف
D.p("", space_after=2)
D.rich([("سيرفر Rappelz 9.1  —  Revolution Files", True, NAVY)], size=22,
       align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
D.rich([("دليل التشغيل الكامل + الحالة الحالية + المتبقي", False, BLUE)], size=14,
       align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
D.rich([("ملف تسليم (Handover) — يُعطى لأي شخص أو وكيل ذكاء اصطناعي يكمل الشغل",
         False, GREY)], size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
D.rich([("تاريخ التحديث: 12 نوفمبر 2026  •  جهاز: DESKTOP-ICC037B (Mena)", False, GREY)],
       size=9.5, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=10)

D.callout("الخلاصة في خمس سطور",
          "السيرفر الآن يعمل: قاعدة البيانات + Auth Server + Game Server، والاثنان متصلان ببعض، "
          "واللعبة جاهزة لاستقبال أكاونت. المفتاح الذي كان مفقوداً: ملف GameServer.opt لا يقرأه "
          "البرنامج مباشرة، بل يجب تحويله بـ RappelzCompress.exe إلى GameServer.eop. "
          "المتبقي: تشغيل LogServer و UploadServer، إنشاء أكاونت، تثبيت الكلاينت وتوجيهه إلى 127.0.0.1، "
          "ثم ضبط الرِيتس وإغلاق ثغرة أمنية في SQL.")

# ---------------------------------------------------------------- 1
D.h1("1", "حالة النظام الآن — ما يعمل وما لا يعمل")
D.table(
    ["المكوّن", "الحالة", "الملاحظة / الدليل"],
    [["SQL Server 2019 (MSSQLSERVER)", "يعمل", "منفذ 1433 يستمع على 0.0.0.0 — نسخة 15.0.x"],
     ["Auth Server (PrincessAuroraServer.exe)", "يعمل", "start db initializing... ok  ✓"],
     ["Game Server (CaptainHerlockServer.exe)", "يعمل", "Acceptor initialize... ok (0.0.0.0:4514)  ✓"],
     ["ارتباط Game → Auth", "يعمل", "Game Server Login: IP 127.0.0.1(4514) Name: Revolution Official Index 1"],
     ["Log Server (LogServer.exe)", "لا يعمل", "cannot connect log server: ip 127.0.0.1, port 4516"],
     ["Upload Server (UploadServer.exe)", "لا يعمل", "Connect To Upload... failed — PORT 4616"],
     ["كلاينت Rappelz 9.1", "غير مثبت", "المثبّت موجود على F: وينتظر التثبيت"],
     ["أكاونت للاعب", "غير موجود", "لم يُنشأ بعد في قاعدة Auth"]],
    widths=[6.2, 2.4, 8.4], size=9.5)

D.h2("نص شاشة Auth Server (مرجعي)")
D.code("""Network initialize... ok
IOCP initialize... ok
Starting IOCP thread pool... ok
IOCP initialize... ok
Starting IOCP thread pool... ok
cannot connect log server: ip: 127.0.0.1, port: 4516
start db initializing... ok
Game server acceptor initialize... ok
Adding game server acceptor to IOCP... ok
Game Server Login: IP: 127.0.0.1(4514) Name : Revolution Official Index 1
cannot connect log server: ip: 127.0.0.1, port: 4516""")

D.h2("نص شاشة Game Server (مرجعي — آخر السطور هي المهمة)")
D.code("""...
Total 580 Title Condition table loaded...
Lua run script failed. mob( 1002 167538,53382,169050,54432):1: ')' expected near '167538'
Event state added successfully.
Connect To Auth... ok
Adding auth connection to IOCP... ok
Setting a ranking data: id(1), tCurrent(1794779944), tNextSetting(1427839200 -> 1796076000 = 2026-12-01 00:00:00)
Connect To Upload... failed
Connecting to the upload server failed. Check upload server status. IP: 127.0.0.1 / PORT: 4616
Enter 'connect upload' to retry.
Acceptor initialize... ok(IP: 0.0.0.0, Port: 4514)
Adding acceptor to IOCP... ok""")

# ---------------------------------------------------------------- 2
D.pagebreak()
D.h1("2", "المواصفات الفنية (كل الأرقام والمسارات)")

D.h2("المنافذ (Ports)")
D.table(["المنفذ", "الخدمة", "المصدر (من أي ملف)"],
        [["1433", "SQL Server", "إعدادات SQL Server — TCP/IP"],
         ["1996", "دخول اللاعبين (Client → Auth)", "authserver.opt → io.auth.port"],
         ["1995", "كونسول الأوامر في Auth", "authserver.opt → console.port"],
         ["4514", "اتصال الـ Game بـ Auth واستقبال اللاعبين", "GameServer.opt → io.port"],
         ["4516", "Log Server", "log.ip / log.chat.ip — برنامج LogServer.exe"],
         ["4616", "Upload Server (صور الجيلد/server list)", "GameServer.opt → io.upload.port"],
         ["65528", "كونسول Game Server", "GameServer.opt → console.port"]],
        widths=[1.8, 6.6, 8.6])

D.h2("قواعد البيانات")
D.table(["الاسم", "الوظيفة", "الحالة"],
        [["Auth", "حسابات اللاعبين (tuser) — مطلوبة لتسجيل الدخول", "ONLINE"],
         ["Telecaster1", "بيانات الحسابات/الشخصيات (user DB) — نسخة من Telecaster", "ONLINE"],
         ["Arcadia", "بيانات اللعبة والموارد (Resource tables)", "ONLINE"],
         ["BILLING", "الدفع/الكاش", "ONLINE"]],
        widths=[3.0, 10.4, 3.6])

D.h2("بيانات الدخول الحالية")
D.table(["الحساب", "كلمة المرور", "الصلاحية", "مستخدم في"],
        [["rappelz", "فارغة (عمداً)", "sysadmin", "Auth Server + Game Server (عبر db.*._password الفارغ)"],
         ["sa", "Ahmed@7710", "sysadmin", "غير مستخدم — للطوارئ فقط"]],
        widths=[2.4, 3.4, 2.6, 8.6])

D.callout("لماذا كلمة المرور فارغة؟ (مهم جداً — لا «تصلحها»)",
          "السيرفران (Auth و Game) لا يقرأان db.auth.password / db.user.password النصية، بل يقرأان "
          "db.*._password المشفّرة، وهي غير موجودة عندنا فتكون فارغة. لذلك يرسلان كلمة مرور فارغة إلى SQL. "
          "أي محاولة لوضع كلمة مرور في ملف الـ opt ستُتجاهل، والدخول سيفشل. الحل الحالي — حساب SQL بكلمة "
          "مرور فارغة — هو ما جعل الاتصال ينجح فعلياً. الحل الأنظف لاحقاً: توليد قيمة مشفّرة صحيحة لـ "
          "db.*._password (غير ضروري الآن).",
          fill="FFF4E5", bar="C55A11", title_color=RGBColor(0x8A, 0x3D, 0x00))

D.h2("شجرة المسارات على الجهاز")
D.code(r"""C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\
   |-- Auth_bin\      PrincessAuroraServer.exe   UploadServer.exe
   |                  authserver.opt             RappelzCompress_v2.exe
   |                  Log\   (مخرجات)
   |-- Game_bin\      CaptainHerlockServer.exe   GameServer.opt
   |                  GameServer.eop  <== الملف السحري (مضغوط من .opt)
   |                  RappelzCompress.exe        EOPUpdater.exe + EOPUpdater.opt
   |                  Log\  GameLog.txt
   |-- Log_bin\       LogServer.exe
   |-- Server_Launcher\  ServerLauncher.exe (+ _x64)  ServerLauncher.opt
   |-- DBupdater\     DBUpdater.exe  dbupdater.eop  + مجلد RDU

C:\RZ\DBs\            Arcadia.bak  Telecaster.bak  Billing.bak  Auth.bak
C:\RZ\Server\GameEngine\   <== مجلد فارغ دخيل — تجاهله تماماً""")

D.h2("الكلاينت")
D.table(["البند", "القيمة"],
        [["ملفات التثبيت", "F:\\...\\rappelz server\\Client\\  →  Rappelz_Setup_9.1.exe + .2 + .3 + .4"],
         ["طريقة التثبيت", "شغّل الـ .exe الأول فقط (بقية الأجزاء تُقرأ تلقائياً) وثبّت في  F:\\RZ\\Client"],
         ["تشغيل الكلاينت", "RappelzCmdLauncher.exe sframe.exe /auth_ip:127.0.0.1 /use_nprotect:0 /locale:Windows-1256 /country:ME ..."],
         ["تعطيل GameGuard", "المعامل /use_nprotect:0 (مذكور في ملف الباكدج: how to delete gg and use.txt)"]],
        widths=[3.4, 13.6])

# ---------------------------------------------------------------- 3
D.pagebreak()
D.h1("3", "الملفات الحاكمة — القاعدة الذهبية")

D.callout("القاعدة رقم 1 في هذا السيرفر",
          "أي تعديل في GameServer.opt لا يصل إلى السيرفر إلا بعد تحويله إلى GameServer.eop بواسطة "
          "RappelzCompress.exe (اسحب ملف .opt وأفلته فوق أيقونة RappelzCompress.exe). البرنامج يقرأ "
          ".eop فقط. هذا هو سبب ضياع أكثر من 6 ساعات عمل في محاولات تعديل الـ opt.",
          fill="E8F5E9", bar="2E7D32", title_color=RGBColor(0x1B, 0x5E, 0x20))

D.h2("محتوى GameServer.opt الحالي (النسخة العاملة — منسوخ بالبايت)")
D.p("ملاحظة: محفوظ بترميز ANSI وسطور CRLF وحجمه 2108 بايت بالظبط. أي تعديل يجب أن يحافظ على الترميز.", size=9.5, color=GREY)
D.code(GAME_OPT)

D.h2("مفاتيح authserver.opt العاملة")
D.table(["المفتاح", "القيمة", "ملاحظة"],
        [["db.auth.server / db.billing.server", "127.0.0.1", "—"],
         ["db.auth.name", "Auth", "—"],
         ["db.billing.name", "BILLING", "—"],
         ["db.auth.account / db.billing.account", "rappelz", "الحساب بكلمة مرور فارغة"],
         ["db.auth.use_md5", "1", "لا تغيّره إلا إذا كنت تعرف ما تفعل"],
         ["db.auth.md5_key", "A4&8zx209z&8zx267Ope", "⛔ ممنوع تغييره"],
         ["io.auth.port", "1996", "منفذ دخول اللاعبين"],
         ["console.port", "1995", "منفذ الكونسول"],
         ["console._password", "4556000003008f15...", "⛔ ممنوع تغييره (كلمة مرور كونسول Auth)"],
         ["billing.use", "1", "لو رفض الدخول بسبب الفاتورة اجعلها 0"],
         ["billing.allow_login_without_billing", "1", "تسمح بالدخول بدون حساب دفع"]],
        widths=[6.4, 4.6, 4.4])

D.callout("مفاتيح ممنوعة نهائياً",
          "console._password (في authserver.opt و GameServer.opt) و db.*.md5_key. تغييرها يفصل الكونسول "
          "أو يكسر تشفير كلمات المرور، ولن تستطيع الرجوع بسهولة.")

# ---------------------------------------------------------------- 4
D.pagebreak()
D.h1("4", "المشاكل الجذرية التي واجهناها — وكيف حُلّت")
D.p("هذا القسم هو أهم ما يجب أن يعرفه أي شخص يكمل العمل: كل مشكلة هنا استهلكت وقتاً، وسببها الحقيقي "
    "كان مخالفاً للظاهر.", size=10.5)

D.table(["#", "العَرَض", "السبب الحقيقي", "الحل الذي نجح"],
        [["1", "ملفات سيرفر قديمة/ناقصة", "الباكدج المُنزَّل أول مرة كان Revolution 7.2 وليس 9.1",
          "تحميل باكدج 9.1 الصحيح (144,010,622 بايت — md5 يبدأ بـ 4974932…)"],
         ["2", "SSMS 22 لا يتثبت", "«Operating system not supported»",
          "استخدام SSMS 19.3 (fwlink/?linkid=2257624)"],
         ["3", "Restore من واجهة SSMS يفشل بصمت", "مشكلة في واجهة الاستعادة مع هذا الـ .bak",
          "سكربت RESTORE … WITH MOVE بالأسماء المنطقية الصحيحة: Telecaster_New_Data / Telecaster_New_Log"],
         ["4", "Msg 8985 في DBCC SHRINKFILE", "تنفيذ الأمر على master",
          "USE [Telecaster1] قبل الأمر"],
         ["5", "Auth: Login failed … Password did not match", "السيرفر يرسل كلمة مرور فارغة (db.auth._password فارغ) وليس ما في db.auth.password",
          "إنشاء حساب SQL اسمه rappelz بكلمة مرور فارغة + sysadmin"],
         ["6", "Game crash: ACCESS_VIOLATION C0000005 في DB_OnStartUp", "فشل الاتصال بقاعدة البيانات → مؤشر فارغ",
          "تصحيح إعدادات قاعدة البيانات (لكنه لم يكن كافياً — انظر #7)"],
         ["7", "كل القيم في Environment dump ترجع للافتراضي (cadb.nflavor.com, exp_rate 1.0, item_hold_time 180000)", "البرنامج لا يقرأ GameServer.opt إطلاقاً — يقرأ GameServer.eop المضغوط، الذي لم يكن موجوداً في الباكدج",
          "سحب GameServer.opt وإفلاته على RappelzCompress.exe → إنشاء GameServer.eop → السيرفر عمل"]],
        widths=[0.9, 4.6, 6.0, 6.0], size=9)

D.h2("مسارات خاطئة سلكناها — لا تعيدها")
D.bullet("Run as administrator: يغيّر مجلد العمل إلى C:\\Windows\\System32، فيضيع على البرنامج ملف الـ opt. الأفضل: التشغيل من داخل المجلد (cmd أو دبل كليك عادي).")
D.bullet("تعديل GameServer.opt بدون إعادة ضغط: لا أثر له مهما كان صحيحاً.")
D.bullet("إضافة أسطر db.c.password / db.user.password في الـ opt: البرنامج يتجاهلها، والأصل أن تُحذف.")
D.bullet("سكربتات .ps1 أو .bat: تُغلق فوراً على جهاز المستخدم ولا تُستخدم. كل الخطوات تُنفَّذ يدوياً (Notepad / SSMS / Explorer).")
D.bullet("الدخول إلى SSMS بحساب rappelz: مستحيل لأن كلمته فارغة و SSMS يرفض الحقل الفارغ. استخدم Windows Authentication دائماً.")

# ---------------------------------------------------------------- 5
D.pagebreak()
D.h1("5", "Runbook — تشغيل السيرفر من الصفر (بالترتيب)")

D.num(1, "SQL Server: تأكد أن الخدمة تعمل (Services → SQL Server (MSSQLSERVER) → Running).")
D.num(2, "افتح SSMS بـ Windows Authentication وتأكد أن القواعد الأربع ONLINE: Auth · Telecaster1 · Arcadia · BILLING.")
D.num(3, "لو عدّلت GameServer.opt: اسحب الملف وأفلته فوق RappelzCompress.exe داخل Game_bin، وتأكد من ظهور/تحديث GameServer.eop.")
D.num(4, "شغّل LogServer.exe من داخل مجلد Log_bin (اختياري لكنه يمنع رسائل الخطأ الحمراء).")
D.num(5, "شغّل PrincessAuroraServer.exe من داخل مجلد Auth_bin — انتظر حتى تظهر: start db initializing... ok")
D.num(6, "شغّل CaptainHerlockServer.exe من داخل مجلد Game_bin — انتظر حتى تظهر: Adding acceptor to IOCP... ok")
D.num(7, "شغّل UploadServer.exe من داخل Auth_bin (اختياري — لصور الجيلد وقائمة السيرفرات).")
D.num(8, "في كونسول Auth اكتب: start_service ثم Enter — ليبدأ استقبال اللاعبين.")
D.num(9, "شغّل الكلاينت عبر RappelzCmdLauncher مع /auth_ip:127.0.0.1 وسجّل الدخول.")
D.spacer(4)
D.callout("ترتيب إجباري",
          "Auth قبل Game. ولو أُعيد تشغيل خدمة SQL لأي سبب: أغلق السيرفرين وأعد تشغيلهما بنفس الترتيب — "
          "وإلا سيبقيان عالقين على اتصال ميت.")

# ---------------------------------------------------------------- 6
D.pagebreak()
D.h1("6", "المتبقي — خطوات دقيقة (To-Do)")

D.h2("6.1  Log Server (يزيل رسالة port 4516)")
D.num(1, "افتح المجلد ...\\GameEngine\\Log_bin")
D.num(2, "شغّل LogServer.exe (دبل كليك من داخل المجلد)")
D.num(3, "النتيجة المتوقعة: تختفي رسالة cannot connect log server من كونسول Auth والـ Game.")

D.h2("6.2  Upload Server (يزيل رسالة port 4616)")
D.num(1, "افتح ...\\GameEngine\\Auth_bin")
D.num(2, "شغّل UploadServer.exe")
D.num(3, "في كونسول الـ Game اكتب: connect upload — أو أعد تشغيل الـ Game وسيتصل تلقائياً.")

D.h2("6.3  إنشاء أكاونت لاعب")
D.p("لا يوجد أداة تسجيل في الباكدج، فالحساب يُنشأ مباشرة في قاعدة Auth. اتبع الترتيب:", size=10.5)
D.num(1, "في SSMS (Windows Authentication) افتح New Query ونفّذ للاستكشاف:")
D.code("""USE [Auth];
SELECT TOP 5 * FROM dbo.tuser;      -- شكل الصفوف الموجودة (لو فيه أي صف)
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'tuser';""")
D.num(2, "لو لم توجد صفوف، انسخ هيكل الأعمدة كما هو. أنواع الأعمدة تحدد صيغة الباسورد:")
D.table(["نوع عمود password", "الصيغة المطلوبة", "مثال INSERT"],
        [["varchar / nvarchar", "نص عادي (مع db.auth.use_md5 = 0)",
          "INSERT INTO dbo.tuser (id,password,email,authority) VALUES ('test','test','a@a.com',0);"],
         ["varbinary / binary", "MD5",
          "INSERT INTO dbo.tuser (id,password,email,authority) VALUES ('test',HASHBYTES('MD5','test'),'a@a.com',0);"]],
        widths=[3.6, 4.8, 9.2], size=9)
D.num(3, "أعد تشغيل Auth Server ثم جرّب الدخول من الكلاينت. لو رفض الدخول:")
D.bullet("راجع كونسول Auth — يطبع سبب الرفض (كلمة مرور/حساب/باندويدث).")
D.bullet("لو الرسالة متعلقة بالـ billing: في authserver.opt اجعل N:billing.use:0 وأعد التشغيل.")
D.bullet("لو الرسالة password mismatch: فك تشفير المتوقع بأن تجعل N:db.auth.use_md5:0 وتخزّن النص كما هو.")
D.callout("تحذير",
          "عمود authority / الخصائص الأخرى قد تكون إلزامية (NOT NULL بدون default). في هذه الحالة انسخ صفاً "
          "من قاعدة Auth المرفقة إن وُجد، أو املأ الأعمدة الإلزامية فقط. لا تخمّن — اعتمد على رسالة الخطأ من SQL.",
          fill="FFF4E5", bar="C55A11", title_color=RGBColor(0x8A, 0x3D, 0x00))

D.h2("6.4  تثبيت الكلاينت وتوجيهه")
D.num(1, "ثبّت الكلاينت من Rappelz_Setup_9.1.exe (بقية الأجزاء .2/.3/.4 في نفس المجلد) إلى F:\\RZ\\Client.")
D.num(2, "انسخ RappelzCmdLauncher.exe من مجلد Launcher داخل الباكدج إلى مجلد الكلاينت.")
D.num(3, "أنشئ ملف Revolution Launcher.bat بجواره بالمحتوى التالي (المصدر: الباكدج نفسه):")
D.code("RappelzCmdLauncher.exe sframe.exe /auth_ip:127.0.0.1 /use_nprotect:0 /help_url_w:611 "
       "/help_url_h:625 /locale:Windows-1256 /country:ME /cash /commercial_shop /layout_dir:6 "
       "/layout_auto:0 /cash_url_w:800 /cash_url_h:631")
D.num(4, "شغّل الـ bat وسجّل الدخول بالحساب المنشأ.")
D.p("ملاحظة: /use_nprotect:0 يعطّل GameGuard (من ملف how to delete gg and use.txt داخل الباكدج). "
    "/locale:Windows-1256 و /country:ME هما إعداد اللغة العربية لمنطقة الشرق الأوسط، ومتوافقة مع "
    "CodePage:1256 في GameServer.opt.", size=9.5, color=GREY)

D.h2("6.5  تعديل الرِيتس ومستوى اللاعب")
D.table(["ما تريده", "المفتاح في GameServer.opt", "القيمة الحالية"],
        [["مضاعف الخبرة", "F:game.exp_rate", "42"],
         ["مضاعف الجولد", "F:game.gold_drop_rate", "50"],
         ["نسبة سقوط الأدوات", "F:game.item_drop_rate", "20"],
         ["أقصى مستوى", "T:game.max_level", "180"],
         ["زمن بقاء الأيتم على الأرض (ملي ثانية)", "N:game.item_hold_time", "2500"]],
        widths=[5.4, 6.2, 5.4])
D.p("بعد أي تعديل: حفظ الملف (ANSI) → سحبه على RappelzCompress.exe → إعادة تشغيل الـ Game Server. "
    "بدون هذه الخطوة لن يتغير شيء على الإطلاق.", size=10, color=RED)

D.h2("6.6  الأمان (يجب قبل أي فتح للإنترنت)")
D.bullet("منفذ 1433 مفتوح على 0.0.0.0 وحساب sa وصلاحيته sysadmin — خطر مباشر على السيرفر.")
D.bullet("الحل الفوري: في SQL Server Configuration Manager → Protocols → TCP/IP → IPAll → احذف 1433 من TCP Port، أو أوقف الاستماع الخارجي.")
D.bullet("أو استخدم Windows Firewall: منع 1433 من الخارج مع السماح لـ 127.0.0.1.")
D.bullet("اكتب كلمة مرور قوية لحساب sa، ولا تعرّض السيرفر للإنترنت قبل ذلك.")
D.bullet("حساب rappelz بكلمة مرور فارغة مقبول محلياً فقط — لا يُستخدم من خارج الجهاز.")

D.h2("6.7  أخطاء Lua (تجميلية)")
D.p("في كونسول الـ Game تظهر أسطر مثل:  Lua run script failed. mob( 1002 167538,53382,169050,54432):1: ')' expected near '167538'", size=10)
D.bullet("المعنى: سكربتات توليد الوحوش في Resource\\Script فيها مشكلة صياغة (فواصل بدل أقواس).")
D.bullet("الأثر: بعض مجموعات الوحوش قد لا تُولَّد في مناطق محددة. لا يمنع الدخول أو اللعب العادي.")
D.bullet("الحل لاحقاً: استبدال مجلد Script بنسخة سليمة، أو صياغة الأسطر على شكل mob(id, x, y, ...).")

# ---------------------------------------------------------------- 7
D.pagebreak()
D.h1("7", "جدول الأخطاء ومعانيها")
D.table(["الرسالة", "المعنى", "التصرف"],
        [["DB COM ERROR … 80040E4D … Invalid authorization specification",
          "بيانات دخول قاعدة البيانات مرفوضة (اسم/كلمة مرور/سيرفر)",
          "راجع .opt ثم أعد الضغط إلى .eop"],
         ["Login failed for user 'X'. Reason: Password did not match",
          "SQL رفض كلمة المرور — يظهر في xp_readerrorlog",
          "طابق كلمة المرور: الحل الحالي حساب بكلمة فارغة"],
         ["Exception C0000005 في ?callStartupHandler@DB_OnStartUp",
          "انهيار بعد فشل الاتصال بقاعدة البيانات",
          "أصلح إعدادات الـ DB (وليس الذاكرة)"],
         ["cannot connect log server: ip 127.0.0.1, port 4516",
          "LogServer.exe لا يعمل",
          "شغّل Log_bin\\LogServer.exe"],
         ["Connect To Upload... failed … PORT 4616",
          "UploadServer.exe لا يعمل",
          "شغّل Auth_bin\\UploadServer.exe ثم connect upload"],
         ["Lua run script failed … ')' expected near",
          "خطأ صياغة في سكربتات الوحوش",
          "تجميلي — استبدل مجلد Script لاحقاً"],
         ["Operating system not supported (SSMS 22)",
          "SSMS 22 لا يدعم نسخة ويندوز هذه",
          "استخدم SSMS 19.3"],
         ["Msg 8985 … could not locate file",
          "أمر إدارة ملفات نُفّذ على master",
          "نفّذ USE [اسم_القاعدة] أولاً"]],
        widths=[5.6, 5.4, 6.0], size=9)

# ---------------------------------------------------------------- 8
D.h1("8", "قواعد ذهبية للوكيل الذي يكمل العمل")
D.num(1, "لا ترسل سكربتات .ps1 أو .bat — تُغلق فوراً على جهاز المستخدم. الشرح يكون خطوة بخطوة يدوياً.")
D.num(2, "لا تفترض أن تعديل ملف .opt يعمل — الأصل هو .eop، وأي دليل يجب أن يُقرأ من Environment dump أو الكونسول.")
D.num(3, "أي تشخيص يجب أن يقوم على دليل: Environment dump في ملف الـ dump النصي (.txt) يعرض كل قيمة فعلية.")
D.num(4, "قبل أي تشغيل تأكد أن وقت تعديل الملف أقدم من وقت التشغيل، وإلا فأنت تختبر نسخة قديمة.")
D.num(5, "SSMS دائماً بـ Windows Authentication.")
D.num(6, "بعد أي إعادة تشغيل لخدمة SQL: أعد تشغيل Auth ثم Game.")
D.num(7, "لا تلمس console._password ولا db.*.md5_key.")
D.num(8, "شرح المستخدم بالعربية المصرية، خطوة واحدة في كل مرة، مع نهاية واضحة لما يجب فعله.")

# ---------------------------------------------------------------- 9
D.h1("9", "ملفات المشروع الجاهزة")
D.table(["الملف", "المحتوى"],
        [["rappelz-guide-v2.html", "دليل التثبيت الكامل (HTML) + تحذيرات SSMS والمساحات"],
         ["rz-setup-checklist.docx", "قائمة تثبيت مطبوعة خطوة بخطوة"],
         ["rz-telecaster/restore_telecaster1.sql", "سكربت استرجاع قاعدة Telecaster1 (نُفّذ بنجاح)"],
         ["rz-level200/", "مشروع رفع المستوى إلى 200 + منطقة فارم Rondo + دليل عربي"],
         ["rappelz-real-reference.xlsx", "مرجع الجداول والقيم الحقيقية"],
         ["rz-opt/GameServer.opt.FIXED.txt", "نسخة نظيفة من GameServer.opt (نفس محتوى القسم 3)"]],
        widths=[6.2, 10.8])

D.h1("10", "نقاط مفتوحة تحتاج تأكيداً")
D.bullet("مخطط جدول tuser الحقيقي (أعمدة إلزامية / نوع كلمة المرور) — يُحدد من الاستعلام في 6.3.")
D.bullet("هل يحتاج الدخول صفاً في قاعدة BILLING؟ (اختبر أولاً بـ billing.use:1 ثم 0 عند الرفض).")
D.bullet("توليد قيمة مشفّرة صحيحة لـ db.*._password لاحقاً لاستخدام كلمة مرور حقيقية بدل الفارغة.")
D.bullet("إصلاح سكربتات Lua لمناطق الوحوش.")

D.p("", space_after=2)
D.rich([("نهاية الدليل — أي تعديل في الإعدادات يتطلب دائماً: حفظ الـ opt ← ضغطه بـ RappelzCompress ← إعادة تشغيل السيرفر.",
         False, GREY)], size=9, align=WD_ALIGN_PARAGRAPH.CENTER)

D.save("/home/user/rz-server-handover-guide.docx")
print("OK")
