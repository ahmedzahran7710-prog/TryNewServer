--[[ ============================================================
     سكربت "فك الختم" — خاتم يطلع بخصائص عشوائية
     اقرا التعليقات كلها قبل ما تشغّله
     ============================================================ ]]

function get_module_name()
    return "my_ring_unseal"
end

-- ================== الإعدادات (غيّر الأرقام دي) ==================
local SEALED_RING = 910001              -- رقم الخاتم المقفول (اللي بيتوزّع للاعبين)
local RING_VARIANTS = {                 -- 6 نسخ مختلفة (كل نسخة صف في ItemResource)
    910002, 910003, 910004, 910005, 910006, 910007
}
-- نصوص جاهزة موجودة في الكلاينت (بنعيد استخدامها عشان مفيش تعديل كلاينت)
local TXT_TITLE   = "@90702501"         -- عنوان نافذة الحوار
local TXT_PICK    = "@90606096"         -- "اختر الأداة"
local TXT_NOTHING = "@90606097"         -- "مفيش أداة"
local TXT_CLOSE   = "@90010002"         -- "إغلاق"

-- ================== التشغيل ==================
function NPC_Unseal_init()
    cprint("!Unseal NPC ready")         -- رسالة في الكونسول للتأكد
    set_npc_name("@90702500")
end

-- ================== الحوار ==================
function NPC_Unseal_contact()
    dlg_title(TXT_TITLE)
    dlg_text(TXT_PICK)

    local found = 0
    for i = 0, 7 do                                  -- 8 خانات اللبس
        local h = get_wear_item_handle(i)
        if h ~= nil and h ~= 0 then
            if get_item_code(h) == SEALED_RING then
                found = found + 1
                -- خيار في القائمة ينفّذ فك الختم على الأداة دي
                dlg_menu(TXT_PICK, "do_unseal( " .. h .. " )")
            end
        end
    end

    if found == 0 then
        dlg_text(TXT_NOTHING)
    end

    dlg_menu(TXT_CLOSE, "")
    dlg_show()
end

-- ================== فك الختم ==================
function do_unseal(handle)
    -- تأكيد إن الأداة لسه هي نفسها (ممكن اللاعب يغيّر اللبس)
    if get_item_code(handle) ~= SEALED_RING then
        return
    end

    -- اختيار عشوائي آمن (بنحمي نفسنا من نطاق random())
    local idx = random(#RING_VARIANTS) + 1
    if idx < 1 then idx = 1 end
    if idx > #RING_VARIANTS then idx = #RING_VARIANTS end

    -- تحويل الأداة إلى النسخة العشوائية (الخصائص بتيجي من صف الأداة نفسه)
    change_item_code(handle, RING_VARIANTS[idx])

    cprint("unseal -> variant " .. tostring(idx))
end

--[[ ============================================================
     ملاحظات مهمة:
     1) الوظائف المستخدمة هنا موجودة فعلاً في سكربتات اللعبة الأصلية
        (change_item_code / get_item_code / get_wear_item_handle / random)
        — شوف NPC_ItemUP.lua لو عايز أمثلة أكثر.
     2) عايز خصائص "أكتر عشوائية" ومش مجرد 6 نسخ؟
        زوّد نسخ في RING_VARIANTS، أو استخدم:
            set_item_random_option( handle, 1, type, subtype, value )
        (شوف نفس الملف NPC_ItemUP.lua بيتستخدمها فعلاً).
     3) ربط الـ NPC بخريطة: لازم NPC id + سباون. أسهل بداية:
        اربط المنطق ده بـ NPC موجود بالفعل (زي الحداد) بدل إنشاء NPC جديد.
     4) تحذير: لو ظهر في اللوج
        "lua script file load failed" يبقى فيه خطأ في الصياغة —
        راجع الملف ورجّع النسخة القديمة فوراً.
     ============================================================ ]]
