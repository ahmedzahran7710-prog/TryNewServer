دليل تسطيب وتشغيل سيرفر أمل الشعوب (Rappelz 9.1) — من الصفر
=================================================================

الملفات اللي في الفولدر ده = "العدة" بتاعتك. اقرا ملف الدليل (rappelz-guide.html)
قبل ما تفتح أي حاجة، لأن كل خطوة مشروحة هناك بالتفصيل.

المحتوى:
  configs\authserver.opt    ← نسخة جاهزة للتعديل (حطها مكان ملف الحزمة)
  configs\GameServer.opt    ← نفس الشيء
  configs\ServerLauncher.opt ← عدّل مسارات C:\RZ لو حطيت السيرفر في مكان تاني
  launcher\Start-Client.bat        ← لتشغيل اللعبة على جهازك (127.0.0.1)
  launcher\Start-Client-Online.bat ← لللعب مع أصحابك (غيّر YOUR_IP)
  sql\00_check_databases.sql  ← تأكد إن القواعد اتعملها Restore
  sql\01_check_account_table.sql ← شوف شكل جدول الحسابات
  sql\02_create_account.sql   ← إنشاء حساب بطريقة SQL
  website\config.php + register.php + index.php ← موقع تسجيل بسيط (XAMPP)

القيم اللي لازم تغيّرها قبل أي حاجة:
  YOUR_SA_PASSWORD   = الباسورد اللي هتحطه لـ sa وقت تثبيت SQL Server
  YOUR_IP            = IP بتاعك (127.0.0.1 للتجربة المحلية)

مفتاح تشفير الباسوردات (موجود في authserver.opt):
  A4&8zx209z&8zx267Ope
  لو غيّرته، لازم تغيّره في كل حاجة (السيرفر + الموقع + أي أداة) قبل إنشاء الحسابات.

مهم: اقرا قسم "الأخطاء الشائعة" في الدليل قبل ما تتوتر من أي رسالة خطأ.
