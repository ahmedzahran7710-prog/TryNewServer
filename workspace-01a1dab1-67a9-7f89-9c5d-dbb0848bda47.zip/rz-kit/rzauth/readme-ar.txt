rzauth v6.5 - بديل سيرفر الدخول (Auth) لملفات Revolution 9.1
=====================================================
المحتوى:
  rzauth.exe, rzu.dll, libcrypto-1_1-x64.dll, libssl-1_1-x64.dll
  auth.opt   (إعدادات جاهزة على قاعدة Auth وجدول dbo.Accounts)
  rzauth_user_guide.md (دليل رسمي)

طريقة التشغيل:
 1) اقفل PrincessAuroraServer.exe و UploadServer.exe خالص.
 2) شغّل rzauth.exe من الفولدر ده (دبل كليك) - هيشتغل في نافذة كونسول.
 3) راجع السطور: لازم يقول إنه سمع على 1996 للعملاء و 4502 للسيرفرات.
 4) شغّل CaptainHerlockServer.exe (لازم يتصل بالـ Auth من جديد).
 5) من الكلينت: test2 / test123

ملاحظات:
 - الباسورد في auth.opt محسوب بطريقة md5(salt+password) والـ salt هو
   A4&8zx209z&8zx267Ope ، وعشان كده الحساب الجاهز هو test2 / test123
 - لو الحساب أو الباسورد مش عاجبك، عدّل auth.db.salt أو ضيف حساب جديد.
 - لو قاعدة البيانات مش اتصلت: استخدم سطر auth.db.connectionstring الموجود
   كتعليق في auth.opt.
 - لو احتجت تشوف الباكيتات اللي جاية من الكلينت: خلي trafficdump.enable:true
