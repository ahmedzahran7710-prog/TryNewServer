/* ============================================================
   1) استكشاف — شغّل ده الأول وشوف الدنيا شكلها إيه
   قاعدة اللعبة اسمها Arcadia
   ============================================================ */
USE Arcadia;
GO

/* (أ) كل الخواتم الموجودة — الأيقونة بتوريك الشكل */
SELECT id, name_id, icon_file_name, level, use_min_level, socket, enhance, enhance_id,
       base_type_0, base_var1_0, base_var2_0,
       base_type_1, base_var1_1, base_var2_1,
       base_type_2, base_var1_2, base_var2_2,
       base_type_3, base_var1_3, base_var2_3,
       opt_type_0,  opt_var1_0,  opt_var2_0,
       opt_type_1,  opt_var1_1,  opt_var2_1
FROM dbo.ItemResource
WHERE icon_file_name LIKE 'icon_ring%'
ORDER BY level DESC;
GO

/* (ب) أكواد الخصائص المستخدمة في الخواتم وقيمها — ده اللي هتعرف منه
       كود الحيوية/القوة/الرشاقة/البراعة (قارن بخاتم انت عارفه في اللعبة) */
SELECT base_type_0 AS stat_code, COUNT(*) AS used_by_rings,
       MIN(base_var1_0) AS min_value, MAX(base_var1_0) AS max_value
FROM dbo.ItemResource
WHERE icon_file_name LIKE 'icon_ring%'
GROUP BY base_type_0
ORDER BY COUNT(*) DESC;
GO

/* (ج) أكواد الأوبشن (الخصائص الإضافية) */
SELECT opt_type_0 AS opt_code, COUNT(*) AS used_by_rings,
       MIN(opt_var1_0) AS min_value, MAX(opt_var1_0) AS max_value
FROM dbo.ItemResource
WHERE icon_file_name LIKE 'icon_ring%' AND opt_type_0 <> 0
GROUP BY opt_type_0
ORDER BY COUNT(*) DESC;
GO

/* (د) جداول الأنظمة الخاصة (عشان تعرف اللي موجود عندك فعلاً) */
SELECT name FROM sys.tables
WHERE name LIKE '%Random%' OR name LIKE '%Awaken%' OR name LIKE '%Enhance%'
ORDER BY name;
GO
