/* ============================================================
   2) نُسخة من خاتم موجود برقم جديد
   غير السطرين اللي تحت بس: @src (الخاتم الأصلي) و @new (رقمك الجديد)
   ============================================================ */
USE Arcadia;
GO
SET NOCOUNT ON;

DECLARE @src INT = 4444;      -- ← رقم الخاتم اللي عاجبك شكله
DECLARE @new INT = 910001;    -- ← رقم الخاتم الجديد (استخدم نطاق 910000+ عشان مفيش تعارض)

IF EXISTS (SELECT 1 FROM dbo.ItemResource WHERE id = @new)
BEGIN
    RAISERROR('الرقم %d مستخدم بالفعل — اختار رقم تاني', 16, 1, @new);
    RETURN;
END
IF NOT EXISTS (SELECT 1 FROM dbo.ItemResource WHERE id = @src)
BEGIN
    RAISERROR('الخاتم الأصلي %d مش موجود — راجع الرقم من الخطوة 1', 16, 1, @src);
    RETURN;
END

DECLARE @cols NVARCHAR(MAX) = STUFF((
    SELECT ',' + QUOTENAME(name)
    FROM sys.columns
    WHERE object_id = OBJECT_ID('dbo.ItemResource') AND name <> 'id' AND is_computed = 0
    ORDER BY column_id
    FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '');

DECLARE @isIdent BIT = (SELECT is_identity FROM sys.columns
                        WHERE object_id = OBJECT_ID('dbo.ItemResource') AND name = 'id');
DECLARE @sql NVARCHAR(MAX);
DECLARE @params NVARCHAR(100) = N'@src INT, @new INT';

IF @isIdent = 1
    SET @sql = N'SET IDENTITY_INSERT dbo.ItemResource ON;
                 INSERT INTO dbo.ItemResource (id,' + @cols + ')
                 SELECT @new,' + @cols + ' FROM dbo.ItemResource WHERE id = @src;
                 SET IDENTITY_INSERT dbo.ItemResource OFF;';
ELSE
    SET @sql = N'INSERT INTO dbo.ItemResource (id,' + @cols + ')
                 SELECT @new,' + @cols + ' FROM dbo.ItemResource WHERE id = @src;';

EXEC sp_executesql @sql, @params, @src = @src, @new = @new;

SELECT 'تم النسخ ✔' AS result;
SELECT * FROM dbo.ItemResource WHERE id = @new;
GO
