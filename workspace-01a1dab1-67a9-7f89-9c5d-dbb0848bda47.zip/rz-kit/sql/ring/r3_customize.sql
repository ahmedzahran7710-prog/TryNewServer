/* ============================================================
   3) تخصيص الخاتم: لفل 185 + 6 خصائص + 3 خانات + استعداد +25
   ★ عدّل الأرقام اللي مكتوب جنبها  ←
   ملاحظة: أكواد الخصائص (base_type / opt_type) مش من دماغك —
            خدها من نتيجة r1_discover.sql
   ============================================================ */
USE Arcadia;
GO

DECLARE @ring INT = 910001;   -- ← رقم خاتمك الجديد

UPDATE dbo.ItemResource
SET
    /* ---- اللفل المطلوب ---- */
    level           = 185,     -- لفل الأداة نفسها
    use_min_level   = 185,     -- أقل لفل للاستخدام  ← ده اللي إنت عايزه
    use_max_level   = 0,       -- 0 = بدون حد أقصى

    /* ---- 4 خصائص أساسية (أكواد من الخواتم الموجودة) ---- */
    base_type_0 = 1,  base_var1_0 = 500,  base_var2_0 = 500,   -- ← كود 1 / القيمة
    base_type_1 = 2,  base_var1_1 = 400,  base_var2_1 = 400,   -- ← كود 2
    base_type_2 = 3,  base_var1_2 = 300,  base_var2_2 = 300,   -- ← كود 3
    base_type_3 = 4,  base_var1_3 = 200,  base_var2_3 = 200,   -- ← كود 4

    /* ---- خصيتين إضافيتين كأوبشن (كده بقى عندك 6 خصائص) ---- */
    opt_type_0 = 5,  opt_var1_0 = 10,  opt_var2_0 = 10,        -- ← كود الأوبشن الأول
    opt_type_1 = 6,  opt_var1_1 = 10,  opt_var2_1 = 10,        -- ← كود الأوبشن الثاني

    /* ---- خانات الأحجار ---- */
    socket = 3,

    /* ---- استعداد التطوير (+X) ---- */
    enhance     = 0,      -- يبدأ +0
    enhance_id  = 1       -- ← خد قيمة enhance_id من خاتم عالي موجود (شوف r1)

WHERE id = @ring;

SELECT 'تم التعديل ✔' AS result;
SELECT id, level, use_min_level, socket, enhance, enhance_id,
       base_type_0, base_var1_0, base_type_1, base_var1_1,
       base_type_2, base_var1_2, base_type_3, base_var1_3,
       opt_type_0, opt_var1_0, opt_type_1, opt_var1_1
FROM dbo.ItemResource WHERE id = @ring;
GO

/* ============================================================
   لو عايز تعرف أقصى درجة تطوير (+X) مسموحة في السيرفر:
   ============================================================ */
-- SELECT level, * FROM dbo.EnhanceResource ORDER BY level DESC;
-- SELECT TOP 50 * FROM dbo.AwakenResource;
-- SELECT TOP 20 * FROM dbo.RandomItemOptionResource;
-- SELECT TOP 20 * FROM dbo.RandomItemPresetResource;
