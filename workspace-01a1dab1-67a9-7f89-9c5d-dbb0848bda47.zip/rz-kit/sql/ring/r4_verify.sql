/* 4) تأكيد وتراجع */
USE Arcadia;
GO
-- شوف الخاتم
SELECT * FROM dbo.ItemResource WHERE id = 910001;
GO
-- خواتمك الجديدة كلها (نطاق 910000+)
SELECT id, name_id, icon_file_name, level, use_min_level FROM dbo.ItemResource WHERE id >= 910000 ORDER BY id;
GO
-- ★ لو باظ حاجة وعايز تمسح الخاتم تماماً:
-- DELETE FROM dbo.ItemResource WHERE id = 910001;
-- ⚠️ لو اللاعبين لابسينه، امسحه بعد ما يشيلوه. الأفضل تعدّل بدل ما تمسح.
