/* ============================================================
   3) الحجر «الأكبر» — زوّد القيمة وغيّر الأيقونة
   ★ خد كود الحيوية من نتيجة s1 (لا تخترعه)
   ============================================================ */
USE Arcadia;
GO

DECLARE @stone INT = 920001;      -- ← رقم حجرك

UPDATE dbo.ItemResource
SET
    /* اللفل المطلوب للاستخدام */
    level         = 185,
    use_min_level = 185,

    /* ★ القيمة اللي الحجر بيديها — هنا بتخليه «أكبر» */
    base_type_0 = 1,        -- ← كود الخاصية (الحيوية مثلاً) من نتيجة s1
    base_var1_0 = 1000,     -- ← القيمة (الحجر العادي غالباً 50–300)
    base_var2_0 = 1000,

    /* أيقونة جديدة (من تصميمنا) — بعد تسجيلها في الكلاينت */
    icon_file_name = 'icon_item_mygem_big',
    icon_id        = 990601

WHERE id = @stone;

SELECT id, icon_file_name, level, use_min_level, base_type_0, base_var1_0
FROM dbo.ItemResource WHERE id = @stone;
GO

/* ---- اختياري: توزيع الحجر على اللاعبين ---- */
-- يوقعه وحش (خانة 09 فاضية في مجموعة دروب):
-- UPDATE dbo.DropGroupResource
-- SET drop_item_id_09 = 920001, drop_min_count_09 = 1, drop_max_count_09 = 1, drop_percentage_09 = 300
-- WHERE id = <رقم_المجموعة>;

-- أو يتباع في الشوب: شوف جدول MarketResource الأول
-- SELECT TOP 20 * FROM dbo.MarketResource;
