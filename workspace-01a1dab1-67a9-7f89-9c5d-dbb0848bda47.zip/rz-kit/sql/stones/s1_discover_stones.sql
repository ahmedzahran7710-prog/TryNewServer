/* ============================================================
   1) اكتشاف الأحجار (السفك/التركيب) عندك في السيرفر
   ============================================================ */
USE Arcadia;
GO

/* (أ) كل الأدوات اللي شكلها حجر/جوهرة — دوّر على الحجر اللي إنت عارفه */
SELECT id, name_id, icon_file_name, level, use_min_level,
       type, [group], class, item_use_flag,
       base_type_0, base_var1_0, base_var2_0,
       opt_type_0,  opt_var1_0,  opt_var2_0
FROM dbo.ItemResource
WHERE icon_file_name LIKE '%gem%'
   OR icon_file_name LIKE '%stone%'
   OR icon_file_name LIKE '%crystal%'
ORDER BY icon_file_name;
GO

/* (ب) عائلات الأحجار: نفس (type + group + class) = نفس نوع الحجر
       ده اللي بيحدد إنه «حجر سفك» ويتحط في العتاد */
SELECT type, [group], class, COUNT(*) AS عدد_الأحجار
FROM dbo.ItemResource
WHERE icon_file_name LIKE '%gem%' OR icon_file_name LIKE '%stone%' OR icon_file_name LIKE '%crystal%'
GROUP BY type, [group], class
ORDER BY عدد_الأحجار DESC;
GO

/* (ج) قيم الخصائص المستخدمة في الأحجار — عشان تعرف كود الحيوية/القوة */
SELECT base_type_0 AS stat_code, COUNT(*) AS عدد,
       MIN(base_var1_0) AS أقل_قيمة, MAX(base_var1_0) AS أعلى_قيمة
FROM dbo.ItemResource
WHERE icon_file_name LIKE '%gem%' OR icon_file_name LIKE '%stone%'
GROUP BY base_type_0
ORDER BY عدد DESC;
GO
