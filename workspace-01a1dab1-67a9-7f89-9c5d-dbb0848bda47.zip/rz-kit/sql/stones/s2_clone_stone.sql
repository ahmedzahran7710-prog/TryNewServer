/* ============================================================
   2) نسخة من حجر موجود برقم جديد
   غير @src (الحجر الأصلي) و @new (رقمك)
   ============================================================ */
USE Arcadia;
GO
SET NOCOUNT ON;

DECLARE @src INT = 510001;    -- ← رقم الحجر الأصلي (من نتيجة s1)
DECLARE @new INT = 920001;    -- ← رقم الحجر الجديد (نطاق 920000+)

IF EXISTS (SELECT 1 FROM dbo.ItemResource WHERE id = @new)
BEGIN RAISERROR('الرقم مستخدم — غيّره',16,1); RETURN; END
IF NOT EXISTS (SELECT 1 FROM dbo.ItemResource WHERE id = @src)
BEGIN RAISERROR('الحجر الأصلي مش موجود — راجع الرقم',16,1); RETURN; END

DECLARE @cols NVARCHAR(MAX) = STUFF((
    SELECT ',' + QUOTENAME(name) FROM sys.columns
    WHERE object_id = OBJECT_ID('dbo.ItemResource') AND name <> 'id' AND is_computed = 0
    ORDER BY column_id
    FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'), 1, 1, '');

DECLARE @isIdent BIT = (SELECT is_identity FROM sys.columns
                        WHERE object_id=OBJECT_ID('dbo.ItemResource') AND name='id');
DECLARE @sql NVARCHAR(MAX);
IF @isIdent = 1
  SET @sql = N'SET IDENTITY_INSERT dbo.ItemResource ON;
               INSERT INTO dbo.ItemResource (id,'+@cols+') SELECT @new,'+@cols+' FROM dbo.ItemResource WHERE id=@src;
               SET IDENTITY_INSERT dbo.ItemResource OFF;';
ELSE
  SET @sql = N'INSERT INTO dbo.ItemResource (id,'+@cols+') SELECT @new,'+@cols+' FROM dbo.ItemResource WHERE id=@src;';

EXEC sp_executesql @sql, N'@src INT, @new INT', @src, @new;
SELECT 'تم نسخ الحجر ✔' AS result;
SELECT * FROM dbo.ItemResource WHERE id = @new;
GO
