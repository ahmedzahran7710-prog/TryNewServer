/* ============================================================
   إنشاء حساب جديد
   الشرط: authserver.opt فيه  db.auth.use_md5:1
   وطريقة التشفير = MD5( المفتاح + الباسورد )  بصيغة hex صغيرة
   المفتاح الافتراضي في الحزمة:  A4&8zx209z&8zx267Ope
   غيّر MY_PASSWORD_VALUE و MY_LOGIN قبل التشغيل
   ============================================================ */
USE Auth;

DECLARE @login    VARCHAR(32)  = 'testuser';          -- اسم الحساب
DECLARE @plain    VARCHAR(32)  = 'test1234';          -- الباسورد بالعادي
DECLARE @key      VARCHAR(64)  = 'A4&8zx209z&8zx267Ope';

INSERT INTO Account (login_name, password)
VALUES (@login, LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', @key + @plain), 2)));

SELECT * FROM Account WHERE login_name = @login;

/* ---- لو ظهر خطأ "Cannot insert the value NULL into column ..." ----
   معنى كده إن الجدول عنده أعمدة إجبارية تانية. الحل الأسهل:
   افتح SSMS > Auth > Tables > دبل كليك على dbo.Account (Edit Top 200 Rows)
   خد نسخة من صف موجود، دبل كليكه (Copy) وفي آخر الجدول اعمل Paste،
   وغيّر login_name و password بس. ده أسرع وأضمن حل للمبتدئ.
   ---------------------------------------------------------------- */

/* ---- تغيير باسورد حساب موجود ---- */
-- UPDATE Account SET password = LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', 'A4&8zx209z&8zx267Ope' + 'newpass123'), 2)) WHERE login_name = 'testuser';
