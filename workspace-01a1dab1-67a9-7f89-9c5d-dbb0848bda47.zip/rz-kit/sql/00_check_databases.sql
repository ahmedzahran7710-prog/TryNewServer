/* 1) اعرض كل قواعد البيانات — لازم تشوف: Arcadia , Telecaster1 , Auth , BILLING */
SELECT name, state_desc FROM sys.databases ORDER BY name;
