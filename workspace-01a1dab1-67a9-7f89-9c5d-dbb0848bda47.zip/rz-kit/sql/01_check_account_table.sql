/* 2) شوف شكل جدول الحسابات قبل ما تعمل أي حساب */
USE Auth;
EXEC sp_help 'Account';
-- ولو عايز تشوف الحسابات الموجودة أصلاً:
-- SELECT TOP 20 * FROM Account;
