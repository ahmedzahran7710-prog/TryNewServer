@echo off
title Rappelz Client - Online
cd /d "%~dp0"
REM === Change YOUR_IP to your server public IP (example: 41.32.10.5) ===
set SERVER_IP=YOUR_IP
RappelzCmdLauncher.exe SFrame.exe /auth_ip:%SERVER_IP% /locale:Windows-1256 /country:ME /use_nprotect:0 /cash /commercial_shop
if errorlevel 1 pause
