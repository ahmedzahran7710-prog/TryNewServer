@echo off
title Rappelz Client - Local Test
cd /d "%~dp0"
RappelzCmdLauncher.exe SFrame.exe /auth_ip:127.0.0.1 /locale:Windows-1256 /country:ME /use_nprotect:0 /cash /commercial_shop
if errorlevel 1 pause
