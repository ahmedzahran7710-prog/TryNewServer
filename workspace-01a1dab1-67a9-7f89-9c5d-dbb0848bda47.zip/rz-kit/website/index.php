<?php require __DIR__.'/config.php';
$count = '-';
try { $pdo = db_connect(); $count = $pdo->query('SELECT COUNT(*) FROM Account')->fetchColumn(); } catch (Throwable $e) {}
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>سيرفري</title>
<style>body{font-family:Tahoma;background:#0f131a;color:#e6e9ef;text-align:center;padding-top:80px}
a{color:#f0b429;font-size:18px}b{color:#6fdc8c}</style></head>
<body><h1>سيرفر أمل الشعوب — شغّال</h1>
<p>عدد الحسابات المسجّلة: <b><?= htmlspecialchars((string)$count) ?></b></p>
<p><a href="register.php">تسجيل حساب جديد</a></p></body></html>
