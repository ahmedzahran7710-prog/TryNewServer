<?php
/* ==========================================================
   إعدادات الاتصال بقاعدة بيانات الحسابات
   عدّل القيم دي بس، وبعدين احفظ
   ========================================================== */

$DB_HOST = '127.0.0.1';        // لو SQL Express:  localhost\SQLEXPRESS
$DB_NAME = 'Auth';             // قاعدة الحسابات (اللي عملتلها Restore)
$DB_USER = 'sa';
$DB_PASS = 'YOUR_SA_PASSWORD'; // نفس باسورد الـ sa

// نفس المفتاح الموجود في authserver.opt  (السطر S:db.auth.md5_key)
$MD5_KEY = 'A4&8zx209z&8zx267Ope';

function db_connect() {
    global $DB_HOST, $DB_NAME, $DB_USER, $DB_PASS;
    $dsn = "sqlsrv:Server=$DB_HOST;Database=$DB_NAME;Encrypt=no;TrustServerCertificate=yes";
    try {
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        die('<div style="font-family:Tahoma;direction:rtl;padding:20px;background:#fee;border:1px solid #c00">'
            . '<b>فشل الاتصال بقاعدة البيانات</b><br>' . htmlspecialchars($e->getMessage())
            . '<br><br>راجع: 1) اسم السيرفر 2) تمكين TCP/IP 3) إن إضافة php_sqlsrv متفعّلة في php.ini</div>');
    }
}

// الهاش المستخدم في السيرفر = MD5( المفتاح + الباسورد ) بحروف صغيرة
function hash_password($plain) {
    global $MD5_KEY;
    return md5($MD5_KEY . $plain);
}
