<?php
/* صفحة تسجيل حساب — تحطها في  C:\xampp\htdocs\rz\register.php */
require __DIR__ . '/config.php';

$msg = ''; $ok = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $pass  = trim($_POST['pass'] ?? '');
    $pass2 = trim($_POST['pass2'] ?? '');

    if (strlen($login) < 4 || strlen($login) > 16)      $msg = 'اسم الحساب لازم من 4 لـ 16 حرف.';
    elseif (!preg_match('/^[A-Za-z0-9_]+$/', $login))   $msg = 'اسم الحساب بحروف إنجليزي وأرقام و _ بس.';
    elseif (strlen($pass) < 6)                          $msg = 'الباسورد لازم 6 حروف على الأقل.';
    elseif ($pass !== $pass2)                           $msg = 'الباسوردين مش زي بعض.';
    else {
        try {
            $pdo = db_connect();
            $chk = $pdo->prepare('SELECT COUNT(*) FROM Account WHERE login_name = ?');
            $chk->execute([$login]);
            if ($chk->fetchColumn() > 0) {
                $msg = 'اسم الحساب موجود بالفعل، اختار تاني.';
            } else {
                $ins = $pdo->prepare('INSERT INTO Account (login_name, password) VALUES (?, ?)');
                $ins->execute([$login, hash_password($pass)]);
                $ok = true;
                $msg = "تم إنشاء الحساب  $login  بنجاح — تقدر تدخل بيه اللعبة دلوقتي.";
            }
        } catch (PDOException $e) {
            $msg = 'خطأ في القاعدة: ' . $e->getMessage()
                 . ' — غالباً الجدول عنده أعمدة إجبارية تانية؛ شوف ملف sql/02_create_account.sql';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تسجيل حساب</title>
<style>
body{font-family:Tahoma,Arial;background:#12161d;color:#e6e9ef;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}
.box{background:#1b212b;padding:28px 30px;border-radius:12px;width:340px;box-shadow:0 10px 30px #0008}
h1{font-size:19px;margin:0 0 16px;color:#f0b429}
label{display:block;font-size:13px;margin:10px 0 4px;color:#9fb0c6}
input{width:100%;padding:9px 10px;border-radius:7px;border:1px solid #2c3644;background:#0f131a;color:#fff;font-size:14px}
button{margin-top:16px;width:100%;padding:10px;border:0;border-radius:7px;background:#f0b429;color:#191c22;font-weight:700;font-size:15px;cursor:pointer}
.msg{margin-top:14px;padding:10px;border-radius:7px;font-size:13px;line-height:1.7}
.ok{background:#123021;border:1px solid #2c6b46}
.err{background:#301317;border:1px solid #6b262d}
</style></head>
<body>
<div class="box">
  <h1>إنشاء حساب جديد</h1>
  <form method="post">
    <label>اسم الحساب</label><input name="login" maxlength="16" required>
    <label>الباسورد</label><input name="pass" type="password" required>
    <label>تأكيد الباسورد</label><input name="pass2" type="password" required>
    <button type="submit">تسجيل</button>
  </form>
  <?php if ($msg): ?><div class="msg <?= $ok?'ok':'err' ?>"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
</div>
</body></html>
