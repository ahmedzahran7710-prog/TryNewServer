/* =============================================================
   استكشاف قاعدة بيانات السيرفر — أين الشخصيات والأيتمات
   شغّله في SSMS (New Query) — قراءة فقط، لا يعدّل شيئًا
   ============================================================= */

------------------------------------------------------------------
-- 1) القواعد الموجودة على السيرفر
------------------------------------------------------------------
SELECT name, state_desc FROM sys.databases ORDER BY name;
GO

------------------------------------------------------------------
-- 2) كل جداول قاعدة اللعبة (Telecaster1) مع عدد الصفوف
------------------------------------------------------------------
SELECT
    t.name                AS [table],
    SUM(p.rows)           AS [rows]
FROM Telecaster1.sys.tables t
LEFT JOIN Telecaster1.sys.partitions p
       ON p.object_id = t.object_id AND p.index_id IN (0,1)
GROUP BY t.name
ORDER BY [rows] DESC, t.name;
GO

------------------------------------------------------------------
-- 3) الشخصيات  ← هنا شخصيتك OwnerZahran
------------------------------------------------------------------
SELECT
    sid,                      -- رقم الشخصية الداخلي (owner_id في جدول الأيتم)
    name,
    account_id,               -- يربطها بجدول Auth.dbo.Accounts
    lv,
    exp,
    gold,
    permission,
    layer, x, y, z,
    delete_time
FROM Telecaster1.dbo.Character
WHERE name NOT LIKE '@%'
ORDER BY sid;
GO

------------------------------------------------------------------
-- 4) الأيتمات اللي مع شخصيتك
--    owner_id = رقم الشخصية (sid)
--    idx      = مكان الأيتم (0..N = الحقيبة، أرقام كبيرة = الأسلحة/اللبس)
--    code     = كود الأيتم
------------------------------------------------------------------
SELECT
    i.sid,
    i.owner_id,
    i.account_id,
    i.idx,
    i.code,
    i.cnt,
    i.level,
    i.enhance,
    i.flag
FROM Telecaster1.dbo.Item i
INNER JOIN Telecaster1.dbo.Character c ON c.sid = i.owner_id
WHERE c.name = N'OwnerZahran'
ORDER BY i.idx;
GO

------------------------------------------------------------------
-- 5) الأسلحة / اللبس الملبوسة (idx كبير عادةً)
------------------------------------------------------------------
SELECT i.idx, i.code, i.level, i.enhance
FROM Telecaster1.dbo.Item i
INNER JOIN Telecaster1.dbo.Character c ON c.sid = i.owner_id
WHERE c.name = N'OwnerZahran' AND i.idx >= 100
ORDER BY i.idx;
GO

------------------------------------------------------------------
-- 6) نظرة سريعة على جدول الحالات (State) — بافات/حالات مستمرة
------------------------------------------------------------------
SELECT TOP 20 * FROM Telecaster1.dbo.State ORDER BY sid DESC;
GO

------------------------------------------------------------------
-- 7) الحسابات (قاعدة Auth) — للمقارنة
------------------------------------------------------------------
SELECT account_id, login_name, block, auth_ok
FROM Auth.dbo.Accounts ORDER BY account_id;
GO
