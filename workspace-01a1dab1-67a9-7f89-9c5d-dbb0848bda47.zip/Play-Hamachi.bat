@echo off
cd /d "%~dp0"
title Rappelz - Hamachi 25.21.212.130

if exist "RappelzCmdLauncher.exe" (
    start "" RappelzCmdLauncher.exe /auth_ip:25.21.212.130 /auth_port:1996 /use_nprotect:0
    goto :eof
)
if exist "sframe.exe" (
    start "" sframe.exe /auth_ip:25.21.212.130 /auth_port:1996 /use_nprotect:0
    goto :eof
)
echo sframe.exe / RappelzCmdLauncher.exe not found in this folder.
pause
