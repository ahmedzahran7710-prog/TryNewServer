#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
levelcurve.py — يقرأ جدول الخبرة الحقيقي من CSV، يتعلّم شكل المنحنى،
ويولّد صفوف المستويات الجديدة (181 → 200) بسكربت SQL جاهز.

الفكرة: مفيش رقم مخترع. السكربت بياخد آخر N مستوى حقيقي من عندك،
بيحسب نسبة النمو بينهم، وبيستخدمها للمستويات الجديدة.

الاستخدام:
    python3 levelcurve.py --csv levels.csv                  # تقرير وتحليل
    python3 levelcurve.py --csv levels.csv --sql out.sql     # + توليد SQL
    python3 levelcurve.py --csv levels.csv --to 220          # لحد لفل 220
    python3 levelcurve.py --csv levels.csv --tail 30         # آخر 30 مستوى كأساس

لو مش عارف أسماء الأعمدة، السكربت بيحاول يكتشفها لوحده ويطبع اللي اختاره.
وتقدر تحددها يدوي:
    python3 levelcurve.py --csv levels.csv --level-col level --exp-col exp
"""
import argparse
import csv
import io
import math
import os
import sys
from datetime import date


# ------------------------------------------------------------------ القراءة
def read_csv(path):
    with io.open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        sample = f.read(4096)
        f.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.reader(f, dialect))
    if not rows:
        sys.exit("الملف فاضي.")
    header = rows[0]
    data = [r for r in rows[1:] if r and any(x.strip() for x in r)]
    return header, data


def to_num(x):
    x = (x or "").strip().replace(",", "")
    if x == "":
        return None
    try:
        return int(x)
    except ValueError:
        try:
            return float(x)
        except ValueError:
            return None


def detect_columns(header, data, level_col=None, exp_col=None):
    ncol = len(header)
    cols = []
    for i in range(ncol):
        vals = [to_num(r[i]) for r in data if i < len(r)]
        num = [v for v in vals if isinstance(v, (int, float))]
        cols.append(num)

    if level_col is None:
        # عمود اللفل = الأرقام فيه متسلسلة 1,2,3... أو أصغر عمود بأرقام صغيرة فريدة
        best, best_score = None, -1
        for i, num in enumerate(cols):
            if len(num) < 5:
                continue
            uniq = len(set(num))
            ordered = all(num[j] < num[j + 1] for j in range(len(num) - 1))
            span = max(num) - min(num)
            score = 0
            if ordered:
                score += 2
            if uniq == len(num):
                score += 2
            if min(num) <= 5:
                score += 2
            if span < 1000:
                score += 1
            if score > best_score:
                best, best_score = i, score
        level_col = best

    if exp_col is None:
        # عمود الخبرة = أكبر عمود في القيم وبيزيد
        best, best_max = None, -1
        for i, num in enumerate(cols):
            if i == level_col or len(num) < 5:
                continue
            if max(num) > best_max and max(num) > 1000:
                best, best_max = i, max(num)
        exp_col = best

    if level_col is None or exp_col is None:
        sys.exit("مش عارف أحدد الأعمدة. حددها بـ --level-col و --exp-col")
    return level_col, exp_col


# ------------------------------------------------------------------ الحساب
def build_pairs(header, data, li, ei):
    pairs = []
    for r in data:
        if li >= len(r) or ei >= len(r):
            continue
        lv = to_num(r[li])
        ex = to_num(r[ei])
        if lv is None or ex is None:
            continue
        pairs.append((int(lv), float(ex)))
    pairs.sort()
    # شيل التكرار
    seen, clean = set(), []
    for lv, ex in pairs:
        if lv in seen:
            continue
        seen.add(lv)
        clean.append((lv, ex))
    return clean


def analyse(pairs, tail):
    window = pairs[-tail:] if len(pairs) > tail else pairs[:]
    ratios = []
    deltas = []
    for i in range(1, len(window)):
        prev = window[i - 1][1]
        cur = window[i][1]
        if prev > 0:
            ratios.append(cur / prev)
        deltas.append(cur - prev)

    # وسط هندسي للنسب = أدق من المتوسط العادي في النمو الأسي
    if ratios:
        gmean = math.exp(sum(math.log(r) for r in ratios) / len(ratios))
    else:
        gmean = 1.0

    # هل النسبة نفسها بتزيد؟ (منحنى يتسارع)
    trend = 0.0
    if len(ratios) >= 6:
        half = len(ratios) // 2
        first = sum(ratios[:half]) / half
        second = sum(ratios[half:]) / (len(ratios) - half)
        trend = (second - first) / max(first, 1e-9)

    return {
        "window": window,
        "ratios": ratios,
        "gmean": gmean,
        "trend": trend,
        "min_ratio": min(ratios) if ratios else 1,
        "max_ratio": max(ratios) if ratios else 1,
    }


def extrapolate(pairs, to_level, tail):
    info = analyse(pairs, tail)
    last_lv, last_ex = pairs[-1]
    if to_level <= last_lv:
        return [], info

    out = []
    ex = last_ex
    ratio = info["gmean"]
    step = info["trend"] / max(len(range(last_lv, to_level)), 1)
    for i, lv in enumerate(range(last_lv + 1, to_level + 1)):
        ratio_i = ratio * (1 + info["trend"] * (i + 1) / max(to_level - last_lv, 1))
        ex = ex * ratio_i
        out.append((lv, int(round(ex)), ratio_i))
    return out, info


# ------------------------------------------------------------------ الطباعة
def print_report(header, pairs, info, new_rows):
    print("=" * 74)
    print("  تحليل جدول الخبرة الحقيقي")
    print("=" * 74)
    print(f"  عدد المستويات المقروءة : {len(pairs)}")
    print(f"  من لفل {pairs[0][0]} إلى لفل {pairs[-1][0]}")
    print(f"  خبرة آخر مستوى        : {pairs[-1][1]:,.0f}")
    print()
    print(f"  نافذة التحليل         : آخر {len(info['window'])} مستوى")
    print(f"  وسط هندسي لنسبة النمو : {info['gmean']:.4f}  "
          f"(يعني كل مستوى بيحتاج {info['gmean']:.1%} من اللي قبله)")
    print(f"  أقل/أعلى نسبة         : {info['min_ratio']:.4f} / {info['max_ratio']:.4f}")
    print(f"  اتجاه النسبة (تسارع)  : {info['trend']:+.2%}")
    print()

    print("  آخر 8 مستويات حقيقية:")
    print("  " + "-" * 60)
    print(f"  {'لفل':>6} {'الخبرة المطلوبة':>22} {'نسبة النمو':>14}")
    for i, (lv, ex) in enumerate(pairs[-8:]):
        r = ""
        idx = len(pairs) - 8 + i
        if idx > 0:
            r = f"{ex / pairs[idx - 1][1]:.4f}"
        print(f"  {lv:>6} {ex:>22,.0f} {r:>14}")
    print()

    if new_rows:
        print(f"  المستويات المولّدة ({new_rows[0][0]} → {new_rows[-1][0]}):")
        print("  " + "-" * 60)
        print(f"  {'لفل':>6} {'الخبرة المطلوبة':>22} {'× عن السابق':>14}")
        prev = pairs[-1][1]
        for lv, ex, r in new_rows:
            print(f"  {lv:>6} {ex:>22,.0f} {r:>14.4f}")
            prev = ex
        print()
        print(f"  إجمالي الخبرة من {pairs[-1][0]} لـ {new_rows[-1][0]}: "
              f"{sum(x[1] for x in new_rows):,.0f}")
    print("=" * 74)


def emit_sql(path, header, pairs, new_rows, table, level_col, exp_col):
    lvname = header[level_col].strip() or "level"
    exname = header[exp_col].strip() or "exp"
    today = date.today().strftime("%Y%m%d")
    lines = []
    lines.append("-- ============================================================")
    lines.append("--  مولّد تلقائياً بواسطة levelcurve.py")
    lines.append(f"--  التاريخ: {date.today().isoformat()}")
    lines.append(f"--  المصدر: جدول حقيقي {len(pairs)} مستوى "
                 f"({pairs[0][0]} → {pairs[-1][0]})")
    lines.append("--  ⚠️  شغّل النسخة الاحتياطية الأول (سطر 11 في الملف)")
    lines.append("-- ============================================================")
    lines.append("")
    lines.append("USE [Arcadia];")
    lines.append("GO")
    lines.append("")
    lines.append("-- 0) نسخة احتياطية قبل أي حاجة")
    lines.append(f"IF OBJECT_ID('dbo.{table}_bak_{today}') IS NULL")
    lines.append(f"    SELECT * INTO dbo.{table}_bak_{today} FROM dbo.{table};")
    lines.append("GO")
    lines.append("")
    lines.append("SET NOCOUNT ON;")
    lines.append("BEGIN TRANSACTION;")
    lines.append("")
    lines.append("-- 1) شيل أي صفوف قديمة في نفس النطاق (عشان تمنع التكرار)")
    lines.append(f"DELETE FROM dbo.[{table}]")
    lines.append(f" WHERE [{lvname}] BETWEEN {new_rows[0][0]} AND {new_rows[-1][0]};")
    lines.append("")
    lines.append("-- 2) إدخال المستويات الجديدة")
    lines.append(f"-- ملاحظة: لو الجدول فيه أعمدة إجبارية تانية، استخدم")
    lines.append("-- 3_sql/11_clone_row_template.sql بدل الجزء ده.")
    lines.append(f"INSERT INTO dbo.[{table}] ([{lvname}], [{exname}]) VALUES")
    body = []
    for lv, ex, _r in new_rows:
        body.append(f"    ({lv}, {ex})")
    lines.append(",\n".join(body) + ";")
    lines.append("")
    lines.append("COMMIT TRANSACTION;")
    lines.append("GO")
    lines.append("")
    lines.append("-- 3) تحقق")
    lines.append(f"SELECT * FROM dbo.[{table}]")
    lines.append(f" WHERE [{lvname}] BETWEEN {new_rows[0][0]} AND {new_rows[-1][0]}")
    lines.append(f" ORDER BY [{lvname}];")
    lines.append("GO")
    lines.append("")
    lines.append("-- 4) تراجع (لو حصلت مشكلة)")
    lines.append("-- ROLLBACK TRANSACTION;")
    lines.append(f"-- أو: DELETE FROM dbo.[{table}] WHERE [{lvname}] > {pairs[-1][0]};")
    lines.append("")
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with io.open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"\n✅ اتكتب: {path}")


def main():
    ap = argparse.ArgumentParser(description="تحليل منحنى الخبرة وتوليد مستويات جديدة")
    ap.add_argument("--csv", required=True, help="ملف CSV المصدَّر من LevelResource")
    ap.add_argument("--level-col", default=None, help="اسم/رقم عمود اللفل")
    ap.add_argument("--exp-col", default=None, help="اسم/رقم عمود الخبرة")
    ap.add_argument("--to", type=int, default=200, help="آخر مستوى مطلوب (افتراضي 200)")
    ap.add_argument("--tail", type=int, default=20, help="عدد المستويات المستخدمة كأساس (افتراضي 20)")
    ap.add_argument("--table", default="LevelResource")
    ap.add_argument("--sql", default=None, help="مسار ملف SQL الناتج")
    args = ap.parse_args()

    header, data = read_csv(args.csv)
    li = header.index(args.level_col) if args.level_col in header else (
        int(args.level_col) if (args.level_col or "").isdigit() else None)
    ei = header.index(args.exp_col) if args.exp_col in header else (
        int(args.exp_col) if (args.exp_col or "").isdigit() else None)
    if li is None or ei is None:
        li, ei = detect_columns(header, data, li, ei)

    print(f"عمود اللفل  : [{header[li] if li < len(header) else li}]  (#{li})")
    print(f"عمود الخبرة : [{header[ei] if ei < len(header) else ei}]  (#{ei})\n")

    pairs = build_pairs(header, data, li, ei)
    if len(pairs) < 5:
        sys.exit("الصفوف الرقمية قليلة — تأكد إن الملف هو LevelResource فعلاً.")

    new_rows, info = extrapolate(pairs, args.to, args.tail)
    print_report(header, pairs, info, new_rows)

    if args.sql and new_rows:
        emit_sql(args.sql, header, pairs, new_rows, args.table, li, ei)
    elif args.sql:
        print("مفيش مستويات جديدة تتولّد (آخر لفل >= المطلوب).")


if __name__ == "__main__":
    main()
