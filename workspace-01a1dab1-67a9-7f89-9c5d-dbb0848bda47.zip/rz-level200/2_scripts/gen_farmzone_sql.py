#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_farmzone_sql.py — يولّد سكربت SQL جاهز لمنطقة تجميع (Farm Zone).

بياخد ملف الإعدادات farmzone.json (المعرّفات الحقيقية اللي طلعتها من
1_discover/03_find_rondo.sql) وبيطلع:
    - UPDATE للوحوش (لفل / HP / خبرة)
    - نسخة احتياطية تلقائية قبل التعديل
    - ملف تراجع (rollback)

الاستخدام:
    python3 gen_farmzone_sql.py --config farmzone.json
    python3 gen_farmzone_sql.py --config farmzone.json --dry-run
"""
import argparse
import io
import json
import os
import sys
from datetime import date


def need(cfg, key):
    if key not in cfg:
        sys.exit(f"ناقص في الإعدادات: {key}")
    return cfg[key]


def build(cfg, dry=False):
    t = date.today().strftime("%Y%m%d")
    area = need(cfg, "area_name")
    regions = need(cfg, "region_ids")
    mons = need(cfg, "monster_ids")
    lvl_from, lvl_to = need(cfg, "level_from"), need(cfg, "level_to")
    hp_mult = cfg.get("hp_multiplier", 1.0)
    exp_mult = cfg.get("exp_multiplier", 1.0)
    mtable = cfg.get("monster_table", "MonsterResource")
    ltable = cfg.get("level_table", "LevelResource")
    lvl_col = cfg.get("level_column", "level")
    hp_col = cfg.get("hp_column", "max_hp")
    exp_col = cfg.get("exp_column", "exp")

    region_list = ",".join(str(x) for x in regions)
    mon_list = ",".join(str(x) for x in mons)

    L = []
    A = L.append
    A("-- " + "=" * 70)
    A(f"--  منطقة التجميع: {area}")
    A(f"--  النطاق: لفل {lvl_from} → {lvl_to}")
    A(f"--  مولّد بواسطة gen_farmzone_sql.py — {date.today().isoformat()}")
    A("-- " + "=" * 70)
    A("")
    A("USE [Arcadia];")
    A("GO")
    A("SET NOCOUNT ON;")
    A("")
    A("-- " + "-" * 70)
    A("-- 0) نسخة احتياطية (لا تتخطى الخطوة دي)")
    A("-- " + "-" * 70)
    A(f"IF OBJECT_ID('dbo.{mtable}_bak_{t}') IS NULL")
    A(f"    SELECT * INTO dbo.{mtable}_bak_{t} FROM dbo.{mtable};")
    A("GO")
    A("")
    A("-- " + "-" * 70)
    A("-- 1) قبل التعديل: شوف الحالة الحالية (صوّر النتيجة أو خزّنها)")
    A("-- " + "-" * 70)
    A(f"SELECT id, {lvl_col}"
      + (f", {hp_col}" if hp_col else "")
      + f" FROM dbo.[{mtable}]"
      + f" WHERE id IN ({mon_list}) ORDER BY {lvl_col};")
    A("GO")
    A("")
    A("-- " + "-" * 70)
    A("-- 2) التعديل: توزيع اللفلات على النطاق المطلوب")
    A("--    (بيوزّع الوحوش بالتساوي من لفل {} لـ {})".format(lvl_from, lvl_to))
    A("-- " + "-" * 70)
    A("BEGIN TRANSACTION;")
    A("")
    n = len(mons)
    if n == 1:
        targets = [lvl_from]
    else:
        span = lvl_to - lvl_from
        targets = [lvl_from + round(i * span / (n - 1)) for i in range(n)]

    for mid, lv in zip(mons, targets):
        A(f"UPDATE dbo.[{mtable}] SET [{lvl_col}] = {lv} WHERE id = {mid};"
          f"   -- لفل {lv}")
    A("")
    if hp_col and hp_mult != 1.0:
        A(f"-- 3) تعديل نقاط الحياة ×{hp_mult} للوحوش المختارة")
        A(f"UPDATE dbo.[{mtable}] SET [{hp_col}] = [{hp_col}] * {hp_mult}")
        A(f" WHERE id IN ({mon_list});")
        A("")
    if exp_mult != 1.0:
        A(f"-- 4) تعديل الخبرة ×{exp_mult}")
        A(f"UPDATE dbo.[{ltable}] SET [{exp_col}] = [{exp_col}] * {exp_mult}")
        A(f" WHERE [{lvl_col}] BETWEEN {lvl_from} AND {lvl_to};")
        A("")
    A("-- 5) تأكد إن الرقم منطقي قبل الـCOMMIT")
    A(f"SELECT id, {lvl_col}, " + (f"{hp_col}" if hp_col else "''") + f" FROM dbo.[{mtable}]"
      + f" WHERE id IN ({mon_list}) ORDER BY {lvl_col};")
    A("")
    A("-- لو كل حاجة تمام:")
    A("COMMIT TRANSACTION;")
    A("-- لو فيه مشكلة:")
    A("-- ROLLBACK TRANSACTION;")
    A("GO")
    A("")
    A("-- " + "-" * 70)
    A("-- 6) ملف التراجع (شغّله لو عايز ترجع كل حاجة زي ما كانت)")
    A("-- " + "-" * 70)
    A("/*")
    A(f"DELETE FROM dbo.[{mtable}];")
    A(f"INSERT INTO dbo.[{mtable}] SELECT * FROM dbo.{mtable}_bak_{t};")
    A(f"DBCC CHECKIDENT ('dbo.{mtable}', RESEED, 0);   -- لو فيه Identity")
    A("*/")
    A("GO")
    A("")
    A("-- " + "-" * 70)
    A("-- 7) تذكير: التعديل ده على جدول الوحوش بس.")
    A("--    لسه محتاج:")
    A("--      - كثافة الظهور  : monster_respawn.lua")
    A("--      - الدروب       : DropGroupResource")
    A("--      - بوابة الدخول : 4_lua/NPC_FarmZone_Gate.lua")
    A("-- " + "-" * 70)
    A("")
    A(f"-- المنطقة (region ids): {region_list}")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="farmzone.json")
    ap.add_argument("--out", default=None)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    with io.open(a.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    sql = build(cfg, a.dry_run)
    if a.dry_run:
        print(sql)
        return

    out = a.out or f"../3_sql/20_{cfg.get('area_slug','farmzone')}.sql"
    d = os.path.dirname(out)
    if d:
        os.makedirs(d, exist_ok=True)
    with io.open(out, "w", encoding="utf-8") as f:
        f.write(sql)
    print(f"✅ اتكتب: {out}")
    print(f"   عدد الوحوش: {len(cfg['monster_ids'])}")
    print(f"   النطاق: {cfg['level_from']} → {cfg['level_to']}")


if __name__ == "__main__":
    main()
