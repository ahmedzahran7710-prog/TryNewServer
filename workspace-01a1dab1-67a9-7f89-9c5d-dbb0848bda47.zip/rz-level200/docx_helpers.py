# -*- coding: utf-8 -*-
"""أدوات بناء ملفات وورد عربية RTL — مشتركة."""
import json
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

NAVY = RGBColor(0x1F, 0x38, 0x64)
BLUE = RGBColor(0x2E, 0x5C, 0x8A)
RED = RGBColor(0xC0, 0x00, 0x00)
GREEN = RGBColor(0x1E, 0x6B, 0x3A)
GREY = RGBColor(0x59, 0x59, 0x59)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

FONT = "Segoe UI"


# ----------------------------------------------------------------- utilities
def rtl_par(p, align=WD_ALIGN_PARAGRAPH.RIGHT):
    pPr = p._p.get_or_add_pPr()
    b = OxmlElement("w:bidi")
    pPr.append(b)
    p.alignment = align


def rtl_run(run):
    rPr = run._r.get_or_add_rPr()
    r = OxmlElement("w:rtl")
    rPr.append(r)
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:cs"), FONT)
    rFonts.set(qn("w:ascii"), FONT)
    rFonts.set(qn("w:hAnsi"), FONT)


def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear")
    sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), hexcolor)
    tcPr.append(sh)


def cell_margins(table, top=60, bottom=60, left=90, right=90):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("start", left), ("bottom", bottom), ("end", right)):
        e = OxmlElement("w:" + k)
        e.set(qn("w:w"), str(v))
        e.set(qn("w:type"), "dxa")
        mar.append(e)
    tblPr.append(mar)


def table_borders(table, color="BFCEDD", sz=6):
    tblPr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "start", "bottom", "end", "insideH", "insideV"):
        e = OxmlElement("w:" + edge)
        e.set(qn("w:val"), "single")
        e.set(qn("w:sz"), str(sz))
        e.set(qn("w:space"), "0")
        e.set(qn("w:color"), color)
        borders.append(e)
    tblPr.append(borders)


def bidi_table(table):
    tblPr = table._tbl.tblPr
    b = OxmlElement("w:bidiVisual")
    tblPr.append(b)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    e = OxmlElement("w:tblHeader")
    e.set(qn("w:val"), "true")
    trPr.append(e)


def no_split(row):
    trPr = row._tr.get_or_add_trPr()
    e = OxmlElement("w:cantSplit")
    e.set(qn("w:val"), "true")
    trPr.append(e)


# ------------------------------------------------------------------ writers
class Doc:
    def __init__(self):
        self.d = Document()
        st = self.d.styles["Normal"]
        st.font.name = FONT
        st.font.size = Pt(11)
        st.element.rPr.rFonts.set(qn("w:cs"), FONT)
        sec = self.d.sections[0]
        sec.page_width = Cm(21)
        sec.page_height = Cm(29.7)
        sec.left_margin = Cm(2.0)
        sec.right_margin = Cm(2.0)
        sec.top_margin = Cm(1.9)
        sec.bottom_margin = Cm(1.9)
        self._footer()

    def _footer(self):
        p = self.d.sections[0].footer.paragraphs[0]
        rtl_par(p, WD_ALIGN_PARAGRAPH.CENTER)
        r = p.add_run("سيرفر Rappelz Space — دليل كامل  •  صفحة ")
        r.font.size = Pt(8.5)
        r.font.color.rgb = GREY
        rtl_run(r)
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), "PAGE")
        run = OxmlElement("w:r")
        rPr = OxmlElement("w:rPr")
        sz = OxmlElement("w:sz")
        sz.set(qn("w:val"), "17")
        rPr.append(sz)
        run.append(rPr)
        fld.append(run)
        p._p.append(fld)

    # -- text
    def p(self, text, size=11, bold=False, color=None, align=WD_ALIGN_PARAGRAPH.JUSTIFY,
          space_after=6, space_before=0, italic=False, indent=0):
        par = self.d.add_paragraph()
        rtl_par(par, align)
        pf = par.paragraph_format
        pf.space_after = Pt(space_after)
        pf.space_before = Pt(space_before)
        pf.line_spacing = 1.28
        if indent:
            pf.right_indent = Cm(indent)
        r = par.add_run(text)
        r.font.size = Pt(size)
        r.bold = bold
        r.italic = italic
        if color is not None:
            r.font.color.rgb = color
        rtl_run(r)
        return par

    def rich(self, parts, size=11, align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_after=6):
        """parts = [(text, bold, color|None), ...]"""
        par = self.d.add_paragraph()
        rtl_par(par, align)
        par.paragraph_format.space_after = Pt(space_after)
        par.paragraph_format.line_spacing = 1.28
        for text, bold, color in parts:
            r = par.add_run(text)
            r.font.size = Pt(size)
            r.bold = bold
            if color is not None:
                r.font.color.rgb = color
            rtl_run(r)
        return par

    def h1(self, num, text):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT)
        pf = par.paragraph_format
        pf.space_before = Pt(16)
        pf.space_after = Pt(8)
        pf.keep_with_next = True
        pPr = par._p.get_or_add_pPr()
        pbdr = OxmlElement("w:pBdr")
        bot = OxmlElement("w:bottom")
        bot.set(qn("w:val"), "single")
        bot.set(qn("w:sz"), "18")
        bot.set(qn("w:space"), "6")
        bot.set(qn("w:color"), "1F3864")
        pbdr.append(bot)
        pPr.append(pbdr)
        r = par.add_run(f"{num}. {text}")
        r.font.size = Pt(17)
        r.bold = True
        r.font.color.rgb = NAVY
        rtl_run(r)

    def h2(self, text, color=BLUE):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT)
        pf = par.paragraph_format
        pf.space_before = Pt(11)
        pf.space_after = Pt(4)
        pf.keep_with_next = True
        r = par.add_run(text)
        r.font.size = Pt(13.5)
        r.bold = True
        r.font.color.rgb = color
        rtl_run(r)

    def h3(self, text):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT)
        pf = par.paragraph_format
        pf.space_before = Pt(8)
        pf.space_after = Pt(3)
        pf.keep_with_next = True
        r = par.add_run("▪ " + text)
        r.font.size = Pt(11.5)
        r.bold = True
        r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
        rtl_run(r)

    def bullet(self, text, size=11, indent=0.5):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.JUSTIFY)
        pf = par.paragraph_format
        pf.right_indent = Cm(indent + 0.4)
        pf.space_after = Pt(2.5)
        pf.line_spacing = 1.24
        r = par.add_run("•  " + text)
        r.font.size = Pt(size)
        rtl_run(r)

    def num(self, i, text, size=11):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.JUSTIFY)
        pf = par.paragraph_format
        pf.right_indent = Cm(0.9)
        pf.space_after = Pt(3)
        pf.line_spacing = 1.24
        r = par.add_run(f"{i})  ")
        r.bold = True
        r.font.size = Pt(size)
        r.font.color.rgb = NAVY
        rtl_run(r)
        r2 = par.add_run(text)
        r2.font.size = Pt(size)
        rtl_run(r2)

    def code(self, text):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.LEFT)
        pf = par.paragraph_format
        pf.space_before = Pt(3)
        pf.space_after = Pt(7)
        pf.left_indent = Cm(0.6)
        pf.right_indent = Cm(0.6)
        pPr = par._p.get_or_add_pPr()
        sh = OxmlElement("w:shd")
        sh.set(qn("w:val"), "clear")
        sh.set(qn("w:color"), "auto")
        sh.set(qn("w:fill"), "F2F2F2")
        pPr.append(sh)
        r = par.add_run(text)
        r.font.name = "Consolas"
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(0x0A, 0x2E, 0x4F)
        return par

    def callout(self, title, body, fill="EAF1F8", bar="2E5C8A", title_color=NAVY):
        t = self.d.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        bidi_table(t)
        cell = t.cell(0, 0)
        shade(cell, fill)
        cell_margins(t, 90, 90, 130, 130)
        table_borders(t, bar, 4)
        cell.paragraphs[0]._p.getparent().remove(cell.paragraphs[0]._p)
        p1 = cell.add_paragraph()
        rtl_par(p1, WD_ALIGN_PARAGRAPH.RIGHT)
        p1.paragraph_format.space_after = Pt(2)
        r = p1.add_run(title)
        r.bold = True
        r.font.size = Pt(11)
        r.font.color.rgb = title_color
        rtl_run(r)
        p2 = cell.add_paragraph()
        rtl_par(p2, WD_ALIGN_PARAGRAPH.JUSTIFY)
        p2.paragraph_format.line_spacing = 1.26
        r2 = p2.add_run(body)
        r2.font.size = Pt(10.5)
        rtl_run(r2)
        self.p("", space_after=3)

    def verdict(self, level):
        """level in easy/med/hard/vhard/impossible"""
        return {
            "easy": ("سهل", "C6EFCE", "1E6B3A"),
            "med": ("متوسط", "FFF2CC", "7F6000"),
            "hard": ("صعب", "FCE4D6", "974706"),
            "vhard": ("صعب جداً", "FFC7CE", "9C0006"),
            "no": ("مستحيل عملياً", "D9D9D9", "404040"),
        }[level]

    def table(self, headers, rows, widths=None, vcol=None, size=9.5, head_fill="1F3864"):
        t = self.d.add_table(rows=1, cols=len(headers))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        bidi_table(t)
        table_borders(t)
        cell_margins(t, 50, 50, 80, 80)
        hdr = t.rows[0]
        repeat_header(hdr)
        for i, h in enumerate(headers):
            c = hdr.cells[i]
            shade(c, head_fill)
            c.paragraphs[0]._p.getparent().remove(c.paragraphs[0]._p)
            p = c.add_paragraph()
            rtl_par(p, WD_ALIGN_PARAGRAPH.CENTER)
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(h)
            r.bold = True
            r.font.size = Pt(size)
            r.font.color.rgb = WHITE
            rtl_run(r)
        for ri, row in enumerate(rows):
            cells = t.add_row().cells
            no_split(t.rows[-1])
            for ci, val in enumerate(row):
                c = cells[ci]
                if ri % 2 == 1:
                    shade(c, "F4F8FC")
                c.paragraphs[0]._p.getparent().remove(c.paragraphs[0]._p)
                p = c.add_paragraph()
                rtl_par(p, WD_ALIGN_PARAGRAPH.RIGHT)
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.15
                if vcol is not None and ci == vcol and val in (
                        "easy", "med", "hard", "vhard", "no"):
                    label, fill, col = self.verdict(val)
                    shade(c, fill)
                    r = p.add_run(label)
                    r.bold = True
                    r.font.size = Pt(size)
                    r.font.color.rgb = RGBColor.from_string(col)
                    rtl_run(r)
                else:
                    r = p.add_run(str(val))
                    r.font.size = Pt(size)
                    rtl_run(r)
        if widths:
            for i, w in enumerate(widths):
                for row in t.rows:
                    row.cells[i].width = Cm(w)
        self.p("", space_after=4)
        return t

    def pagebreak(self):
        par = self.d.add_paragraph()
        par.add_run().add_break(WD_BREAK.PAGE)

    def spacer(self, pt=6):
        self.p("", space_after=pt)

    def save(self, path):
        self.d.save(path)


