--[[ ==========================================================================
     NPC_FarmZone_Gate.lua
     Farm-zone gate NPC  --  level-restricted teleporter.

     Written against the REAL 9.1 script API found in your files
     (Game_bin/Resource/Script/NPC_TeleportField.lua / NPC_TeleportTown.lua):

        get_value("level")        get_value("gold")
        set_value("gold", x)      update_gold_chaos()
        warp(x, y)                save()
        message("@id")            cprint("@id")
        dlg_title / dlg_text / dlg_menu / dlg_show

     HOW TO INSTALL
     --------------
     1. Put this file in:  GameEngine/Game_bin/Resource/Script/
     2. Compile it with the server's own tool if your build needs it
        (RappelzCompress_v2.exe produces the .ela version -- same name).
     3. In the DB: NPCResource -> the NPC you created must have
        script_name = 'NPC_FarmZone_Gate'
     4. Every race needs its own function: _Deva_ / _Asura_ / _Gaia_
     5. Restart the game server. Talk to the NPC in game.

     NOTE: keep this file ASCII-only. Non-ASCII comments in NPC scripts
     can break the server's script encoder on some builds.
     ========================================================================== ]]

function get_module_name()
    return "NPC_FarmZone_Gate"
end


-- ===========================================================================
--  CONFIG  --  change these values only
-- ===========================================================================
local CFG = {
    -- level window allowed to enter
    min_level   = 180,
    max_level   = 200,      -- 0 = no upper limit

    -- gold price (0 = free)
    cost        = 0,

    -- destination coordinates  >> CHANGE THESE <<
    -- take them from the map file / from inside the game (F2 or your GM tool)
    warp_x      = 0,
    warp_y      = 0,
    warp_random = 8,        -- random offset so players don't stack

    -- message ids (these are real ids that exist in your 9.1 client)
    msg_title   = "@90100601",   -- dialog title
    msg_text    = "@90100602",   -- dialog body
    msg_enter   = "@90100603",   -- "teleport" button label
    msg_close   = "@90010001",   -- "close" button label
    msg_no_gold = "@90010008",   -- "not enough gold"
    msg_low     = "@90010010",   -- reuse as generic "requirement not met"
    msg_high    = "@90010010",
}


-- ===========================================================================
--  CORE
-- ===========================================================================

local function level_ok()
    local lv = get_value("level")

    if lv < CFG.min_level then
        return false, "low"
    end

    if CFG.max_level > 0 and lv > CFG.max_level then
        return false, "high"
    end

    return true, "ok"
end


-- the button handler -- called from dlg_menu
function FarmZone_Gate_Enter()

    local ok, why = level_ok()

    if not ok then
        if why == "low" then
            message(CFG.msg_low)
        else
            message(CFG.msg_high)
        end
        return
    end

    if CFG.cost > 0 then
        local gold = get_value("gold")
        if gold < CFG.cost then
            message(CFG.msg_no_gold)
            return
        end
        set_value("gold", gold - CFG.cost)
        update_gold_chaos()
    end

    save()

    warp(
        CFG.warp_x + math.random(0, CFG.warp_random),
        CFG.warp_y + math.random(0, CFG.warp_random)
    )
end


-- ===========================================================================
--  NPC entry points  (one set per race)
-- ===========================================================================

local function show_dialog()
    local ok, why = level_ok()

    dlg_title(CFG.msg_title)
    dlg_text(CFG.msg_text)

    if ok then
        dlg_menu(CFG.msg_enter, 'FarmZone_Gate_Enter()')
    else
        -- player sees a locked entry; still show the close button
        if why == "low" then
            cprint(CFG.msg_low)
        else
            cprint(CFG.msg_high)
        end
    end

    dlg_menu(CFG.msg_close, '')
    dlg_show()
end


function NPC_FarmZone_Gate_Deva_init()
    set_npc_name("@90100600")
end

function NPC_FarmZone_Gate_Deva_contact()
    show_dialog()
end


function NPC_FarmZone_Gate_Asura_init()
    set_npc_name("@90100600")
end

function NPC_FarmZone_Gate_Asura_contact()
    show_dialog()
end


function NPC_FarmZone_Gate_Gaia_init()
    set_npc_name("@90100600")
end

function NPC_FarmZone_Gate_Gaia_contact()
    show_dialog()
end


-- ===========================================================================
--  OPTIONAL: block entry while the player is in a party of >1
--  (farm zones are usually solo; uncomment if you want that)
-- ===========================================================================
-- function FarmZone_Gate_Enter()
--     if get_value("party_id") ~= 0 then
--         cprint("@9831")
--         return
--     end
--     ...
-- end
