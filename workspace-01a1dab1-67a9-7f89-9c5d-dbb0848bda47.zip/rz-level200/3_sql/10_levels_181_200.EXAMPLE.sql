-- ============================================================
--  مولّد تلقائياً بواسطة levelcurve.py
--  التاريخ: 2026-11-10
--  المصدر: جدول حقيقي 180 مستوى (1 → 180)
--  ⚠️  شغّل النسخة الاحتياطية الأول (سطر 11 في الملف)
-- ============================================================

USE [Arcadia];
GO

-- 0) نسخة احتياطية قبل أي حاجة
IF OBJECT_ID('dbo.LevelResource_bak_20261110') IS NULL
    SELECT * INTO dbo.LevelResource_bak_20261110 FROM dbo.LevelResource;
GO

SET NOCOUNT ON;
BEGIN TRANSACTION;

-- 1) شيل أي صفوف قديمة في نفس النطاق (عشان تمنع التكرار)
DELETE FROM dbo.[LevelResource]
 WHERE [level] BETWEEN 181 AND 200;

-- 2) إدخال المستويات الجديدة
-- ملاحظة: لو الجدول فيه أعمدة إجبارية تانية، استخدم
-- 3_sql/11_clone_row_template.sql بدل الجزء ده.
INSERT INTO dbo.[LevelResource] ([level], [exp]) VALUES
    (181, 899015),
    (182, 927784),
    (183, 957473),
    (184, 988112),
    (185, 1019732),
    (186, 1052363),
    (187, 1086039),
    (188, 1120792),
    (189, 1156657),
    (190, 1193670),
    (191, 1231868),
    (192, 1271288),
    (193, 1311969),
    (194, 1353952),
    (195, 1397278),
    (196, 1441991),
    (197, 1488135),
    (198, 1535755),
    (199, 1584900),
    (200, 1635616);

COMMIT TRANSACTION;
GO

-- 3) تحقق
SELECT * FROM dbo.[LevelResource]
 WHERE [level] BETWEEN 181 AND 200
 ORDER BY [level];
GO

-- 4) تراجع (لو حصلت مشكلة)
-- ROLLBACK TRANSACTION;
-- أو: DELETE FROM dbo.[LevelResource] WHERE [level] > 180;
