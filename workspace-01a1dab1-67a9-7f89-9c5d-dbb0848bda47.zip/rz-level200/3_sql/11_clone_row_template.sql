-- =============================================================================
--  11_clone_row_template.sql
--  الطريقة الآمنة لإضافة مستويات جديدة لو LevelResource فيه أعمدة إجبارية
--  كتير (زي HP/MP/نقاط/حاجات تانية) ومش عايز تحسبها كلها بإيدك.
--
--  الفكرة: بناخد آخر صف حقيقي (مثلاً 180)، بننسخه، وبنغيّر اللفل والخبرة بس.
--  كل الأعمدة التانية بتفضل زي ما هي — وده غالباً أحسن من إنك تخترع أرقام.
-- =============================================================================

USE [Arcadia];
GO
SET NOCOUNT ON;

-- غيّر الأرقام دي بس
DECLARE @fromLevel INT = 180;     -- آخر مستوى حقيقي
DECLARE @toLevel   INT = 200;     -- آخر مستوى عايز توصله
DECLARE @expColumn SYSNAME = 'exp';
DECLARE @lvlColumn SYSNAME = 'level';

-- 0) نسخة احتياطية
IF OBJECT_ID('dbo.LevelResource_bak_before_clone') IS NULL
    SELECT * INTO dbo.LevelResource_bak_before_clone FROM dbo.LevelResource;
GO

-- 1) نتأكد إن آخر لفل موجود فعلاً
SELECT MAX(level) AS [أقصى لفل حالي] FROM dbo.LevelResource;
GO

-- =============================================================================
--  2) النسخ الديناميكي: بيبني أسماء الأعمدة تلقائياً من sys.columns
--     ومش محتاج تعرفهم — السكربت بيتصرف لوحده.
-- =============================================================================
DECLARE @fromLevel INT = 180;
DECLARE @toLevel   INT = 200;
DECLARE @expColumn SYSNAME = 'exp';

DECLARE @cols NVARCHAR(MAX), @sql NVARCHAR(MAX), @lv INT;
DECLARE @growth DECIMAL(18,6) = 1.032;   -- نسبة النمو (خدها من تقرير levelcurve.py)

-- كل الأعمدة ما عدا اللي هنغيّرها
SELECT @cols = STRING_AGG(QUOTENAME(name), ', ')
FROM sys.columns
WHERE object_id = OBJECT_ID('dbo.LevelResource')
  AND name NOT IN ('level', @expColumn);

-- خبرة صف البداية
DECLARE @exp BIGINT =
    (SELECT CAST([exp] AS BIGINT) FROM dbo.LevelResource WHERE level = @fromLevel);

SET @lv = @fromLevel + 1;

WHILE @lv <= @toLevel
BEGIN
    SET @exp = CAST(@exp * @growth AS BIGINT);

    SET @sql = N'
        INSERT INTO dbo.LevelResource (' + @cols + N', [level], [' + @expColumn + N'])
        SELECT ' + @cols + N', @lv, @exp
        FROM dbo.LevelResource
        WHERE [level] = @from;';

    EXEC sp_executesql @sql,
         N'@lv INT, @exp BIGINT, @from INT',
         @lv = @lv, @exp = @exp, @from = @fromLevel;

    SET @lv = @lv + 1;
END
GO

-- 3) تحقق
SELECT * FROM dbo.LevelResource WHERE level > 180 ORDER BY level;
GO

-- 4) تراجع
-- DELETE FROM dbo.LevelResource WHERE level > 180;
-- GO
