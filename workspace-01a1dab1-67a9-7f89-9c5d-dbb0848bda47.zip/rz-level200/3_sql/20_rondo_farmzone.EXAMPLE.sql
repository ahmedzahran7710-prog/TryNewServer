-- ======================================================================
--  منطقة التجميع: Rondo Farm Zone 180-200
--  النطاق: لفل 180 → 200
--  مولّد بواسطة gen_farmzone_sql.py — 2026-11-10
-- ======================================================================

USE [Arcadia];
GO
SET NOCOUNT ON;

-- ----------------------------------------------------------------------
-- 0) نسخة احتياطية (لا تتخطى الخطوة دي)
-- ----------------------------------------------------------------------
IF OBJECT_ID('dbo.MonsterResource_bak_20261110') IS NULL
    SELECT * INTO dbo.MonsterResource_bak_20261110 FROM dbo.MonsterResource;
GO

-- ----------------------------------------------------------------------
-- 1) قبل التعديل: شوف الحالة الحالية (صوّر النتيجة أو خزّنها)
-- ----------------------------------------------------------------------
SELECT id, level, max_hp FROM dbo.[MonsterResource] WHERE id IN (1001,1002,1003,1004,1005,1006,1007,1008) ORDER BY level;
GO

-- ----------------------------------------------------------------------
-- 2) التعديل: توزيع اللفلات على النطاق المطلوب
--    (بيوزّع الوحوش بالتساوي من لفل 180 لـ 200)
-- ----------------------------------------------------------------------
BEGIN TRANSACTION;

UPDATE dbo.[MonsterResource] SET [level] = 180 WHERE id = 1001;   -- لفل 180
UPDATE dbo.[MonsterResource] SET [level] = 183 WHERE id = 1002;   -- لفل 183
UPDATE dbo.[MonsterResource] SET [level] = 186 WHERE id = 1003;   -- لفل 186
UPDATE dbo.[MonsterResource] SET [level] = 189 WHERE id = 1004;   -- لفل 189
UPDATE dbo.[MonsterResource] SET [level] = 191 WHERE id = 1005;   -- لفل 191
UPDATE dbo.[MonsterResource] SET [level] = 194 WHERE id = 1006;   -- لفل 194
UPDATE dbo.[MonsterResource] SET [level] = 197 WHERE id = 1007;   -- لفل 197
UPDATE dbo.[MonsterResource] SET [level] = 200 WHERE id = 1008;   -- لفل 200

-- 3) تعديل نقاط الحياة ×1.5 للوحوش المختارة
UPDATE dbo.[MonsterResource] SET [max_hp] = [max_hp] * 1.5
 WHERE id IN (1001,1002,1003,1004,1005,1006,1007,1008);

-- 4) تعديل الخبرة ×1.2
UPDATE dbo.[LevelResource] SET [exp] = [exp] * 1.2
 WHERE [level] BETWEEN 180 AND 200;

-- 5) تأكد إن الرقم منطقي قبل الـCOMMIT
SELECT id, level, max_hp FROM dbo.[MonsterResource] WHERE id IN (1001,1002,1003,1004,1005,1006,1007,1008) ORDER BY level;

-- لو كل حاجة تمام:
COMMIT TRANSACTION;
-- لو فيه مشكلة:
-- ROLLBACK TRANSACTION;
GO

-- ----------------------------------------------------------------------
-- 6) ملف التراجع (شغّله لو عايز ترجع كل حاجة زي ما كانت)
-- ----------------------------------------------------------------------
/*
DELETE FROM dbo.[MonsterResource];
INSERT INTO dbo.[MonsterResource] SELECT * FROM dbo.MonsterResource_bak_20261110;
DBCC CHECKIDENT ('dbo.MonsterResource', RESEED, 0);   -- لو فيه Identity
*/
GO

-- ----------------------------------------------------------------------
-- 7) تذكير: التعديل ده على جدول الوحوش بس.
--    لسه محتاج:
--      - كثافة الظهور  : monster_respawn.lua
--      - الدروب       : DropGroupResource
--      - بوابة الدخول : 4_lua/NPC_FarmZone_Gate.lua
-- ----------------------------------------------------------------------

-- المنطقة (region ids): 0