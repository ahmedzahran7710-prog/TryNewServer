-- =============================================================================
--  01_schema.sql  -  خطوة 1: اعرف شكل جدول LevelResource الحقيقي
--  شغّله على داتابيز Arcadia (SQL Server Management Studio)
--  الغرض: نعرف أسماء الأعمدة الحقيقية قبل أي تعديل. مفيش تعديل هنا.
-- =============================================================================

USE [Arcadia];
GO

-- 1) الأعمدة وأنواعها
SELECT
    c.column_id                AS [ترتيب],
    c.name                     AS [العمود],
    t.name                     AS [النوع],
    c.max_length               AS [الطول],
    c.is_nullable              AS [يقبل NULL],
    c.is_identity              AS [Identity]
FROM sys.columns c
JOIN sys.types  t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.LevelResource')
ORDER BY c.column_id;
GO

-- 2) المفاتيح والقيود
SELECT
    i.name                     AS [الفهرس],
    i.is_primary_key           AS [Primary Key],
    i.is_unique                AS [Unique],
    COL_NAME(ic.object_id, ic.column_id) AS [العمود]
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
WHERE i.object_id = OBJECT_ID('dbo.LevelResource');
GO

-- 3) أقصى لفل موجود فعلاً (ده الرقم اللي هيحدد من فين نبدأ)
SELECT
    COUNT(*)   AS [عدد الصفوف],
    MIN(level) AS [أقل لفل],
    MAX(level) AS [أقصى لفل]
FROM dbo.LevelResource;
GO

-- 4) أول 5 صفوف وآخر 10 صفوف (لو عايز تشوف الشكل بعينك)
SELECT TOP 5 * FROM dbo.LevelResource ORDER BY level ASC;
GO
SELECT TOP 10 * FROM dbo.LevelResource ORDER BY level DESC;
GO

-- 5) جدول البتس (لو هترفع لفله كمان) - لاحظ الاسم مكتوب Resouce في بعض النسخ
IF OBJECT_ID('dbo.SummonLevelResource') IS NOT NULL
    SELECT TOP 5 * FROM dbo.SummonLevelResource ORDER BY level DESC;
ELSE IF OBJECT_ID('dbo.SummonLevelResouce') IS NOT NULL
    SELECT TOP 5 * FROM dbo.SummonLevelResouce ORDER BY level DESC;
GO

-- =============================================================================
--  لو ظهر إن أسماء الأعمدة مختلفة عن [level] و [exp]،
--  خد الأسماء الحقيقية من نتيجة الاستعلام 1 وضعها في الأمر اللي بعده.
-- =============================================================================
