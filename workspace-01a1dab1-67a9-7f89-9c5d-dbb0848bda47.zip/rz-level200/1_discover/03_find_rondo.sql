-- =============================================================================
--  03_find_rondo.sql  -  خطوة 3: دوّر على "منطقة Rondo" والوحوش اللي فيها
--  الهدف: تطلع بالمعرّفات الحقيقية اللي هنبني عليها منطقة التجميع.
--  مفيش تعديل هنا — استعلامات قراءة بس.
-- =============================================================================

USE [Arcadia];
GO

-- =============================================================================
-- (1)  كل الجداول اللي اسمها فيه Region أو Area أو Map أو World
-- =============================================================================
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME LIKE '%Region%'
   OR TABLE_NAME LIKE '%Area%'
   OR TABLE_NAME LIKE '%Map%'
   OR TABLE_NAME LIKE '%World%'
ORDER BY TABLE_NAME;
GO

-- =============================================================================
-- (2)  شكل جدول MonsterResource — الأعمدة الحقيقية
-- =============================================================================
SELECT c.column_id, c.name AS [العمود], t.name AS [النوع]
FROM sys.columns c
JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.MonsterResource')
ORDER BY c.column_id;
GO

-- =============================================================================
-- (3)  دور على أي عمود فيه "region" أو "area" في كل الجداول
--      ده هيوريك فين الخريطة متسجلة بالظبط
-- =============================================================================
SELECT
    OBJECT_NAME(c.object_id) AS [الجدول],
    c.name                  AS [العمود],
    t.name                  AS [النوع]
FROM sys.columns c
JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.name LIKE '%region%'
   OR c.name LIKE '%area%'
   OR c.name LIKE '%zone%'
ORDER BY [الجدول], c.column_id;
GO

-- =============================================================================
-- (4)  لو عندك جدول Region: اعرض كل المناطق بأسماءها
--      غيّر أسماء الأعمدة لو مختلفة (شوف استعلام 1)
-- =============================================================================
IF OBJECT_ID('dbo.RegionResource') IS NOT NULL
BEGIN
    SELECT * FROM dbo.RegionResource ORDER BY 1;
END
GO

-- =============================================================================
-- (5)  توزيع الوحوش على المناطق — ده أهم استعلام في الملف
--      بيوريك كل منطقة وكام وحش فيها وأقل/أعلى لفل
-- =============================================================================
IF COL_LENGTH('dbo.MonsterResource', 'region_id') IS NOT NULL
BEGIN
    SELECT
        m.region_id      AS [المنطقة],
        COUNT(*)         AS [عدد الوحوش],
        MIN(m.level)     AS [أقل لفل],
        MAX(m.level)     AS [أعلى لفل]
    FROM dbo.MonsterResource m
    GROUP BY m.region_id
    ORDER BY m.region_id;
END
ELSE
    PRINT 'مفيش عمود region_id في MonsterResource — شوف استعلام (3) عشان تلاقي اسم العمود الصح';
GO

-- =============================================================================
-- (6)  الوحوش اللي اسمها فيه Rondo (لو الأسماء موجودة في الجدول)
-- =============================================================================
IF COL_LENGTH('dbo.MonsterResource', 'name_id') IS NOT NULL
BEGIN
    SELECT TOP 100 *
    FROM dbo.MonsterResource
    WHERE name_id IN (
        SELECT id FROM dbo.StringResource WHERE [text] LIKE '%Rondo%'
    )
    ORDER BY level;
END
GO

-- =============================================================================
-- (7)  كل الوحوش اللي لفلها بين 170 و 210 — دي قايمة المرشحين
-- =============================================================================
SELECT TOP 500
    id, name_id, level
    , CASE WHEN COL_LENGTH('dbo.MonsterResource', 'max_hp') IS NOT NULL THEN 'ok' ELSE 'no' END AS [فيه hp]
FROM dbo.MonsterResource
WHERE level BETWEEN 170 AND 210
ORDER BY level, id;
GO

-- =============================================================================
-- (8)  مجموعات الدروب — عشان نعرف نربط دروب جديد
-- =============================================================================
SELECT c.column_id, c.name AS [العمود], t.name AS [النوع]
FROM sys.columns c
JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.DropGroupResource')
ORDER BY c.column_id;
GO

SELECT TOP 20 * FROM dbo.DropGroupResource ORDER BY 1;
GO

-- =============================================================================
-- (9)  الـNPCs — عشان نضيف بوابة المنطقة
-- =============================================================================
SELECT TOP 30 * FROM dbo.NPCResource ORDER BY 1;
GO

-- =============================================================================
-- (10) نسخة احتياطية للجداول اللي هتلمسها (شغّلها قبل أي تعديل!)
-- =============================================================================
-- SELECT * INTO dbo.MonsterResource_bak_20261110 FROM dbo.MonsterResource;
-- SELECT * INTO dbo.LevelResource_bak_20261110    FROM dbo.LevelResource;
-- SELECT * INTO dbo.NPCResource_bak_20261110      FROM dbo.NPCResource;
-- GO
