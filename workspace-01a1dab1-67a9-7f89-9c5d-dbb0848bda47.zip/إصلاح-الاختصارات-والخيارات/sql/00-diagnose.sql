/* ============================================================
   إصلاح الاختصارات — 00-diagnose.sql   (قراءة فقط / READ ONLY)
   شغّله في SSMS على أي قاعدة، وابعت النتائج
   ============================================================ */

/* ---------- 1) القواعد الموجودة ---------- */
SELECT name, state_desc, recovery_model_desc
FROM sys.databases
ORDER BY name;
GO

/* ---------- 2) هل الـ Linked Server باسم BILLING موجود؟ ---------- */
SELECT srvname, srvproduct, provider, datasource, is_linked
FROM sys.servers
ORDER BY is_linked DESC, srvname;
GO

/* ---------- 3) اختبار فعلي: هل نقدر نوصل لـ BILLING؟ ---------- */
BEGIN TRY
    EXEC sp_tables_ex @table_server = N'BILLING';
    SELECT 'BILLING linked server: OK' AS result;
END TRY
BEGIN CATCH
    SELECT 'BILLING linked server: FAILED -> ' + ERROR_MESSAGE() AS result;
END CATCH
GO

/* ---------- 4) جداول قاعدة BILLING (لو التقارير فوق فشلت، شغّل على BILLING مباشرة) ---------- */
USE [BILLING];
GO
SELECT TABLE_SCHEMA, TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;
GO

/* ---------- 5) الجداول/الأعمدة اللي لها علاقة بالخيارات والاختصارات ---------- */
USE [BILLING];
GO
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS
WHERE COLUMN_NAME LIKE '%key%'
   OR COLUMN_NAME LIKE '%option%'
   OR COLUMN_NAME LIKE '%shortcut%'
   OR COLUMN_NAME LIKE '%macro%'
   OR COLUMN_NAME LIKE '%config%'
   OR COLUMN_NAME LIKE '%setting%'
   OR COLUMN_NAME LIKE '%hotkey%'
ORDER BY TABLE_NAME, COLUMN_NAME;
GO

/* ---------- 6) هل توجد Stored Procedures في Telecaster بتستخدم BILLING؟ ---------- */
USE [Telecaster1];
GO
SELECT o.type_desc, o.name
FROM sys.sql_modules m
JOIN sys.objects o ON o.object_id = m.object_id
WHERE m.definition LIKE '%BILLING%'
ORDER BY o.name;
GO

/* ---------- 7) هل dbo.PaidItem موجود؟ ---------- */
USE [Telecaster1];
GO
SELECT CASE WHEN OBJECT_ID('dbo.PaidItem') IS NULL
            THEN 'dbo.PaidItem MISSING'
            ELSE 'dbo.PaidItem OK' END AS paiditem_check;
GO

/* ---------- 8) متابعة الكتابة: شغّل قبل/بعد حفظ الاختصارات ---------- */
USE [BILLING];
GO
SELECT t.name AS table_name,
       SUM(p.rows) AS row_count
FROM sys.tables t
JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0,1)
GROUP BY t.name
ORDER BY t.name;
GO
