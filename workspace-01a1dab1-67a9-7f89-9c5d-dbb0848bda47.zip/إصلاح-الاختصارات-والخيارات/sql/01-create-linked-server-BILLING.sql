/* ============================================================
   01-create-linked-server-BILLING.sql
   الحل الجذري: تعريف Linked Server اسمه BILLING
   (ده اللي بيخلي السيرفر يقدر يحفظ اختصارات اللاعب وخياراته)

   شغّله على قاعدة master
   عدّل السطر اللي فيه  <<SA_PASSWORD>>  قبل التشغيل
   ============================================================ */

USE [master];
GO

/* ---------- 0) لو موجود بالفعل: امسحه الأول (idempotent) ---------- */
IF EXISTS (SELECT 1 FROM sys.servers WHERE name = N'BILLING' AND is_linked = 1)
BEGIN
    EXEC sp_dropserver @server = N'BILLING', @droplogins = 'droplogins';
    PRINT 'Old BILLING linked server dropped.';
END
GO

/* ---------- 1) إنشاء الـ Linked Server ---------- */
EXEC sp_addlinkedserver
     @server     = N'BILLING',
     @srvproduct = N'',
     @provider   = N'SQLNCLI',
     @datasrc    = N'127.0.0.1';
GO

/* ---------- 2) بيانات الدخول ---------- */
/*  اختر واحد من الخيارين (شيل علامة التعليق عن اللي تختاره)  */

-- الخيار A: حساب sa (اكتب الباسورد الحقيقي مكان <<SA_PASSWORD>>)
/*
EXEC sp_addlinkedsrvlogin
     @rmtsrvname  = N'BILLING',
     @useself     = N'FALSE',
     @rmtuser     = N'sa',
     @rmtpassword = N'<<SA_PASSWORD>>';
GO
*/

-- الخيار B: استخدام حساب خدمة SQL نفسه (بدون باسورد)
EXEC sp_addlinkedsrvlogin
     @rmtsrvname = N'BILLING',
     @useself    = N'TRUE';
GO

/* ---------- 3) اختبار ---------- */
BEGIN TRY
    EXEC sp_tables_ex @table_server = N'BILLING';
    PRINT '>>> SUCCESS: BILLING linked server works.';
END TRY
BEGIN CATCH
    PRINT '>>> FAILED: ' + ERROR_MESSAGE();
    PRINT '>> Try the sa option (A) with a valid password.';
END CATCH
GO

/* ---------- 4) للتراجع (rollback) ---------- */
/*
EXEC sp_dropserver @server = N'BILLING', @droplogins = 'droplogins';
GO
*/
