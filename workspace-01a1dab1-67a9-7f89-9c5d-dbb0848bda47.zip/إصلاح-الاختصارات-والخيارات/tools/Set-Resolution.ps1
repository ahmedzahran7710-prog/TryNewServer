# ==================================================================
#  Set-Resolution.ps1   -- ASCII only
#  Sets the Rappelz CLIENT resolution by editing rappelz_v1.opt
#  (the in-game combo is greyed out while a graphics preset is active)
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File Set-Resolution.ps1 -Width 1280 -Height 800 -Windowed 1
#    powershell -ExecutionPolicy Bypass -File Set-Resolution.ps1 -Width 1280 -Height 800 -Windowed 0 -ReadOnly
# ==================================================================

param(
    [int]$Width    = 1280,
    [int]$Height   = 800,
    [int]$Windowed = 1,
    [switch]$ReadOnly,
    [string]$ClientPath = ""
)

$ErrorActionPreference = "Stop"
function Say($t, $c = "Gray") { Write-Host $t -ForegroundColor $c }

Say ""
Say "==============================================" Cyan
Say "   Rappelz client resolution setter" Cyan
Say "==============================================" Cyan
Say ""

# ---------- 1) locate rappelz_v1.opt ----------
$opt = $null
if ($ClientPath -ne "") {
    $p = Join-Path $ClientPath "rappelz_v1.opt"
    if (Test-Path $p) { $opt = $p }
}

if (-not $opt) {
    $roots = @("C:\", "D:\", "E:\", "F:\")
    foreach ($r in $roots) {
        if (-not (Test-Path $r)) { continue }
        $found = Get-ChildItem $r -Recurse -Filter "rappelz_v1.opt" -File -ErrorAction SilentlyContinue |
                 Select-Object -First 1
        if ($found) { $opt = $found.FullName; break }
    }
}

if (-not $opt) {
    Say "rappelz_v1.opt not found." Red
    Say "Run again with:  -ClientPath \"C:\Path\To\RappelzClient\"" Yellow
    exit 1
}

$dir = Split-Path $opt -Parent
Say "Client folder : $dir" Green

# ---------- 2) backup ----------
$stamp  = Get-Date -Format "yyyyMMdd-HHmmss"
$bdir   = "F:\AhmedZahran\rz-backup\client-opt-$stamp"
if (-not (Test-Path "F:\AhmedZahran\rz-backup")) { $bdir = Join-Path $dir "client-opt-backup-$stamp" }
New-Item -ItemType Directory -Path $bdir -Force | Out-Null
Copy-Item $opt (Join-Path $bdir "rappelz_v1.opt") -Force
Say "Backup        : $bdir" Green

# ---------- 3) make sure the file is writable ----------
(Get-Item $opt).IsReadOnly = $false

# ---------- 4) rewrite the needed keys ----------
$want = [ordered]@{
    "GRAPHIC_RESOLUTION_WIDTH"  = $Width
    "GRAPHIC_RESOLUTION_HEIGHT" = $Height
    "GRAPHIC_WINMODE"           = $Windowed
    "GRAPHIC_REFRESHRATE"       = 1
    "GRAPHIC_PRESETOPTION"      = 0
}

$lines = Get-Content $opt
$seen  = @{}
$out   = foreach ($line in $lines) {
    $matched = $false
    foreach ($k in $want.Keys) {
        if ($line -match "^\s*$k\s*=") {
            $seen[$k] = $true
            $matched = $true
            "$k=$($want[$k])"
            break
        }
    }
    if (-not $matched) { $line }
}

foreach ($k in $want.Keys) {
    if (-not $seen[$k]) { $out = @($out) + "$k=$($want[$k])" }
}

Set-Content -Path $opt -Value $out -Encoding ASCII

Say ""
Say "APPLIED:" Cyan
foreach ($k in $want.Keys) { Say ("   " + $k + "=" + $want[$k]) }
Say ""

if ($ReadOnly) {
    (Get-Item $opt).IsReadOnly = $true
    Say "File set to READ-ONLY (game cannot revert it)." Yellow
    Say "To change later: right click the file -> Properties -> uncheck Read-only." Yellow
}

Say "NEXT:" Cyan
Say "  1. start the game" Cyan
Say "  2. if the game still shows the old size, open Options -> Game Environment," Cyan
Say "     set the preset combo to 'Custom / User' and press Apply" Cyan
Say "  3. exit through ESC -> character select -> quit (never Alt+F4)" Cyan
Say ""
