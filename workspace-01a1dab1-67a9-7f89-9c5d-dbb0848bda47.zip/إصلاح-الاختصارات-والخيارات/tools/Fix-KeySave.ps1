# ==================================================================
#  Fix-KeySave.ps1   -- ASCII only
#  Purpose: make Rappelz save player key bindings / skill-bar
#           (fixes the "key settings empty after every launch" bug)
#
#  What it does:
#    1. finds the server folder
#    2. backs up GameServer.opt + GameServer.eop
#         to F:\AhmedZahran\rz-backup\opt-<timestamp>\
#    3. sets  T:game.cash_usable_server:0   (or back to 1 with -Cash 1)
#    4. deletes the stale GameServer.eop
#    5. tries to rebuild the .eop automatically
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File Fix-KeySave.ps1
#    powershell -ExecutionPolicy Bypass -File Fix-KeySave.ps1 -Cash 1
# ==================================================================

param(
    [int]$Cash = 0
)

$ErrorActionPreference = "Stop"

function Say($t, $c = "Gray") { Write-Host $t -ForegroundColor $c }

Say ""
Say "==============================================" Cyan
Say "   Rappelz - fix key bindings not saving" Cyan
Say "==============================================" Cyan
Say ""

# ---------------- 1) locate server folder ----------------
$candidates = @(
    "C:\RZ\Server\FilesOfficial-Revolution9.1",
    "C:\RZ\Server\GameEngine",
    "C:\RZ\Server",
    "F:\RZ\Server"
)

$optPath = $null
foreach ($c in $candidates) {
    $p1 = Join-Path $c "GameServer.opt"
    $p2 = Join-Path $c "GameEngine\GameServer.opt"
    if (Test-Path $p1) { $optPath = $p1; break }
    if (Test-Path $p2) { $optPath = $p2; break }
}

if (-not $optPath -and (Test-Path "C:\RZ")) {
    $found = Get-ChildItem "C:\RZ" -Recurse -Filter "GameServer.opt" -File -ErrorAction SilentlyContinue |
             Select-Object -First 1
    if ($found) { $optPath = $found.FullName }
}

if (-not $optPath) {
    Say "GameServer.opt not found. Edit the paths at the top of this script." Red
    exit 1
}

$optDir  = Split-Path $optPath -Parent
$eopPath = Join-Path $optDir "GameServer.eop"

Say "Found: $optPath" Green

# ---------------- 2) backup ----------------
$stamp   = Get-Date -Format "yyyyMMdd-HHmmss"
$backup  = "F:\AhmedZahran\rz-backup\opt-$stamp"
if (-not (Test-Path "F:\AhmedZahran\rz-backup")) {
    Say "WARNING: F:\AhmedZahran\rz-backup does not exist - using .\opt-backup" Yellow
    $backup = Join-Path $optDir "opt-backup-$stamp"
}
New-Item -ItemType Directory -Path $backup -Force | Out-Null

Copy-Item $optPath (Join-Path $backup "GameServer.opt") -Force
if (Test-Path $eopPath) { Copy-Item $eopPath (Join-Path $backup "GameServer.eop") -Force }
Say "Backup -> $backup" Green

# ---------------- 3) edit the setting ----------------
$lines = Get-Content $optPath
$changed = $false
$out = foreach ($line in $lines) {
    if ($line -match '^\s*[TN]:game\.cash_usable_server\s*:') {
        $changed = $true
        ($line -replace ':\s*-?\d+\s*$', ":$Cash")
    } else {
        $line
    }
}

if (-not $changed) {
    $out = @($out) + "T:game.cash_usable_server:$Cash"
    Say "Line was missing - appended." Yellow
}

Set-Content -Path $optPath -Value $out -Encoding ASCII
Say "game.cash_usable_server = $Cash" Green

# ---------------- 4) remove stale eop ----------------
if (Test-Path $eopPath) {
    Remove-Item $eopPath -Force
    Say "Deleted old GameServer.eop" Green
}

# ---------------- 5) try to rebuild eop ----------------
$compress = $null
foreach ($n in @("RappelzCompress_v2.exe", "RappelzCompress.exe")) {
    $p = Join-Path $optDir $n
    if (Test-Path $p) { $compress = $p; break }
    $p = Join-Path (Split-Path $optDir -Parent) $n
    if (Test-Path $p) { $compress = $p; break }
}

if ($compress) {
    Say "Trying: $compress GameServer.opt" Yellow
    try {
        Start-Process -FilePath $compress -ArgumentList "`"$optPath`"" -Wait -ErrorAction Stop
    } catch {
        Say "Automatic compress failed (normal - the tool is drag&drop only)." Yellow
    }
    if (Test-Path $eopPath) { Say "GameServer.eop rebuilt automatically." Green }
}

if (-not (Test-Path $eopPath)) {
    Say ""
    Say "MANUAL STEP (fast):" Cyan
    Say "  1. open the folder: $optDir" Cyan
    Say "  2. run RappelzCompress_v2.exe" Cyan
    Say "  3. drag GameServer.opt and drop it inside the small window" Cyan
    Say "  4. a new GameServer.eop appears" Cyan
}

Say ""
Say "DONE. Now restart the server and test:" Cyan
Say "  in game: set your keys -> Apply/Save -> logout to character select -> Quit" Cyan
Say "  relaunch the game -> the keys must still be there." Cyan
Say ""
