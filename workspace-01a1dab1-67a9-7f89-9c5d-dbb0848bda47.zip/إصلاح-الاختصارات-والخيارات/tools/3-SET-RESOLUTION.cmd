@echo off
REM ASCII ONLY - CRLF
cd /d "%~dp0"
set /p W=Width  (e.g. 1280): 
set /p H=Height (e.g. 800): 
set /p M=Windowed? 1=window  0=fullscreen: 
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Set-Resolution.ps1" -Width %W% -Height %H% -Windowed %M%
echo.
pause
