@echo off
REM revert cash_usable_server back to 1
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Fix-KeySave.ps1" -Cash 1
echo.
pause
