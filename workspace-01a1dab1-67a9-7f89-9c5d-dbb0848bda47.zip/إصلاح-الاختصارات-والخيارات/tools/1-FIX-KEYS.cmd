@echo off
REM ASCII ONLY - CRLF required
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Fix-KeySave.ps1"
echo.
pause
