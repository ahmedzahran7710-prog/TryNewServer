# -*- coding: utf-8 -*-
"""يبني rz-setup-checklist.docx — تشيك ليست تشغيل السيرفر من الصفر."""
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import sys
sys.path.insert(0, "/home/user/rz-level200")
from docx_helpers import (Doc, NAVY, BLUE, RED, GREEN, GREY, WHITE,
                          rtl_par, rtl_run, shade, bidi_table)

D = Doc()
BOX = "[    ]"


def check(text, note=None):
    par = D.d.add_paragraph()
    rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT if False else WD_ALIGN_PARAGRAPH.RIGHT)
    par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf = par.paragraph_format
    pf.right_indent = __import__("docx").shared.Cm(0.5)
    pf.space_after = Pt(3)
    pf.line_spacing = 1.22
    r = par.add_run(BOX + "  ")
    r.font.name = "Consolas"
    r.font.size = Pt(12)
    r.font.color.rgb = NAVY
    rtl_run(r)
    r2 = par.add_run(text)
    r2.font.size = Pt(10.5)
    rtl_run(r2)
    if note:
        r3 = par.add_run("   — " + note)
        r3.font.size = Pt(9)
        r3.font.color.rgb = GREY
        r3.italic = True
        rtl_run(r3)


# ---------------------------------------------------------------- title
t = D.d.add_table(rows=1, cols=1)
bidi_table(t)
c = t.cell(0, 0)
shade(c, "1F3864")
c.paragraphs[0]._p.getparent().remove(c.paragraphs[0]._p)
p = c.add_paragraph(); rtl_par(p, WD_ALIGN_PARAGRAPH.CENTER)
p.paragraph_format.space_before = Pt(10); p.paragraph_format.space_after = Pt(3)
r = p.add_run("تشغيل سيرفر Rappelz 9.1 — تشيك ليست")
r.bold = True; r.font.size = Pt(19); r.font.color.rgb = WHITE; rtl_run(r)
p2 = c.add_paragraph(); rtl_par(p2, WD_ALIGN_PARAGRAPH.CENTER)
p2.paragraph_format.space_after = Pt(10)
r2 = p2.add_run("اطبعها  •  علّم على كل خطوة  •  متتخطاش خطوة")
r2.font.size = Pt(10); r2.font.color.rgb = RGBColor(0xDC, 0xE6, 0xF1); rtl_run(r2)

D.p("", space_after=4)
D.p("الترتيب مهم. كل مرحلة بتفتح اللي بعدها. لو خطوة فشلت، متكمّلش — صلّحها الأول.",
    size=10, color=GREY, align=WD_ALIGN_PARAGRAPH.CENTER)

# ---------------------------------------------------------------- 0
D.h1("٠", "الملفات — تأكد إنها كاملة")
check("فكيت `FilesOfficial-Revolution9.1` في مسار قصير", "C:\\RZ\\Server")
check("جوه الفولدر ٦ فولدرات + ReadMe", "dbs · GameEngine · GameGuard · Launcher · RDU · SFrame")
check("`dbs/Arcadia.bak` = ~١٧٠ ميجا", "لو أصغر → فك الضغط ناقص")
check("`dbs/Telecaster.bak` = ~٢٢٥ ميجا")
check("`dbs/Billing.bak` = ~١٣ ميجا")
check("الكلاينت 9.1 اتحمّل", "~٢.٤ جيجا — ابدأه بدري، بياخد وقت")

# ---------------------------------------------------------------- 1
D.h1("١", "تثبيت SQL Server")
check("ثبّت SQL Server 2019 Express")
check("اخترت **Mixed Mode Authentication**", "مش Windows only")
check("حطيت باسورد قوي لـ `sa` وحفظته")
check("فعّلت **TCP/IP** في SQL Server Configuration Manager")
check("أعدت تشغيل خدمة SQL Server بعد تفعيل TCP/IP")
check("ثبّت SSMS وفتح واتصل بالسيرفر", "لو مش عارف تتصل: جرّب `.\\SQLEXPRESS`")

# ---------------------------------------------------------------- 2
D.h1("٢", "ترجيع الداتابيز التلاتة")
D.p("SSMS → كليك يمين على Databases → Restore Database → Device → Add → اختار الملف.", size=10)
check("`Arcadia` اترجّعت", "الأهم — فيها كل جداول اللعبة")
check("`Billing` اترجّعت")
check("`Telecaster` اترجّعت")
check("شفت الجداول بعينك", "Arcadia → Tables → لازم تلاقي ItemResource و MonsterResource")

# ---------------------------------------------------------------- 3
D.h1("٣", "إعداد ملفات السيرفر (.opt)")
check("فتحت `GameEngine/Auth_bin/*.opt`")
check("فتحت `GameEngine/Game_bin/*.opt`")
check("اسم الداتابيز في `db.auth.name` مظبوط", "الافتراضي في الباكدج غلط — لازم يبقى `Auth`")
check("بورت SQL = 1433", "ونفس الرقم في إعدادات السيرفر")
check("اسم مستخدم وباسورد SQL مظبوطين", "نفس اللي عملته في التثبيت")
check("عملت نسخة `.bak` من كل ملف .opt", "قبل أي تعديل")

# ---------------------------------------------------------------- 4
D.h1("٤", "تشغيل السيرفر — بالترتيب")
D.p("متحاولش تشغّل الاتنين مع بعض في أول مرة. واحد واحد.", size=10, color=RED)
check("شغّلت سيرفر **Auth** الأول", "استنى لحد ما يقول إنه اتصل بالداتابيز")
check("مفيش أخطاء SQL في الكونسول", "لو فيه → ارجع للمرحلة ٢ و٣")
check("شغّلت سيرفر **Game** بعده")
check("الكونسول بيقول `Server ready` أو مشابه", "مش بيقفل لوحده")
check("شغّلت **Log** (اختياري)")

# ---------------------------------------------------------------- 5
D.h1("٥", "الحساب والكلاينت")
check("عملت حساب في الداتابيز", "جدول المستخدمين في Billing أو Auth — حسب نسختك")
check("ظبطت `ip` في الكلاينت على `127.0.0.1`")
check("اللانشر بيفتح من فولدر الكلاينت")
check("دخلت اللعبة وعملت شخصية")

# ---------------------------------------------------------------- 6
D.h1("٦", "أعطال شائعة — الحل السريع")
rows = [
    ["السيرفر بيقفل فوراً", "مش لاقي الداتابيز أو الباسورد غلط", "افتح اللوج، وشوف آخر سطر خطأ"],
    ["Can't connect to SQL", "TCP/IP مقفول أو البورت مش 1433", "Configuration Manager → فعّل TCP/IP + أعد التشغيل"],
    ["Login failed for user", "Mixed Mode مش مفعّل", "أعد تثبيت الـInstance باختيار Mixed Mode"],
    ["الكلاينت بيقفل عند الدخول", "إصدار الكلاينت مش 9.1", "نزّل كلاينت 9.1 بالظبط"],
    ["اللانشر مش بيفتح", "محتاج VC++ Redistributable", "نزّل Visual C++ 2010/2013 x86 وx64"],
    ["الداتابيز بترفض ترجيع", "مسار .bak فيه مسافات أو صلاحيات", "انقل الملف لـ`C:\\RZ\\bak` وجرب"],
]
D.table(["العطل", "السبب", "الحل"], rows, widths=[5.0, 5.4, 6.2], size=8.5)

D.spacer(10)
D.p("ملاحظة: أرقام البورتات والمسارات بتختلف شوية بين نسخة ونسخة. لو رقم مش مطابق، "
    "دوّر في نفس الملف .opt على الكلمة المفتاحية (port / db / auth) واقرأ الرقم الحقيقي عندك — "
    "هو ده الصح، مش أي رقم برّه.",
    size=9.5, color=GREY)

D.save("/home/user/rz-setup-checklist.docx")
print("saved")
