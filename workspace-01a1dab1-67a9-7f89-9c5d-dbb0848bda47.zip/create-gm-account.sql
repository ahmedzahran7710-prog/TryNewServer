/* =============================================================
   Rappelz 9.1 — إنشاء حساب الجي إم (المرحلة 1)
   يُشغَّل في SSMS → New Query  (Windows Authentication)
   ============================================================= */

USE Auth;
GO

/* -------------------------------------------------------------
   عدّل الاسم والباسورد قبل التشغيل.
   IMPORTANT: الباسورد = md5( salt + password )
   والـ salt لازم يطابق auth.db.salt في C:\RZ\rzauth\auth.opt
   ------------------------------------------------------------- */
DECLARE @login    NVARCHAR(32) = N'gmadmin';
DECLARE @password NVARCHAR(32) = N'Gm@Pass2026';     -- بدّلها لباسورد قوي خاص بك
DECLARE @salt     NVARCHAR(64) = N'A4&8zx209z&8zx267Ope';

IF EXISTS (SELECT 1 FROM dbo.Accounts WHERE login_name = @login)
BEGIN
    PRINT 'الحساب موجود بالفعل — لم يتم إنشاء حساب جديد.';
END
ELSE
BEGIN
    INSERT INTO dbo.Accounts
      (login_name, password, block, withdraw_remain_time, age, auth_ok, pcbang, last_login_server_idx, event_code)
    VALUES
      (@login,
       LOWER(CONVERT(VARCHAR(32), HashBytes('MD5', @salt + @password), 2)),
       0, 0, 18, 1, 1, 0, 0);
    PRINT 'تم إنشاء الحساب: ' + @login;
END
GO

-- تحقق
SELECT account_id, login_name, password, block, auth_ok, age
FROM dbo.Accounts
ORDER BY account_id;
GO
