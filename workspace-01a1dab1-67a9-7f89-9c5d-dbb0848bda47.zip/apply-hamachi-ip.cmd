@echo off
setlocal
chcp 65001 >nul
title RZ - Apply Hamachi IP to GameServer.opt

set "GS=C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin"
set "IP=25.21.212.130"

echo ============================================================
echo  Rappelz 9.1 - Hamachi IP patcher
echo  Target : %GS%\GameServer.opt
echo  New IP : %IP%
echo ============================================================
echo.

if not exist "%GS%\GameServer.opt" (
  echo [X] GameServer.opt not found. Edit the GS= line in this file.
  pause & exit /b 1
)

echo [1/4] Backup...
if not exist "%GS%\GameServer.opt.BEFORE-HAMACHI" copy /y "%GS%\GameServer.opt" "%GS%\GameServer.opt.BEFORE-HAMACHI" >nul
if not exist "%GS%\GameServer.eop.BEFORE-HAMACHI"  copy /y "%GS%\GameServer.eop"  "%GS%\GameServer.eop.BEFORE-HAMACHI"  >nul
echo      done.

echo [2/4] Patching io.ip_address ...
powershell -NoProfile -Command "$p='%GS%\GameServer.opt'; $t=Get-Content -Raw -Encoding Default $p; $t=$t -replace 'io\.ip_address:127\.0\.0\.1','io.ip_address:%IP%'; [IO.File]::WriteAllText($p,$t,[Text.Encoding]::Default)"
echo      done.

echo [3/4] Verify:
findstr /C:"io.ip_address" "%GS%\GameServer.opt"
echo.

echo [4/4] Recompressing to GameServer.eop ...
cd /d "%GS%"
if exist RappelzCompress.exe (
   RappelzCompress.exe GameServer.opt
) else (
   echo      [!] RappelzCompress.exe not found in that folder - recompress manually.
)
echo.
echo ============================================================
echo  Check that GameServer.eop timestamp is NOW, then start:
echo    LogServer.exe  -^>  rzauth.exe  -^>  CaptainHerlockServer.exe
echo ============================================================
pause
