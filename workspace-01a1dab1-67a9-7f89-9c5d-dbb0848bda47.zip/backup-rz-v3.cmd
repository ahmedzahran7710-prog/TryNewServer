@echo off
setlocal
chcp 65001 >nul
title RZ - Database Backup (F: drive)

rem ============================================================
rem  Rappelz 9.1 - backup all databases to F:\AhmedZahran\rz-backup
rem  Right click -> Run as administrator
rem  Read-only + BACKUP. Never modifies game data.
rem  v3: SQL Server EXPRESS detected -> COMPRESSION removed
rem      (Msg 1844: WITH COMPRESSION is not supported on Express)
rem      + lists all databases so we can see their real names
rem ============================================================

set "DEST=F:\AhmedZahran\rz-backup"
set "SQLSRV=."

echo.
echo ============================================================
echo   DESTINATION : %DEST%
echo   SQL SERVER  : %SQLSRV%
echo ============================================================
echo.

echo [1/6] Creating folder...
if not exist "%DEST%" mkdir "%DEST%" 2>nul
if not exist "%DEST%" (
    echo [X] Cannot create %DEST% - run as administrator.
    pause & exit /b 1
)
echo       ok.

echo.
echo [2/6] SQL Server edition:
sqlcmd -S %SQLSRV% -E -h -1 -W -Q "SET NOCOUNT ON; SELECT CAST(SERVERPROPERTY('Edition') AS VARCHAR(80)) + '  |  ' + CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(40))"

echo.
echo [3/6] All databases on this instance (real names + size):
sqlcmd -S %SQLSRV% -E -W -Q "SET NOCOUNT ON; SELECT d.name AS [database], d.state_desc AS [state], CAST(SUM(mf.size)*8.0/1024 AS DECIMAL(10,1)) AS [SizeMB] FROM sys.databases d LEFT JOIN sys.master_files mf ON mf.database_id = d.database_id GROUP BY d.name, d.state_desc ORDER BY [SizeMB] DESC"

echo [4/6] Free space on each drive...
powershell -NoProfile -Command "Get-PSDrive -PSProvider FileSystem | Where-Object {$_.Used -ne $null} | Select-Object Name, @{n='FreeGB';e={[math]::Round($_.Free/1GB,1)}}, @{n='UsedGB';e={[math]::Round($_.Used/1GB,1)}} | Format-Table -AutoSize"

echo [5/6] Giving the SQL Server service account write access...
powershell -NoProfile -Command "$svc=(Get-CimInstance Win32_Service | Where-Object {$_.Name -like 'MSSQL*' -and $_.Name -notmatch 'Agent|Browser|FDLauncher|CEIP|Telemetry|Writer|Polybase|Launcher'} | Select-Object -First 1).StartName; if($svc){ Write-Host ('      SQL service account = '+$svc); icacls '%DEST%' /grant ($svc+':(OI)(CI)M') | Out-Null; Write-Host '      permission granted.' } else { Write-Host '      [!] SQL service not found.' }"

echo.
echo [6/6] Backing up databases (no compression - Express edition)...
call :BACKUP Auth
call :BACKUP Telecaster1
call :BACKUP Arcadia
call :BACKUP ArcadiaInfo
call :BACKUP Billing

echo.
echo ==================== VERIFY ====================
call :VERIFY Auth
call :VERIFY Telecaster1
call :VERIFY Arcadia
call :VERIFY ArcadiaInfo
call :VERIFY Billing

echo.
echo ==================== RESULT ====================
powershell -NoProfile -Command "Get-ChildItem '%DEST%\*.bak' -ErrorAction SilentlyContinue | Sort-Object Length -Descending | Select-Object Name, @{n='SizeMB';e={[math]::Round($_.Length/1MB,1)}}, LastWriteTime | Format-Table -AutoSize"
echo ==============================================
pause
exit /b 0


rem ------------------------------------------------------------
:BACKUP
set "DB=%~1"
if exist "%DEST%\%DB%.new.bak" del /q "%DEST%\%DB%.new.bak"
echo       - %DB% ...
sqlcmd -S %SQLSRV% -E -b -Q "IF DB_ID('%DB%') IS NULL PRINT 'DATABASE_NOT_FOUND'; ELSE BACKUP DATABASE [%DB%] TO DISK='%DEST%\%DB%.new.bak' WITH INIT, CHECKSUM, STATS=25"
if errorlevel 1 (
    echo         [X] FAILED - read the error message printed above
    if exist "%DEST%\%DB%.new.bak" del /q "%DEST%\%DB%.new.bak" 2>nul
    goto :eof
)
if not exist "%DEST%\%DB%.new.bak" (
    echo         [SKIP] %DB% : database not installed
    goto :eof
)
if exist "%DEST%\%DB%_prev.bak" del /q "%DEST%\%DB%_prev.bak"
if exist "%DEST%\%DB%.bak" move /y "%DEST%\%DB%.bak" "%DEST%\%DB%_prev.bak" >nul
move /y "%DEST%\%DB%.new.bak" "%DEST%\%DB%.bak" >nul
echo         [OK]
goto :eof

rem ------------------------------------------------------------
:VERIFY
set "DB=%~1"
if not exist "%DEST%\%DB%.bak" goto :eof
sqlcmd -S %SQLSRV% -E -b -Q "RESTORE VERIFYONLY FROM DISK='%DEST%\%DB%.bak' WITH CHECKSUM"
if errorlevel 1 (echo       [X] %DB% : VERIFY FAILED) else (echo       [VERIFIED] %DB%)
goto :eof
