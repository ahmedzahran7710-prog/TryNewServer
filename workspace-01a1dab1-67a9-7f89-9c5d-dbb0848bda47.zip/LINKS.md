# LINKS — كل الروابط والمصادر

> مرجع كامل لكل ما بحثنا فيه، ومن أين جاء السورس والملفات والأدوات.
> **آخر تحديث:** 2026-11-10
>
> **دلالة الحالة:** ✅ استُخدم فعليًا في المشروع · 📖 مرجع/قراءة · ⚠️ تحذير أمني · 🔎 لم يُجرّب بعد

---

## ⚠️ ملاحظة مهمة أولًا — من أين جاءت ملفاتنا؟

**ملفات السيرفر والكلاينت عندك لم تُحمَّل من أي رابط.** جاءت من الحزمة الموجودة على جهازك:

```
C:\RZ\Server\FilesOfficial-Revolution9.1     (السيرفر)
F:\AhmedZahran\rappelz server\Client\...     (الكلاينت)
```

وهي **Revolution Team Epic 9.1** — نفس الإصدار المرفوع في الموضوع الرسمي في الجدول أدناه (§2).
**الشيء الوحيد الذي حمّلناه فعليًا من الإنترنت هو `rzauth` v6.5 (§1).**

---

## 1) سورس سيرفر الدخول (Auth) — ✅ استُخدم

| الرابط | إيه فيه | الحالة |
|---|---|---|
| https://github.com/glandu2/rzu/releases/tag/v6.5 | **`rzu` v6.5** — مجموعة أدوات رابلز: `rzauth` (Auth Emulator) + `rzbenchauth` | ✅ **هذا اللي عندك شغّال** |
| https://github.com/glandu2/rzu | السورس الكامل (C++) — `rzauth/` داخل الشجرة | 📖 |
| https://github.com/glandu2 | باقي مشاريع glandu2: `RZEmulator` · `RappelzCmdLauncher` · `Client-Encryption` | 📖 |
| https://github.com/glandu2/rzauth | مستودع قديم **مؤرشف** — **لا يوجد فيه Releases** (سبب إرباك سابق) | ⚠️ لا تستخدمه |
| https://github.com/glandu2/rzauth/releases | صفحة فارغة — تأكيد أنه لا إصدارات | ⚠️ |
| https://github.com/glandu2/rzbenchauth | بديل Auth بلغة TSQL (مؤرشف) | 📖 |

> **درس مهم:** `glandu2/rzauth` مستودع ميت — الملفات الحقيقية داخل `rzu`. أي شخص يبحث عن rzauth لازم يروح لـ `rzu/tree/master/rzauth`.

---

## 2) ملفات السيرفر 9.1 — ✅ هي أصلًا عندك

| الرابط | إيه فيه | الحالة |
|---|---|---|
| https://www.elitepvpers.com/forum/rappelz-private-server/3653422-release-full-9-1-server-files-revolution-team.html | **[RELEASE] Full 9.1 Server Files — Revolution Team** — نفس ملفاتك بالضبط · الباسورد `Revolution-Team` · ملاحظة عن `RappelzCmdLauncher` و`/use_nprotect:0` | ✅ أصل ملفاتك |
| https://www.elitepvpers.com/forum/rappelz-private-server/4594744-release-rappelz-official-source-code-4.html | **[Release] Rappelz Official Source Code** — سورس رسمي (8.2 sframe متوافق حتى 9.3) · نقاش عن بناء GS من المصدر | 📖 يخص خيار "بناء سيرفر مخصص" |
| https://www.elitepvpers.com/forum/rappelz-private-server/4594715-release-rappelz-official-9-5-2-files-5.html | ملفات **9.5.2** رسمية — لو فكرت في الترقية لاحقًا | 🔎 |
| https://www.elitepvpers.com/forum/rappelz-private-server/4737226-release-rappelz-9-6-server-files.html | ملفات **9.6** — تحذير المشرفين: مبنية على 9.1 معدّل، ومصادر غير موثوقة | ⚠️ |
| https://www.elitepvpers.com/forum/rappelz-private-server/4201955-rappelz-9-1-server-files-help.html | طلب ملفات 9.1 (كل اللينكات القديمة ميتة) — دليل على أن الروابط تموت | 📖 |

---

## 3) الكلاينت

| الرابط | إيه فيه | الحالة |
|---|---|---|
| `F:\AhmedZahran\rappelz server\Client\New folder\` | **كلاينتك الحالي** 9.1 (sframe 5,564,656 بايت · md5 `098bc3fa...`) — جاء مع الحزمة | ✅ هو اللي شغّال |
| https://www.reality-rappelz.us/en/download | "Old Rappelz" — ينزّل **كلاينت 9.1 مُرقّى لـ9.7** | 🔎 لو احتجت كلاينت بديل |
| https://www.rappelztournament.com/downloads/ | كلاينت 9.6+ (Google Drive / MediaFire / MEGA) + شرح مشاكل اللانشر | 📖 |
| https://www.rappelzonlinegame.com/rappelz-private-servers/ | قائمة سيرفرات 2026 — منها **Empire Rappelz** (يدعم العربية) و**Sapphire RZ** (9.1) | 📖 للمقارنة |

> **تحذير:** كلاينت أي سيرفر آخر = **إصدار مختلف** ⇒ لن يتصل بسيرفرك.
> لتوسيع الكلاينت (خريطة/أيتم جديد) تحتاج أدوات تعديل، لا كلاينت جاهز.

---

## 4) الأدوات الجوهرية — ✅ استخدمنا منها اثنتين

| الرابط | إيه فيه | الحالة |
|---|---|---|
| `RappelzCompress.exe` / `RappelzCompress_v2.exe` (داخل حزمة السيرفر) | يحوّل `.opt` → `.eop` و`.lua` → `.ela` — **بدونه السيرفر لا يقرأ أي تعديل** | ✅ مستخدم |
| https://www.elitepvpers.com/forum/rappelz-private-server/1086737-rappelz-server-files-2.html | **شرح Pyrok الأصلي** لصيغة `.eop`/`.ela`: 4 بايت نوع + 2 إصدار + 4 حجم مضغوط + 4 حجم بعد الفك + **zlib**. وفيه `RappelzCompress.rar` | ✅ أساس فهمنا للصيغة |
| https://www.elitepvpers.com/forum/rappelz-private-server/1617502-help-thread-please-post-your-questions-here-89.html | طريقة الاستخدام الصحيحة: عدّل `.opt` → اغلق المحرّر → **اسحب الملف داخل نافذة الأداة** → تخرج `.eop` | ✅ |
| https://www.rappelzonlinegame.com/rappelz-developer-tools/ | **أرشيف 280+ أداة** من ElitePvP (2013–2017): `RappelzCompress v3` **by Pyrok** · `Resource Editor` · `RDB Library` · `nConverter` · `SFrame unpacked` · `GM TOOL V4` · `ItemModder 7.4` · `Item Code Finder` · `MD5 Hasher` · `Command Generator v2` | ✅ المصدر الرئيسي للأدوات |
| http://rappelzdc.weebly.com/tools.html | **Rappelz Download Center** — تحميل مباشر لكل أداة: `Zoidberg GM Tool` · `Admin-Tool v2` · `Item Code Finder` · `Database To RDB` · `Resource Editor Lite` · `Rappelz Compresor` · `MD5 Hasher v2` · `DataBase Manager` | ✅ روابط تحميل مباشرة |

---

## 5) أدوات الجي إم — 🔎 لم تُجرّب بعد

| الرابط | إيه فيه | الحالة |
|---|---|---|
| https://github.com/Xijezu/GM-Tool | **Xijezu GM-Tool V5 — مفتوح المصدر، C#/.NET 4.0، GPL-3.0**. تابات: Character · Items · Pets · Monster · Warp · Buffs · Skills · Database | 🔎 **الأأمن للمراجعة** |
| https://github.com/Xijezu | حساب المطوّر — 8 مستودعات | 📖 |
| https://www.elitepvpers.com/forum/rappelz-private-server/3803062-release-xijezu-s-gm-tool-v5-final.html | موضوع الإصدار + شرح الإمكانيات | 📖 |
| https://www.elitepvpers.com/forum/rappelz-private-server/4278950-release-seizure-yet-another-gm-tool.html | **Seizure GM Tool** — تعديل تجهيز، ألقاب، نقل، **تاب إشعارات (notice)** | 🔎 |
| https://www.elitepvpers.com/forum/rappelz-private-server/2720885-release-source-telnet-gm-tool.html | **InstaGM — Telnet GM Tool بسورس**: Connect → Command → Send | 🔎 **الأقرب لفكرة "لايف"** |
| https://www.elitepvpers.com/forum/rappelz-private-server/2530362-release-royal-gm-tool-v1.html | Royal GM-Tool v1 | 📖 |
| https://www.elitepvpers.com/forum/rappelz-private-server/4882206-rappelz-gm-tool.html | طلب أداة لـ9.7 ⇒ الأدوات دائمًا متأخرة عن الإصدارات | 📖 |
| https://kandi.openweaver.com/csharp/Xijezu/GM-Tool | تحليل كود Xijezu + تحميل `Rel.GM-Tool V5.zip` | 📖 |

---

## 6) باسورد الكونسول — العائق المركزي ⚠️

| الرابط | إيه فيه | الحالة |
|---|---|---|
| https://www.elitepvpers.com/forum/rappelz-private-server/3658755-how-setup-9-1-a.html | دليل إعداد 9.1 — وفيه `console._password` مكتوب كـ **`REPLACE.ME.WITH.PYROK.TOOL.GENERATED.PASSWORD`** ⇒ الباسورد **يُولَّد بأداة Pyrok**، وليس نصًا معروفًا | ✅ الدليل القاطع |
| https://www.rappelzonlinegame.com/rappelz-developer-tools/ | يذكر **`RappelzCompress v3 by Pyrok`** و**`Command Generator v2`** ⇒ أول مكان تبحث فيه عن مولّد الباسورد | 🔎 **الخطوة القادمة** |
| http://rappelzdc.weebly.com/tools.html | **`Command Generator v2`** و**`Hamachi Password Generator`** — أسماء مرشّحة | 🔎 |

> **الخلاصة:** كل أداة "لايف" تحتاج هذا الباسورد. لو حصلنا على مولّده ⇒ اشتغلت أدوات المجتمع والكونسول معًا. لو لا ⇒ **Lua** يكفي ولا يحتاجه أصلًا.

---

## 7) أدلة الإعداد والمفاهيم

| الرابط | إيه فيه | الحالة |
|---|---|---|
| https://www.elitepvpers.com/forum/rappelz-private-server/3658755-how-setup-9-1-a.html | إعداد 9.1 كامل: `.opt` الثلاثة · DES hash لباسورد DB · الترتيب | 📖 |
| https://www.rappelzonlinegame.com/rappelz-developer-tools/ | "How to Create a Rappelz P-Server" · "Setup newest release + ports + guild icon" | 📖 (منفذ 5000 = أيقونات النقابات، أُكِّد منه) |
| https://www.elitepvpers.com/forum/rappelz-private-server-2/ | قسم رابلز كامل في ElitePvP | 📖 |
| https://www.elitepvpers.com/forum/rappelz-private-server/1617502-help-thread-please-post-your-questions-here-89.html | موضوع المساعدة العام — كنز أسئلة/أخطاء جاهزة | 📖 |

---

## 8) قواعد بيانات مرجعية (أكواد أيتمات/وحوش/خرائط)

| الرابط | إيه فيه | الحالة |
|---|---|---|
| https://www.rappelzonlinegame.com/rappelz-game-information-hub/ | **مركز قواعد البيانات**: Item · Monster · Boss · NPC · Quest · Dungeon · Loot · **Interactive Atlas** | 📖 مفيد جدًا لتعديل السيرفر |
| https://www.rappelzonlinegame.com/rappelz-monster-database/3d-monsters/ | وحوش بـ3D ومعاينة + IDs (مثل تامابل 651، 789) | 📖 |
| http://rappelzdc.weebly.com/tools.html | **`Item Code Finder`** و`Database To RDB` — للبحث عن أكواد الأيتمات | 🔎 |
| داخل حزمة السيرفر | `db_item` / `Resource/` — **المصدر الحقيقي المؤكد** لأكوادك | ✅ المرجع الأول |

> ⚠️ **قاعدة:** أي كود أيتم تأخذه من موقع خارجي **لازم تتأكد منه في قاعدة سيرفرك** — المواقع تعرض إصدارات أحدث.

---

## 9) مجتمعات ومصادر عامة

| الرابط | إيه فيه |
|---|---|
| https://www.elitepvpers.com/forum/rappelz-private-server/ | أكبر قسم رابلز — إصدارات، أدوات، مساعدة |
| https://www.rappelzonlinegame.com/ | فهارس: سيرفرات، أدوات، أدلة، قواعد بيانات |
| https://nostalgic.gg/en/rappelz/play-rappelz | إحصاءات وسيرفرات 9.1 (للمقارنة) |
| https://github.com/NGemity/RZEmulator | إيميوليتور رابلز بديل (C++) — بديل جذري لملفات Revolution |

---

## 10) ⚠️ تحذيرات ثابتة

1. **كل أدوات المنتديات مغلقة المصدر** = احتمال باب خلفي. استخدم **مفتوح المصدر** فقط أو افحص أولًا.
2. **لا تشغّل أداة على جهاز السيرفر بحساب `sa`** — أنشئ `rz_app` بصلاحيات محدودة.
3. **لا تفتح `console` (65528) على الإنترنت** — محلي فقط.
4. ملفات 9.6 المرفوعة من حسابات جديدة = **مصادر غير موثوقة** (تحذير مشرفي ElitePvP نفسهم).
5. الروابط القديمة **تموت بسرعة** — احفظ أي أداة تحتاجها محليًا فورًا.

---

## ✅ خلاصة: ما استُخدم فعلًا من كل هذه الروابط

| # | المصدر | ماذا أعطانا |
|---|---|---|
| 1 | `github.com/glandu2/rzu` releases v6.5 | **`rzauth` — اللعبة تعمل بسببه** |
| 2 | حزمة Revolution 9.1 (محلية) | السيرفر + الكلاينت + `RappelzCompress_v2` |
| 3 | شرح Pyrok لصيغة `.eop` | فهمنا ليه لازم إعادة الضغط |
| 4 | `rappelzonlinegame.com/rappelz-developer-tools` | أرشيف الأدوات + الدليل على Pyrok ومولّد الباسورد |
| 5 | `rappelzdc.weebly.com/tools.html` | روابط تحميل مباشرة للأدوات |
| 6 | موضوع الإعداد 9.1 (elitepvpers 3658755) | تأكيد طبيعة `console._password` |

**كل الباقي = قراءة ومراجع لم تُنفَّذ بعد.**
