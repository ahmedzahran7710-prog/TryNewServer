--[[ ============================================================
     gm_probe.lua  --  GM capability probe (READ ONLY, prints only)
     Purpose: report which Lua functions exist on THIS server build.
     It never gives gold/items/states and never changes anything.

     HOW TO USE
     1) Open  Game_bin\Resource\Script\NPC_Buff.lua  (Notepad++)
     2) Paste everything below this header at the END of the file.
     3) Inside function NPC_Secroute_mage_init()  add ONE line:
              gm_probe_run()
     4) Recompress:  RappelzCompress_v2.exe NPC_Buff.lua
     5) Restart the game server and read the console output.
     ============================================================ ]]

local function P(name, fn)
    if fn == nil then
        cprint("[PROBE] " .. name .. " = MISSING")
    else
        cprint("[PROBE] " .. name .. " = OK (" .. type(fn) .. ")")
    end
end

function gm_probe_run()

    cprint("======== GM PROBE START ========")

    -- 1) inventory / item
    P("has_item",            has_item)
    P("find_item",           find_item)
    P("get_item_handle",     get_item_handle)
    P("get_item_handle_list",get_item_handle_list)
    P("get_item_code",       get_item_code)
    P("get_wear_item_handle",get_wear_item_handle)
    P("insert_item",         insert_item)
    P("drop_item",           drop_item)
    P("delete_item",         delete_item)
    P("change_item_code",    change_item_code)

    -- 2) player values / progression
    P("set_value",           set_value)
    P("get_value",           get_value)
    P("insert_gold",         insert_gold)
    P("add_exp_jp",          add_exp_jp)
    P("add_state",           add_state)
    P("get_state_level",     get_state_level)

    -- 3) broadcast / notice / announce
    P("announce",            announce)
    P("BroadcastNotice",     BroadcastNotice)
    P("SCRIPT_BroadcastNotice", SCRIPT_BroadcastNotice)
    P("add_notice",          add_notice)
    P("notice",              notice)
    P("broadcast",           broadcast)

    -- 4) world / all players
    P("cast_world_state",    cast_world_state)
    P("add_event_state",     add_event_state)
    P("do_each_player_in_instance_dungeon", do_each_player_in_instance_dungeon)
    P("do_each_player_in_battle_arena_team", do_each_player_in_battle_arena_team)

    -- 5) dungeon / zone entry
    P("enter_instance_dungeon",      enter_instance_dungeon)
    P("enter_other_instance_dungeon",enter_other_instance_dungeon)
    P("enter_secret_dungeon",        enter_secret_dungeon)
    P("get_instance_dungeon_id",     get_instance_dungeon_id)

    -- 6) identity / gate
    P("get_account_flag",    get_account_flag)
    P("get_flag",            get_flag)
    P("get_own_guild_name",  get_own_guild_name)
    P("get_player_name",     get_player_name)
    P("get_avatar_name",     get_avatar_name)
    P("get_pc_name",         get_pc_name)
    P("get_target_value",    get_target_value)

    -- 7) teleport helpers
    P("teleport",            teleport)
    P("move_to",             move_to)
    P("set_position",        set_position)

    -- 8) dialog widgets
    P("dlg_title",           dlg_title)
    P("dlg_text",            dlg_text)
    P("dlg_menu",            dlg_menu)
    P("dlg_show",            dlg_show)
    P("dlg_input",           dlg_input)

    cprint("======== GM PROBE END ========")
end
