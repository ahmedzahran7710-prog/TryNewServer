/* ============================================================
   إنشاء حساب لصاحبك على السيرفر
   شغّله في SSMS → New Query على قاعدة Auth
   عدّل السطرين: login_name  و  الباسورد
   ============================================================ */

USE Auth;
GO

-- استبدل  friend1  باسم الدخول، و  Friend@2026  بالباسورد
-- ملاحظة: auth.clients.restrictchars:true  ⇒ مافيش رموز غريبة في الاسم
-- الباسورد: أي حاجة، لكن الحروف والأرقام أضمن

DECLARE @login    NVARCHAR(32) = N'friend1';
DECLARE @password NVARCHAR(32) = N'Friend2026';
DECLARE @salt     NVARCHAR(64) = N'A4&8zx209z&8zx267Ope';   -- لازم يطابق auth.db.salt

INSERT INTO dbo.Accounts
  (login_name, password, block, withdraw_remain_time, age, auth_ok, pcbang, last_login_server_idx, event_code)
VALUES
  (@login,
   LOWER(CONVERT(VARCHAR(32), HashBytes('MD5', @salt + @password), 2)),
   0, 0, 18, 1, 1, 0, 0);
GO

-- تحقق: لازم يظهر الحساب مرة واحدة
SELECT account_id, login_name, password, block, auth_ok, age
FROM dbo.Accounts
WHERE login_name IN (N'friend1', N'test2');
GO
