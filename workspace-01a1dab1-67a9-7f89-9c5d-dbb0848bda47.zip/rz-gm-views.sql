/* =============================================================
   لوحة تحكم جي إم داخل SSMS (Views قابلة للتعديل اليدوي)
   -------------------------------------------------------------
   الفكرة: جدول Character فيه أكثر من 100 عمود — التعديل اليدوي فيه
   متعب وخطير. الـ View دي بتعرض 9 أعمدة بس، وتقدر تعدّلها بالماوس
   من غير أي SQL.

   شغّل الملف مرة واحدة فقط.
   ============================================================= */

------------------------------------------------------------------
-- 1) لوحة تعديل الشخصيات
------------------------------------------------------------------
IF OBJECT_ID('Telecaster1.dbo.v_GM_Characters') IS NOT NULL
    DROP VIEW Telecaster1.dbo.v_GM_Characters;
GO

CREATE VIEW Telecaster1.dbo.v_GM_Characters AS
SELECT
    sid,
    name,
    account_id,
    lv,
    exp,
    jp,
    total_jp,
    talent_point,
    gold,
    permission,
    layer,
    x,
    y,
    z
FROM Telecaster1.dbo.Character
WHERE name NOT LIKE '@%';
GO

------------------------------------------------------------------
-- 2) لوحة تعديل الحسابات
------------------------------------------------------------------
IF OBJECT_ID('Auth.dbo.v_GM_Accounts') IS NOT NULL
    DROP VIEW Auth.dbo.v_GM_Accounts;
GO

CREATE VIEW Auth.dbo.v_GM_Accounts AS
SELECT
    account_id,
    login_name,
    password,
    block,
    auth_ok,
    age
FROM Auth.dbo.Accounts;
GO

------------------------------------------------------------------
-- 3) لوحة قراءة الأيتمات (قراءة فقط — لا تعدّل من هنا)
------------------------------------------------------------------
IF OBJECT_ID('Telecaster1.dbo.v_GM_Items') IS NOT NULL
    DROP VIEW Telecaster1.dbo.v_GM_Items;
GO

CREATE VIEW Telecaster1.dbo.v_GM_Items AS
SELECT
    c.name  AS character_name,
    i.owner_id,
    i.idx,
    i.code,
    i.cnt,
    i.level,
    i.enhance,
    i.flag
FROM Telecaster1.dbo.Item i
INNER JOIN Telecaster1.dbo.Character c ON c.sid = i.owner_id
WHERE c.name NOT LIKE '@%';
GO

------------------------------------------------------------------
-- 4) تأكيد
------------------------------------------------------------------
SELECT * FROM Telecaster1.dbo.v_GM_Characters ORDER BY sid;
SELECT * FROM Auth.dbo.v_GM_Accounts ORDER BY account_id;
GO
