# RAPPELZ 9.1 — ملف الذاكرة النهائي (Final Memory / Handover)

> **الإصدار:** v3 · **آخر تحديث:** 2026-11-10
> **الغرض من الملف:** تسليم كامل لأي وكيل/شخص يكمل العمل. كل ما تم إصلاحه، كل ما تم التحقق منه، كل ما لم يُحلّ بعد — بالحرف وبدون افتراضات.
> **الترتيب المقترح للقراءة:** §0 (TL;DR) → §1 (الحالة) → §3 (ترتيب التشغيل) → §19 (الحالة والمتبقي) → بقية الأقسام حسب الحاجة.
> **أقسام جديدة في هذا الإصدار:** §14 هاماتشي · §15 الجي إم · §16 الاختصارات · §17 الأمان · §18 جرد الملفات · §19 الحالة والمتبقي · §20 TL;DR إنجليزي محدّث.

> آخر تحديث: 2026-11-13 · الحالة: **السيرفر شغّال واللعبة دخلت** (حساب `test2`، شخصية `Zahran`، لفل 1، في المدينة).
> هذا الملف مكتوب لوكيل/مهندس آخر يكمّل من غير ما يعيد اكتشاف أي حاجة. كل مسار وكل أمر هنا **مُجرَّب فعليًا**.

---

## 0) English TL;DR (for any agent)

Rappelz Epic 9.1 private server (Revolution Team leak pack) on **Windows 10 20H2, single PC, localhost only**.

* **The official auth `PrincessAuroraServer.exe` (2014, md5 `2dae2b0bb70c2a0d619beb3d4debda50`) is BROKEN on this machine.** It accepts TCP connections on port 1996 but **never parses the client's bytes** — it prints `!!!!! Invalid Message from 127.0.0.1[ID: …, Size: …]` for **any** input, including a hand-built, perfectly valid packet. Proof is in §7.9. Do not go back to it.
* **Replacement that works: `rzauth` v6.5** (glandu2 Auth Emulator, Windows x64) — folder `C:\RZ\rzauth\`, listens on **1996** (clients) and **4502** (game server), uses the same SQL database `Auth` and table `dbo.Accounts`. Login finally succeeded with it.
* **DB login that works:** `rappelz` with an **empty password** (sysadmin). **`sa` / `Ahmed@7710` does NOT work** (`ODBC 18456 Login failed for user 'sa'`).
* **Working account:** `test2` / `test123` — hash = `md5("A4&8zx209z&8zx267Ope" + "test123")` = `48dd83fce81f40dbbb580b4834435323`.
* **Client:** `F:\AhmedZahran\rappelz server\Client\New folder\`, `sframe.exe` must be the pack's SFrame (`md5 098bc3fa558481241772eb3d4b221b8f`, 5,564,656 B, 2015-03-15), launcher line must contain **both** `/auth_ip:127.0.0.1` **and** `/auth_port:1996`.
* Run order: SQL Server → `LogServer.exe` → `rzauth.exe` → `CaptainHerlockServer.exe` → client. **Never** start `PrincessAuroraServer.exe` or `UploadServer.exe` any more (rzauth replaces both and they fight for the same ports).
* Remaining console errors are cosmetic only (§8): Lua `mob(...)` syntax spam, missing `BILLING` linked server (cash shop), missing `server_idx_offset` column, and one default SQL query pointing at a non-existent table `account` (fix included).

---

## 1) الحالة النهائية (ما الذي يعمل الآن)

| المكوّن | البرنامج | المكان | الحالة |
|---|---|---|---|
| SQL Server | خدمة SQL Server | 127.0.0.1:1433 | شغال |
| Log Server | `LogServer.exe` | `...\GameEngine\Log_bin\` | شغال (اختياري لكن مستخدم) |
| **Auth (سيرفر الدخول)** | **`rzauth.exe` (v6.5)** | **`C:\RZ\rzauth\`** | **شغال — هو الأساس** |
| Game Server | `CaptainHerlockServer.exe` | `...\GameEngine\Game_bin\` | شغال، متصل بالـ Auth والأبلود |
| Client | `sframe.exe` + `Revolution Launcher.bat` | `F:\AhmedZahran\rappelz server\Client\New folder\` | شغال، دخل اللعبة |
| ~~Auth الرسمي~~ | ~~`PrincessAuroraServer.exe`~~ | `...\GameEngine\Auth_bin\` | **معطّل — لا تشغّله** |
| ~~Upload Server~~ | ~~`UploadServer.exe`~~ | `...\GameEngine\Auth_bin\` | **معطّل — rzauth فيه أبلود مدمج** |

---

## 2) خريطة المسارات (كما هي على الجهاز فعليًا)

### جهاز السيرفر
```
C:\RZ\Server\FilesOfficial-Revolution9.1\
├─ GameEngine\
│  ├─ Auth_bin\
│  │  ├─ PrincessAuroraServer.exe     (2,427,976 B · 2014-09-25 · md5 2dae2b0bb70c2a0d619beb3d4debda50)  ← معطّل
│  │  ├─ UploadServer.exe              ← معطّل
│  │  ├─ authserver.opt / AuthServer.eop
│  │  └─ RappelzCompress_v2.exe        (أداة ضغط الإعدادات)
│  ├─ Game_bin\
│  │  ├─ CaptainHerlockServer.exe
│  │  ├─ GameServer.opt  →  GameServer.eop   (لازم الضغط)
│  │  └─ RappelzCompress.exe
│  └─ Log_bin\
│     └─ LogServer.exe
├─ Launcher\
│  ├─ RappelzCmdLauncher.exe
│  └─ Revolution Launcher.bat
└─ SFrame\
   └─ SFrame.exe  (5,564,656 B · 2015-03-15 · md5 098bc3fa558481241772eb3d4b221b8f)
```

### سيرفر الدخول البديل (شغّال)
```
C:\RZ\rzauth\
├─ rzauth.exe                 (v6.5 · Windows AMD64)
├─ rzu.dll
├─ libcrypto-1_1-x64.dll
├─ libssl-1_1-x64.dll
├─ auth.opt                   ← الإعدادات النهائية (النص الكامل في §10)
├─ traffic_log\               (بيتولّد تلقائيًا لو trafficdump.enable:true)
└─ upload\                    (أيقونات النقابات)
```

### جهاز العميل (نفس الجهاز)
```
F:\AhmedZahran\rappelz server\Client\New folder\
├─ sframe.exe        ← نسخة الحزمة (2015-03-15 · 5,564,656 B · md5 098bc3fa558481241772eb3d4b221b8f)
├─ sframe_old.exe    ← نسخة العميل العربية الأصلية (2014-09-16) — احتياطي، لا تُحذف
├─ RappelzCmdLauncher.exe
├─ Revolution Launcher.bat
└─ rappelz_v1.opt    ← إعدادات جرافيك/صوت فقط، لا تحتوي أي IP أو بورت
```

---

## 3) ترتيب التشغيل الصحيح (بالترتيب، كل مرة)

1. **SQL Server** (الخدمة — لازم تكون شغالة قبل أي حاجة).
2. `C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Log_bin\LogServer.exe`
3. `C:\RZ\rzauth\rzauth.exe`
4. `C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin\CaptainHerlockServer.exe`
5. العميل من `Revolution Launcher.bat`.

**لا تشغّل** `PrincessAuroraServer.exe` ولا `UploadServer.exe` (سيتخانقوا مع rzauth على 1996 / 4502 / 4616 / 4617).

### علامات النجاح اللي لازم تشوفها

**rzauth:**
```
DBConnectionPool0: Checking connection to database
DBConnectionPool0: Connection ok
...Starting server auth.clients on 0.0.0.0:1996
...Starting server auth.gameserver on 0.0.0.0:4502
...Starting server upload.clients on 0.0.0.0:4617
...Starting server upload.iconserver on 0.0.0.0:5000
...Starting server upload.gameserver on 127.0.0.1:4616
SocketSession0: Connected to Log server 127.0.0.1:4516
AuthServer::GameServerSession0: Server Login: Revolution Official[1] at 127.0.0.1:4514
UploadServer::GameServerSession0: Server Login: Game001 from 127.0.0.1:xxxxx
```

**Game001:**
```
Connect To Auth... ok
Adding auth connection to IOCP... ok
Connect To Upload... ok
Adding upload connection to IOCP... ok
Acceptor initialize... ok(IP: 0.0.0.0, Port: 4514)
```

> **ملاحظة استكشاف أخطاء سريعة:** كل خطوة بتعتمد على اللي قبلها.
> * `Connect To Auth... failed` → rzauth مقفول أو البورت 4502 مش سامع.
> * `Connect To Upload... failed` → استخدمت `UploadServer.exe` الرسمي بدل rzauth، أو rzauth مش شغال.
> * `Login failed for user 'sa'` في rzauth → استخدم `rappelz` بباسورد فاضي (§5).

---

## 4) البورتات (الخريطة الكاملة)

| البورت | الاستخدام | مين بيسمع |
|---|---|---|
| 1433 | SQL Server | خدمة SQL |
| **1996** | **العميل → سيرفر الدخول** (`/auth_port:1996`) | rzauth |
| 4501 | كونسول الإدارة في rzauth (telnet) | rzauth |
| 4502 | سيرفر اللعبة → سيرفر الدخول | rzauth |
| 4503 | Billing (فاضي/مش مستخدم فعليًا) | rzauth |
| 4514 | سيرفر اللعبة ← العملاء | CaptainHerlockServer |
| 4516 | Log Server | LogServer.exe |
| 4616 | سيرفر اللعبة → الأبلود | rzauth |
| 4617 | العميل → الأبلود (أيقونات النقابات) | rzauth |
| 5000 | ويب سيرفر صغير لأيقونات النقابات | rzauth |
| 1995 | (قديم) كونسول Auth الرسمي | غير مستخدم |
| 65528 | كونسول سيرفر اللعبة | CaptainHerlockServer |

---

## 5) قاعدة البيانات والحسابات

* **Instance:** `127.0.0.1,1433`
* **قواعد موجودة و ONLINE:** `Auth` · `Arcadia` · `Telecaster1` · `BILLING`
* **طريقة الدخول من SSMS:** **Windows Authentication** (ممنوع تحاول الدخول باسم `rappelz`).
* **حسابات SQL:**
  * `rappelz` — **باسورد فاضي** — sysadmin — **هو اللي بيستخدمه rzauth** ✅
  * `sa` — الباسورد **غير معروف** (`Ahmed@7710` فشل: `ODBC 18456 Login failed for user 'sa'`). لا تعتمد عليه.
* **جدول الحسابات:** `Auth.dbo.Accounts` — **مش** `tuser` و**مش** `Account`.
  الأعمدة: `account_id int IDENTITY` · `login_name nvarchar(31)` · `password nvarchar(32)` · `block` · `withdraw_remain_time` · `age` · `auth_ok` · `pcbang` · `last_login_server_idx` · `event_code` · `server_list_mask` · `result` · `ip` · `game_code` · `gamecode`

### الحسابات الموجودة
| login | password field | الباسورد بالعربي | ملاحظة |
|---|---|---|---|
| `admin` | `613b5247e3398350918cb622a3ec19e9` | مجهول | مش قابل للكسر — متضيّعش وقت |
| `test1` | `cc03e747a6afbbcbf8be7668acfebee5` | `test123` (md5 عادي) | مش هيشتغل مع rzauth بإعداد المفتاح الحالي |
| **`test2`** | `48dd83fce81f40dbbb580b4834435323` | **`test123`** | ✅ **هذا اللي بيدخل اللعبة** |

### معادلة الباسورد (مهمة جدًا)
`rzauth` بيقارن: `md5( auth.db.salt + password )` — والـ salt الحالي هو مفتاح الحزمة:
```
A4&8zx209z&8zx267Ope
```
### إنشاء حساب جديد (SQL — يعمل مع الإعداد الحالي)
```sql
USE [Auth];
INSERT INTO dbo.Accounts
  (login_name, password, block, withdraw_remain_time, age, auth_ok, pcbang, last_login_server_idx, event_code)
VALUES
  (N'myacc',
   LOWER(CONVERT(VARCHAR(32), HashBytes('MD5','A4&8zx209z&8zx267Ope' + 'mypassword'), 2)),
   0, 0, 18, 1, 1, 0, 0);
```
> كل الأعمدة NOT NULL ما عدا `account_id` (IDENTITY).

**أمثلة جاهزة:**
* لو عايز باسورد بدون مفتاح: `LOWER(CONVERT(VARCHAR(32), HashBytes('MD5','mypassword'), 2))` وساعتها لازم تفضّي `auth.db.salt` في `auth.opt`.
* حساب `test1` اتعمل بالطريقة دي بالظبط، فمش بيشتغل مع الـ salt الحالي.

---

## 6) العميل (Client)

* الفولدر: `F:\AhmedZahran\rappelz server\Client\New folder\`
* **`sframe.exe` لازم يكون** نسخة الحزمة: `5,564,656 بايت` · `2015-03-15 2:49 PM` · `md5 098bc3fa558481241772eb3d4b221b8f`.
  النسخة العربية الأصلية (`2014-09-16`) محفوظة باسم `sframe_old.exe` — لا تُحذف (احتياطي).
* **سطر التشغيل النهائي** (`Revolution Launcher.bat` — لازم يكون **سطر واحد** بدون أي Enter جوّاه):
```
RappelzCmdLauncher.exe sframe.exe /auth_ip:127.0.0.1 /auth_port:1996 /use_nprotect:0 /help_url_w:611 /help_url_h:625 /locale:Windows-1256 /country:ME /cash /commercial_shop /layout_dir:6 /layout_auto:0 /cash_url_w:800 /cash_url_h:631
```
* `/use_nprotect:0` = إيقاف GameGuard.
* `/auth_port:1996` **إجباري** — من غيره العميل بيروح لبورت افتراضي غلط ويطلع خطأ **10061**.
* ملف `rappelz_v1.opt` في الكلينت = إعدادات جرافيك/صوت فقط، **لا يحتوي أي IP أو بورت** — لا تضيّع وقت في البحث فيه.
* `rappelz.log` مالهوش أي فايدة في مشاكل الاتصال (بيكتب فيه اللعبة `Locale File` ثم `Game Main-loop Finished` وخلاص).

---

## 7) كل مشكلة واجهتنا وحلّها (سجل كامل — لا تعِد اكتشافها)

### 7.1 سيرفر اللعبة كان بيفشل في التشغيل / الإعدادات مش مقروءة
* **العَرَض:** تعدّل `GameServer.opt` وما فيش أي تأثير.
* **السبب:** السيرفر بيقرا **`GameServer.eop`** (نسخة مضغوطة) مش `.opt` مباشرة.
* **الحل:** اسحب `GameServer.opt` وارميه على `Game_bin\RappelzCompress.exe` → يتولّد `GameServer.eop` → إعادة تشغيل.
* **نفس القاعدة تنطبق على** `authserver.opt` → `AuthServer.eop` بـ `Auth_bin\RappelzCompress_v2.exe`.

### 7.2 جدول `tuser` مش موجود
* **العَرَض:** `Invalid object name 'dbo.tuser'`.
* **الحل:** الجدول الصح اسمه **`Auth.dbo.Accounts`** (الأعمدة في §5). لا يوجد جدول حسابات في `Telecaster1` (فيه `Character` فقط).

### 7.3 باسورد `admin` مش قابل للكسر
* جرّبنا قوايم كلمات + المفتاح (prefix/suffix/colon) → **فشل**. توقّف عن المحاولة، استخدم `test2`.

### 7.4 `Revolution Launcher.bat` بيقفل فورًا
* **السبب:** `RappelzCmdLauncher.exe` مش موجود في فولدر الكلينت.
* **الحل:** انسخه من `...\Launcher\RappelzCmdLauncher.exe`.

### 7.5 خطأ **10061** عند تسجيل الدخول
* **العَرَض:** `Rappelz Error (10061)` والسيرفر شغال وسامع على 1996 (تم إثباته بـ `netstat -ano | findstr :1996`).
* **السبب الحقيقي:** سطر التشغيل **ناقصه `/auth_port:1996`** → العميل بيروح لبورت تاني.
* **الحل:** إضافة `/auth_port:1996` بعد `/auth_ip` مباشرة. **اختفت 10061 نهائيًا.**

### 7.6 بعد كده ظهرت `!!!!! Invalid Message from 127.0.0.1[ID: 1957, Size: -1640872455]`
هنا بدأت أطول مرحلة. كل اللي جرّبناه **وفشل** (مكتوب هنا عشان محدش يعيده):

| المحاولة | النتيجة |
|---|---|
| `/notenc:1` في سطر التشغيل | نفس الرسالة |
| `N:game.ignore_client_binary:1` | لا تأثير على رسالة الـ Auth |
| استبدال `sframe.exe` بنسخة الحزمة | نفس الرسالة (البصمة تأكدت إن الملف الشغّال هو نسخة الحزمة فعلًا) |
| تغيير `country:ME` / تجارب اللغة | لا تأثير |
| التأكد من GameGuard (`tasklist` بحثًا عن gamemon/npgg/nprotect) | **مفيش أي عملية حماية شغالة** — القوس ده مقفول |
| توليد `AuthServer.eop` | الإعدادات اتقرأت فعلًا (اختفى تكرار الـ acceptors) لكن **الرسالة نفسها** |
| فحص `auth.version` / `db.auth.*` | لا تأثير |

### 7.7 تحليل الكود (اكتشاف مهم)
فكّكنا `PrincessAuroraServer.exe` بـ capstone وpefile، ولقينا الدالة اللي بتطبع الرسالة (`Aurora\GameClientNetwork.cpp : GameClientConnectionManager::onProcess`) وشكل الباكيت المتوقع:

```
[ size : 4 بايت LE ] [ id : 2 بايت LE ] [ checksum : بايت واحد ]
checksum = مجموع أول 6 بايتات (mod 256)
size يشمل الهيدر (7 بايت) — و size-7 لازم يكون ≤ 0x7FF9 وإلا تطلع Message Too Big
```

### 7.8 ماذا يرسل العميل فعلًا؟
سمّعنا على 1996 بـ PowerShell (listener) والعميل مقفول/مفتوح:
* العميل **بيتصل ويسكت** لحد ما تدوس "تسجيل دخول".
* عند الدخول بيبعت **46 بايت مشفّرة/عالية العشوائية**: `55 0C 41 01 24 02 32 F8 B0 96 …`
* فحصناها: ليست zlib، وليست XOR بسيط، والـ checksum مش مطابق لأي إزاحة → طبقة تشفير حقيقية.

### 7.9 الإثبات القاطع إن المشكلة في الـ Auth الرسمي (وليس في العميل)
أرسلنا للـ Auth باكيت **صنعناه بإيدينا** بصيغة صحيحة تمامًا (size=7، id=10001، checksum=0x3F)، والعميل **مقفول**:
```
!!!!! Invalid Message from 127.0.0.1[ID: 570, Size: 21040218]   ← الرقم مش بتاعنا
!!!!! Invalid Message from 127.0.0.1[ID: 570, Size: 21040218]   ← ونفس الأرقام بالحرف للحالتين
```
* الأرقام اللي طبعها **مش موجودة في الباكيت بتاعنا**، واتكررت بنفس القيمة بعد إعادة تشغيل الجهاز وبعد توليد `AuthServer.eop`.
* **الخلاصة:** `PrincessAuroraServer.exe` (نسخة 2014) على Windows 10/11 **لا يقرأ بايتات العميل إطلاقًا** — فهو لا يصلح، وأي عميل في الدنيا كان هيفشل معه.
* **القرار:** استبداله. (نظريات سابقة مثل "بلوتوث" التشفير/إصدار العميل/الـ country/الحماية كلها اتقفلت بالأدلة.)

### 7.10 الحل النهائي: rzauth v6.5
* المصدر: مشروع `glandu2/rzu` (GitHub Releases v6.5 · Windows AMD64 · `rzemu-v6.5-Windows-AMD64-rzauth.zip`).
* الملفات المطلوبة جنبه: `rzu.dll` · `libcrypto-1_1-x64.dll` · `libssl-1_1-x64.dll`.
* إعداداته: `auth.clients.port:1996` (للعميل) و`auth.gameserver.port:4502` (لسيرفر اللعبة) — نفس أرقام الحزمة.
* **بيانات الدخول للقاعدة:** `rappelz` / باسورد فاضي (فشل `sa`).
* **بعد تشغيله:** أعد تشغيل `CaptainHerlockServer.exe` → `Connect To Auth... ok` + `Connect To Upload... ok` → من الكلينت `test2/test123` → **دخلت اللعبة**.

---

### 7.11 سكربت النسخ الاحتياطي كان بيفشل — خطأ في اقتباس الـ batch

**العَرَض:** كل القواعد رجعت `[X] FAILED - see message above` مع أسماء غريبة (`Msg…`, `Incorrect…`) بدل أسماء القواعد.

**السبب (خطأ مني وليس من جهازك):** كنت بستخدم `for /f` مع استعلام SQL جواه اقتباسات مفردة مكرّرة (`''Auth''`). الـ batch مرّرها حرفيًا لـ sqlcmd ⇒ `IN (''Auth'',...)` ⇒ خطأ صياغة، وسطور رسالة الخطأ نفسها اتحوّلت لـ "أسماء قواعد". كمان كنت بستخدم `>nul` فخبّيت رسالة الخطأ الحقيقية.

**الحل (v2 من `backup-rz.cmd`):** إلغاء `for /f` نهائيًا، واستخدام 4 أوامر `BACKUP` صريحة عبر labels (`call :BACKUP Auth` …)، مع `IF DB_ID('X') IS NULL` لتخطي القاعدة غير المثبّتة، وعدم كتم أي رسالة خطأ، وكتابة آمنة (`*.new.bak` ثم نقل فوق القديم مع احتياطي `*_prev.bak`).

**تحقق النجاح:** `[OK]` قدام كل قاعدة + `[VERIFIED]` في مرحلة `RESTORE VERIFYONLY` + جدول الأحجام في النهاية.
**إضافة v3 (بعد تشغيله على الجهاز):**
- **SQL Server = Express Edition** ⇒ `BACKUP ... WITH COMPRESSION` **غير مدعوم** (`Msg 1844`). النسخ تعمل **بدون** `COMPRESSION`، و`CHECKSUM` مدعوم. الحل: النسخ غير مضغوط على F: (مساحة كافية: 57 GB فاضي).
- **قاعدة `ArcadiaInfo` غير مثبّتة** على هذا الـ instance. **مؤكد الآن:** القواعد الموجودة هي `Auth` · **`Arcadia`** · `Telecaster1` · `Billing` — أي أن قاعدة الباك اسمها **`Arcadia`** لا `ArcadiaInfo`، و`ArcadiaInfo` (المطلوبة كـ Linked Server لنظام الصلاحية) **غير موجودة إطلاقًا**.
- ملاحظة مهمة للجي إم: procs الصلاحية بتقرأ `ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo` (Linked Server) — وطالما لا القاعدة ولا الـ linked server موجودين، نظام الصلاحية الرسمي **غير فعّال أصلًا**. تأكيد إضافي لصحة المسار البديل (`gm.ps1`).

**مؤكد من الشاشة:** إنشاء المجلد ✅ ومنح الصلاحية لـ `NT SERVICE\MSSQLSERVER` ✅ — الاتنين شغالين.

**نتيجة التشغيل النهائية (v3 — ناجحة 100%):**
```
[OK] Auth · [OK] Telecaster1 · [OK] Arcadia · [SKIP] ArcadiaInfo (غير مثبتة) · [OK] Billing
[VERIFIED] Auth · [VERIFIED] Telecaster1 · [VERIFIED] Arcadia · [VERIFIED] Billing
Telecaster1.bak 207.7 MB · Telecaster1_prev.bak 207.7 MB
Arcadia.bak     169.8 MB · Arcadia_prev.bak     169.8 MB
Billing.bak      13.3 MB · Billing_prev.bak      13.3 MB
Auth.bak          3.3 MB · Auth_prev.bak          3.4 MB
```
المسار النهائي: `F:\AhmedZahran\rz-backup` · الإجمالي ≈ 790 MB (نسخة + احتياطي) · F فيه 57 GB فاضي ⇒ لا مشكلة مساحة.

---

## 8) الأخطاء اللي لسه بتظهر — وكلها **ليست أعطال**

### 8.1 سطور Lua (نافذة Game001)
```
Lua run string failed. mob( 1002 167538,53382,169050,54432):1: ')' expected near '167538'
Lua run string failed. mob( 1002 169050,53928,169344,54642) …
```
* **السبب:** سكربتات `mob(...)` في `Resource/Script/*.lua` فيها صياغة قديمة/ناقصة فاصلة بين الأرقام.
* **التأثير:** توليد وحوش الخرائط من الـ Lua بيفشل لبعض السطور فقط؛ الوحوش الأساسية بتيجي من ملفات RDB. **لا تأثير على الدخول أو اللعب.**
* **إصلاح اختياري:** تصحيح صياغة `mob(...)` (فاصلة بين كل وسيط) أو تجاهلها.

### 8.2 `Could not find server 'BILLING' in sys.servers`
```
DB COM ERROR … DB_GetCommercialStorageInfo(dbo.smp_check_purchased_item)
```
* **السبب:** الـ Stored Procedure بتستخدم **Linked Server** اسمه `BILLING`، وهو مش معرّف في SQL.
* **التأثير:** صندوق المتجر/المشتريات (Cash Shop) فقط.
* **إصلاح اختياري (اختر واحدًا):**
  * تعريف Linked Server باسم `BILLING` لقاعدة `BILLING` على نفس الـ instance، **أو**
  * في `GameServer.opt`: `T:game.cash_usable_server:0` ثم إعادة ضغط `GameServer.eop`.

### 8.3 `Column server_idx_offset not found in query result set` (rzauth)
* **السبب:** عمود `server_idx_offset` غير موجود في `dbo.Accounts` (بياخد القيمة الافتراضية 0).
* **التأثير:** صفر — رسالة تحذير فقط.
* **إصلاح اختياري:** `ALTER TABLE dbo.Accounts ADD server_idx_offset int NOT NULL DEFAULT 0;`

### 8.4 `Invalid object name 'account'` (rzauth)
* **السبب:** استعلام افتراضي (`sql.db_updatelastserveridx`) بيكتب في جدول اسمه `account`، وجدولك اسمه `Accounts`.
* **التأثير:** آخر سيرفر اتلعب فيه مش بيتسجل. الدخول نفسه سليم.
* **الإصلاح (مطبق في `auth.opt` النهائي §10):**
```
sql.db_updatelastserveridx.query:UPDATE dbo.Accounts SET last_login_server_idx = ? WHERE account_id = ?;
sql.db_updatelastserveridx.param.serveridx:1
sql.db_updatelastserveridx.param.accountid:2
```
* بديل فوري: `sql.db_updatelastserveridx.enable:false`

---

## 9) تفاصيل تقنية ثمينة (لا تعيد اكتشافها)

1. **صيغة ملفات `.opt`:** `<type>:<key>:<value>` — أنواع شائعة: `S` نص · `N` رقم · `T`/`B` منطقي · `F` عشري. سطر واحد لكل إعداد، CRLF.
2. **قاعدة الضغط:** أي تعديل في `.opt` لازم يتحول لـ `.eop` بالأداة (`RappelzCompress` / `RappelzCompress_v2`) وإلا التعديل مش هيُقرأ.
3. **لا تلمس** `console._password` ولا `db.auth.md5_key` (قيم مشفرة خاصة بالحزمة).
4. **باكيت العميل → Auth (من تحليل `PrincessAuroraServer.exe`):**
   `[size:4 LE][id:2 LE][checksum:1 = مجموع أول 6 بايتات mod 256]` والـ size يشمل الهيدر.
5. **أول 46 بايت من العميل الحقيقي:** `55 0C 41 01 24 02 32 F8 …` (طبقة تشفير حقيقية قبل الهيدر) — عادي وطبيعي مع rzauth.
6. **أوامر تشخيص استخدمناها (بتنفع تاني):**
```bat
netstat -ano | findstr :1996
tasklist | findstr /i "gamemon npgg nprotect ahnlab hackshield"
powershell -c "Get-Process sframe -ea 0 | %{ $_.Path; (Get-Item $_.Path).Length; (Get-FileHash $_.Path -Algorithm MD5).Hash }"
powershell -c "Get-ChildItem '<folder>\*.exe' | %{ '{0,-22} {1,10} {2}' -f $_.Name,$_.Length,(Get-FileHash $_.FullName -Algorithm MD5).Hash }"
```
7. **سمّاعة TCP للتشخيص** (تستقبل أول بايتات العميل على 1996 بعد إغلاق rzauth):
```powershell
powershell -c "$l=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Any,1996);$l.Start();'LISTENING...';$c=$l.AcceptTcpClient();'CONNECTED';$s=$c.GetStream();$s.ReadTimeout=20000;$b=New-Object byte[] 64;$n=$s.Read($b,0,64);'BYTES='+$n;(($b[0..([Math]::Max($n-1,0))]|%{'{0:X2}' -f $_}) -join ' ');$c.Close();$l.Stop()"
```
8. **إرسال باكيت صحيح للـ Auth** (اختبار أن السيرفر يقرا الباكيتات):
```powershell
powershell -c "$b=[byte[]](0x07,0,0,0,0x11,0x27,0x3F);$c=New-Object Net.Sockets.TcpClient('127.0.0.1',1996);$s=$c.GetStream();$s.Write($b,0,$b.Length);Start-Sleep -Seconds 2;$c.Close()"
```
   * مع **rzauth** المفروض ما يطلعش أي `Invalid Message`.
   * مع **PrincessAuroraServer** كان بيطلع رسالة، وده كان دليل تعطّله.
9. **تشخيص أعمق في rzauth:** `trafficdump.enable:true` → ملفات فيها كل باكيت (hex + json) في `traffic_log\`. مفيد جدًا لو حصلت مشكلة جديدة.
10. **نسخة الحزمة الأصلية:** `FilesOfficial-Revolution9.1.rar` — 144,010,622 B · md5 `497493248abf9b8024124ab89740d847` · الباسورد الداخلي `Revolution-Team` · الرابط: archive.org (files-official-revolution-9.1upload-by-marm).

---

## 10) الإعدادات النهائية الجاهزة — `C:\RZ\rzauth\auth.opt`

```
############################################################
# rzauth v6.5 - RAPPELZ AUTH EMULATOR
# Revolution 9.1 files + SQL database "Auth" (dbo.Accounts)
# Working account:  test2 / test123
############################################################
core.appname:rzauth

# ---- DATABASE (login that works: rappelz / EMPTY password) ----
auth.db.driver:SQL Server
auth.db.server:127.0.0.1
auth.db.port:1433
auth.db.name:Auth
auth.db.account:rappelz
auth.db.password:
#auth.db.connectionstring:DRIVER=SQL Server;Server=127.0.0.1,1433;Database=Auth;Trusted_Connection=yes;

# MD5 salt: password in dbo.Accounts = md5( salt + password )
auth.db.salt:A4&8zx209z&8zx267Ope

# ---- CLIENTS ----
auth.clients.ip:0.0.0.0
auth.clients.port:1996
auth.clients.autostart:true
auth.clients.idletimeout:0
auth.clients.restrictchars:true

# ---- GAME SERVER ----
auth.gameserver.ip:0.0.0.0
auth.gameserver.port:4502
auth.gameserver.autostart:true

# ---- ACCOUNTS TABLE ----
sql.db_account.query:SELECT * FROM dbo.Accounts WHERE login_name = ? AND password = ?;
sql.db_account.param.account:1
sql.db_account.param.password:2
sql.db_account.param.ip:-1
sql.db_account.column.accountid:account_id
sql.db_account.column.password:password
sql.db_account.column.block:block
sql.db_account.column.authok:auth_ok
sql.db_account.column.age:age
sql.db_account.column.pcbang:pcbang
sql.db_account.column.lastserveridx:last_login_server_idx
sql.db_account.column.eventcode:event_code

sql.db_updatelastserveridx.query:UPDATE dbo.Accounts SET last_login_server_idx = ? WHERE account_id = ?;
sql.db_updatelastserveridx.param.serveridx:1
sql.db_updatelastserveridx.param.accountid:2

sql.db_securitynocheck.enable:false

# ---- UPLOAD (built-in) ----
upload.gameserver.ip:127.0.0.1
upload.gameserver.port:4616
upload.dir:upload
upload.clients.ip:0.0.0.0
upload.clients.port:4617
upload.iconserver.ip:0.0.0.0
upload.iconserver.port:5000

# ---- LOGS ----
core.log.level:info
core.log.consolelevel:info

# ---- TRAFFIC DUMP (diagnosis only) ----
trafficdump.enable:false
trafficdump.dump_raw:true
```

> الحزمة الجاهزة: `rz-kit/rzauth-v6.5-win64.zip` (في مساحة العمل) — تحتوي `rzauth.exe`, `rzu.dll`, الـ 2 DLL بتوع OpenSSL, `auth.opt`, و`rzauth_user_guide.md`.

---

## 11) المتبقي / TODO (مرتب بالأهمية)

> ⚠️ **هذا القسم تاريخي (قبل جلسة 2026-11-10). القائمة الحالية المعتمدة في §19.**

1. **حساب حقيقي بدل `test2`** — اعمله بالـ SQL في §5 (باسورد قوي + مفتاح MD5).
2. **صلاحيات GM** — لم يتم التحقق منها بعد. المؤشر: جدول `Telecaster1.dbo.Character` (يُبحث عن عمود `authority`/`gm`/`grade`) + إعداد `game.` الخاص بـ GM في `GameServer.opt`. **لم يُختبر بعد.**
3. **المتجر/الكاش شوب** — تعريف Linked Server باسم `BILLING` (أو إيقاف `game.cash_usable_server`).
4. **الأسعار (Rates)** — في `GameServer.opt`: `F:game.exp_rate`, `F:game.gold_drop_rate`, `F:game.item_drop_rate` … ثم **إعادة ضغط `GameServer.eop`** وإعادة تشغيل.
5. **أخطاء Lua** — تصحيح `mob(...)` في سكربتات الخرائط (تجميلي).
6. **عمود `server_idx_offset`** — `ALTER TABLE` لإسكات التحذير (تجميلي).
7. **الأمان (مهم قبل أي فتح للإنترنت):** البورت 1433 مفتوح + `rappelz` باسورد فاضي sysadmin → مقبول محليًا فقط. قبل أي تعريض للخارج: باسورد قوي، إغلاق 1433، وتشغيل rzauth بحساب SQL محدود الصلاحيات.
8. **نسخة احتياطية** من: `C:\RZ\rzauth\auth.opt` · `AuthServer`/`GameServer` opts و`.eop` · قاعدة `Auth` (backup .bak).
9. **تحديث ملفات الهاندوفر القديمة:** `rz-server-handover-guide.docx` / `.md` (مكتوبة قبل اكتشاف عطل الـ Auth الرسمي — **لا تعتمد عليها في موضوع سيرفر الدخول**).

---

## 12) سجل الأدلة (Screenshots / ملفات)

* `uploads/image-64.png` … `image-86.png` — سجل كامل بالصور لكل مرحلة: رسائل `tuser`، سكيمـا `Accounts`، الحسابات المُدخلة، فولدر الكلينت، شاشة الدخول، `Invalid Message`، `netstat`، كونسولات السيرفرات، ثم **الدخول الناجح للعبة** (صورة اللعبة + الكونسولات الثلاثة).
* `rz-kit/sframe/SFrame-Revolution91.exe` — نسخة sframe الحزمة (md5 `098bc3fa…`).
* `rz-kit/rzauth-v6.5-win64.zip` — حزمة سيرفر الدخول الجاهزة.
* `rz-kit/configs/{authserver.opt, GameServer.opt, ServerLauncher.opt}` — نُسخ مرجعية.
* `rz-opt/GameServer.opt.FIXED.txt` — نسخة `GameServer.opt` الأصلية للحزمة (2,108 B).

---

## 13) ملخص في 6 سطور (لو مش فاضي تقرأ كله)

1. **السبب الجذري لكل المعاناة:** `PrincessAuroraServer.exe` الرسمي لا يقرأ باكيتات العملاء على هذا الجهاز (مثبت باختبار باكيت مصنوع يدويًا).
2. **الحل:** `rzauth` v6.5 في `C:\RZ\rzauth\` على بورت 1996، متصل بقاعدة `Auth` بحساب `rappelz` (باسورد فاضي).
3. **الحساب الشغّال:** `test2` / `test123`.
4. **الكلينت:** sframe الحزمة + سطر التشغيل اللي فيه `/auth_port:1996` و`/use_nprotect:0`.
5. **الترتيب:** SQL → LogServer → rzauth → CaptainHerlockServer → الكلينت. وممنوع تشغيل `PrincessAuroraServer`/`UploadServer`.
6. **الباقي كله تجميلي** (Lua + BILLING + تحذيرات SQL) ومش بيأثر على اللعب.

---

## 14) Hamachi — فتح السيرفر لصديق / لاعبين (2026-11-10)

### 14.1 القيم المعتمدة
| العنصر | القيمة |
|---|---|
| IP هاماتشي جهاز السيرفر | **`25.21.212.130`** |
| اسم الشبكة | `ahmed-rappelz` |
| بورتات لازمة للخارج | **1996** (الدخول) + **4514** (العالم) |
| بورتات اختيارية | 4617 / 5000 (أيقونات النقابات) |

### 14.2 التغيير الوحيد على السيرفر
```
GameEngine\Game_bin\GameServer.opt   سطر 12
S:io.ip_address:127.0.0.1   →   S:io.ip_address:25.21.212.130
```
ثم **إعادة الضغط** (السيرفر يقرأ `.eop`):
```cmd
cd /d "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin" && RappelzCompress.exe GameServer.opt
```
- `io.ip_address` = العنوان الذي يُعرَّف به العميل على سيرفر العالم (4514). لو بقي `127.0.0.1` فاللاعب ينجح في الدخول ثم ينقطع عند تحميل العالم.
- **لا يُلمس**: `io.auth.ip` · `io.port` · `db.*` · `auth.server_idx` · `auth.opt` بالكامل.
- النسخ الاحتياطية: `GameServer.opt.BEFORE-HAMACHI` و`GameServer.eop.BEFORE-HAMACHI`.

### 14.3 الجدار الناري (يحل محل قاعدة `RZ-LOCK`)
```cmd
netsh advfirewall firewall delete rule name="RZ-LOCK"
netsh advfirewall firewall add rule name="RZ-HAMACHI-IN" dir=in action=allow protocol=TCP localport=1996,4514 remoteip=25.0.0.0/8
netsh advfirewall firewall add rule name="RZ-BLOCK-SQL" dir=in action=block protocol=TCP localport=1433
```
سبب الاستبدال: `RZ-LOCK` تحجب كل شيء ومنها هاماتشي ⇒ اللاعب لا يستطيع الاتصال.

### 14.4 الكلاينت المرسل للاعب
1. من **نسخة** المجلد: احذف `rappelz_v1.opt` · `sframe_old.exe` · `Screenshot\` · `*.log` · `*.dmp`.
2. في `Revolution Launcher.bat` استبدل `127.0.0.1` بـ `25.21.212.130` (لا تُلمس أي حاجة أخرى).
3. بديل جاهز: `Play-Hamachi.bat` (يجرّب `RappelzCmdLauncher.exe` ثم `sframe.exe`).
4. اضغط 7z (`Fastest`) وارفعه Google Drive.
5. **ممنوع** تحميل كلاينت من مصدر آخر ⇒ `This Session is not verify version` (خلاف `sframe`/`game.version`).

### 14.5 اختبار قبل التحميل
```powershell
Test-NetConnection 25.21.212.130 -Port 1996     # لازم TcpTestSucceeded : True
```

### 14.6 الرجوع للوضع المحلي
- `io.ip_address` → `127.0.0.1` + إعادة ضغط، أو استرجاع `*.BEFORE-HAMACHI`.
- حذف `RZ-HAMACHI-IN` وإعادة `RZ-LOCK`.
- `UPDATE Auth.dbo.Accounts SET block = 1 WHERE login_name = N'friend1';`

### 14.7 ملفات هذه المرحلة
`apply-hamachi-ip.cmd` · `Play-Hamachi.bat` · `MESSAGE-TO-FRIEND-AR.txt` · `add-friend-account.sql` · `RZ-HAMACHI-GUIDE-AR.md`

---

## 15) الجي إم — الحالة الفعلية والخطة (2026-11-10)

### 15.1 نتيجة الفحص (قاطعة، لا تُعِد اكتشافها)
| المطلوب | موجود؟ | الدليل |
|---|---|---|
| أوامر شات GM (`.buff` / `.item`) | ❌ | لا يوجد جدول أوامر شات في `CaptainHerlockServer.exe` |
| أوامر شيت في الكونسول | ❌ | أوامر الكونسول: `about · set · get · show · del · watch · list · history · terminate · quit` |
| `GMTool.exe` في الباك | ❌ | الباك: Auth_bin · Game_bin · Log_bin · Server_Launcher · DBupdater · GameGuard |
| procs `gmtool_cheat_*` | ❌ | الموجود في `Telecaster.bak` 4 فقط: `gmtool_Remove_Delete_item_rows` · `gmtool_set_character_quest` · `gmtool_v3_DTS_character_info` · `gmtool_v3_DTS_item_summon_info` |
| جدول `AllowedCommandsForPermission` | ❌ | غير موجود في `Telecaster.bak` |
| نظام صلاحية (`AuthorityInfo` + `permission`) | ✅ | procs + عمود `dbo.Character.permission` |

**الخلاصة:** الصلاحية موجودة **كبيانات**، والواجهة التي تنفّذ أوامر **غير موجودة في الباك**.

### 15.2 أعمدة `Telecaster1.dbo.Character` المؤكدة (من INSERT داخل الباك)
`sid · name · account · account_id · slot · x · y · z · layer · race · sex · exp · last_decreased_exp · lv · max_reached_level · hp · mp · stamina · havoc · jlv · jp · total_jp · talent_point · job_0..2 · jlv_0..2 · immoral_point · cha · pkc · dkc · huntaholic_point · huntaholic_enter_count · ethereal_stone_durability · create_time · delete_time · login_time · logout_time · mogin_count · play_time · belt_00..05 · permission · skin_color · model_00..04 · hair_color_index · hair_color_rgb · hide_equip_flag · texture_id · job · gold · party_id · flag_list · job_depth · summon_0..5 · main_summon · sub_summon · remain_summon_time · pet · main_title · sub_title_0..4 · remain_title_time · arena_point · arena_block_time · arena_penalty_count · arena_penalty_dec_time · arena_mvp_count · arena_record_x_y · alias · chaos · adv_chat_count · name_changed · auto_used · pkmode · otp_value · otp_date · chat_block_time`

> `dbo.Item`: `sid · owner_id · account_id · summon_id · auction_id · keeping_id · idx · code · flag · cnt · level · enhance …` (الأعمدة المتبقية غير مؤكدة ⇒ لا تُخترع `INSERT`).

### 15.3 نصوص الـ procs الرسمية (نقلًا عن `Telecaster.bak`، بعد تنظيف أخطاء صفحة النسخة الاحتياطية)
```sql
-- smp_read_authority_info
CREATE PROCEDURE dbo.smp_read_authority_info
  @IN_ACCOUNT_ID INT
AS
SET NOCOUNT ON
SELECT authority_type, DATEDIFF(SECOND, GETDATE(), expire_time) AS remain_time
FROM ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo
WHERE account = @IN_ACCOUNT_ID AND expire_time > GETDATE()
RETURN @@ERROR

-- smp_set_authority_info
CREATE PROCEDURE dbo.smp_set_authority_info
  @IN_ACCOUNT_ID INT, @IN_AUTHORITY_TYPE INT, @IN_REMAIN_TIME INT
AS
SET NOCOUNT ON
DECLARE @COUNT INT
SELECT @COUNT = COUNT(*) FROM ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo
 WHERE account = @IN_ACCOUNT_ID AND authority_type = @IN_AUTHORITY_TYPE
IF @COUNT < 1
  INSERT INTO ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo (account, authority_type, expire_time)
  VALUES (@IN_ACCOUNT_ID, @IN_AUTHORITY_TYPE, DATEADD(SECOND, @IN_REMAIN_TIME, GETDATE()))
ELSE
  UPDATE ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo
  SET expire_time = DATEADD(SECOND, @IN_REMAIN_TIME,
        CASE WHEN GETDATE() > expire_time THEN GETDATE() ELSE expire_time END)
  WHERE account = @IN_ACCOUNT_ID AND authority_type = @IN_AUTHORITY_TYPE
RETURN @@ERROR

-- smp_close_authority_info
CREATE PROCEDURE dbo.smp_close_authority_info
  @IN_ACCOUNT_ID INT, @IN_AUTHORITY_TYPE INT
AS
SET NOCOUNT ON
UPDATE ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo SET expire_time = 0
WHERE account = @IN_ACCOUNT_ID AND authority_type = @IN_AUTHORITY_TYPE
RETURN @@ERROR
```
- الاسم `ArcadiaInfo.ArcadiaInfo.dbo.X` = **Linked Server** اسمه `ArcadiaInfo` + قاعدة `ArcadiaInfo`.
- `authority_type = 910000` = صلاحية كاش شوب (تُنسخ من `Billing.dbo.PaidItem`).
- **قيمة `authority_type` للجي إم غير موجودة في الباك** — ممنوع تخمينها.
- `game.use_account_authority_db` غير موجود في `GameServer.opt` الحالي (أي: مطفّي).

### 15.4 أدوات الجي إم التي بُنيت بديلًا عن الأداة الغائبة
| الملف | الوظيفة |
|---|---|
| `create-gm-account.sql` | إنشاء `gmadmin` في `Auth.dbo.Accounts` بـ `md5(salt+password)` |
| `gm.ps1` | GM Console بـ 14 أمرًا فوق `sqlcmd` (UTF-8 BOM) |
| `rz-gm-powers.sql` | نفس القدرات كـ SQL خام + استعلامات مراجعة |
| `RZ-GM-PLAN-AR.md` | الخطة المرحلية + جدول "شيفتة ← طريقة" + قاعدة بدون أخطاء |
| `RZ-GM-HOWTO-AR.md` | شرح الأدلة والصلاحية الرسمية |

أوامر `gm.ps1`: `list · who · gold · goldset · points · level · perm · tp · block · accounts · sql · help · exit`
- تحقق أمان: أسماء الشخصيات `^[A-Za-z0-9_\-]{1,31}$`، الأرقام `^-?[0-9]{1,10}$`، ولا تركيب SQL حر إلا بأمر `sql`.

### 15.4.1 بيانات حساب الجي إم الفعلي (2026-11-10)

| العنصر | القيمة |
|---|---|
| Login name | **`zahran7710`** |
| الباسورد | `Ahmed7710` — **مع المالك فقط، ولا يُخزَّن في هذا الملف لأسباب أمنية** |
| اسم الشخصية | **`OwnerZahran`** |
| طريقة الإنشاء | حساب في `Auth.dbo.Accounts` + شخصية أُنشئت من داخل اللعبة ثم خرج |
| الحالة | ✅ الحساب يعمل ويدخل اللعبة |

> قاعدة ثابتة: حساب الجي إم منفصل تمامًا عن حسابات الاختبار (`test2`) وعن حساب اللاعب (`friend1`).

### 15.4.2 فخ تشغيلي (حصل فعلًا)

أوامر `gm.ps1` تُكتب في **نافذة PowerShell** (`GM>` prompt) — **لا** في شات اللعبة. أول محاولة كتب الأوامر في شات اللعبة فظهرت كرسائل:
```
OwnerZahran: who OwnerZahran
OwnerZahran: gold OwnerZahran 1000000
```
ولا شيء تغيّر في الشخصية. **التحقق الدائم:** لو الأمر ظهر في شات اللعبة ⇒ اتحوّل لرسالة شات ومتجاهَل.

**وأيضًا:** الشخصية لازم تكون **خارج اللعبة** قبل `gold/points/level/tp`، لأن السيرفر يحفظ حالة الشخصية من الذاكرة عند الخروج ويمسح أي تعديل خارجي.

### 15.4.3 محرّك سكربتات Lua — الطريق الوحيد لأوامر جي إم **داخل اللعبة** (اكتشاف 2026-11-10)

**حقائق مؤكدة من الباك:**
- `GameEngine\Game_bin\Resource\Script\` = **42 ملف `.lua`** + ملفات `.ela` + **`RappelzCompress_v2.exe`** (يحوّل `.lua` → `.ela`).
- نمط الربط: كل NPC له اسم سكربت ودالتان `NPC_<name>_init()` و`NPC_<name>_contact()` — مثال: `NPC_Buff.lua` → `NPC_Secroute_mage_init/contact`.
- واجهة الحوار: `dlg_title()` · `dlg_text()` · `dlg_menu(text,"callback()")` · `dlg_show()` · `set_npc_name()` · `cprint()`.
- دوال التأثير اللايف المستخدمة فعليًا في سكربتات الباك:
  `add_state(code, level, duration_ms)` (بفات) · `set_value("gold", n)` · `insert_gold` · `insert_item` · `drop_item` · `delete_item` · `change_item_code` · `add_exp_jp` · `get_value` · `get_state_level` · `get_account_flag`.
- **لا توجد أي دالة `permission` أو قراءة اسم اللاعب** في السكربتات ⇒ بوابة الأمان تحتاج حلًا (`get_account_flag` مرشح، أو تخصيص NPC نادر الوصول).

**لماذا لا يمكن أوامر الشات:** الشات يُرسَل إلى LogServer فقط (`log.chat.ip`)، وLogServer يكتب ملفات نصية `Log\<channel>_YYYY-MM-DD HH.txt` — لا يوجد hook يقرأ الأوامر داخل السيرفر.

**الحكم:** لوحة GM داخل اللعبة عبر NPC = ممكنة وتعمل **لايف** (على عكس تعديلات DB). الخطة الكاملة في `RZ-GM-INGAME-PLAN-AR.md`، وتبدأ بمرحلة 0 (إثبات خط الأنابيب بتعديل سطر واحد في `NPC_Buff.lua` + الضغط + إعادة تشغيل).

### 15.4.4 أسئلة معمارية عن الجي إم — وإجاباتها النهائية (2026-11-10)

**قرار المستخدم الثابت:** لا يريد NPC ظاهرًا للاعبين، ولا متجرًا بصلاحية جي إم. يريد الشيتات **خاصة بالجي إم فقط**، وأن تعمل لصاحب الجي إم بدون سورس وبدون كونسول.

| السؤال | الإجابة |
|---|---|
| هل أوامر الشات ممكنة؟ | ❌ لا. لا يوجد parser للشات في البايناري. |
| هل الكونسول ينفّذ شيتات؟ | ❌ لا. أوامره إدارية فقط (`about/set/get/show/del/watch/list/history/terminate/quit`)، والباسورد مشفّر. |
| كيف تعمل في السيرفرات الأخرى؟ | إما **أداة GMTool** تتصل بالسيرفر (البروتوكول موجود في البايناري: `GMTool` · `GMEMBER(...)` · `GPERMISSION(...)` · `HAS_NO_AUTHORITY`) — والأداة غير موجودة في الباك · أو **GameServer معدّل بالسورس** لإضافة parser أوامر. |
| صاحب الجي إم ينفّذ إزاي بدون سورس/كونسول؟ | (1) **منطقة مقفولة للجي إم** فيها لوحة أوامر — الأفضل · (2) المالك ينفّذ نيابة عنه بـ `gm.ps1` · (3) أداة GMTool لو توفّرت. |
| هل يمكن منطقة للجي إم فقط؟ | ✅ نعم بخريطة **موجودة** (الخرائط الجديدة تحتاج تعديل كلينت). البوابة: **أيتم** (`has_item`) أو **flag** (`get_account_flag`) أو **نقل يدوي** بـ `gm.ps1 tp`. **لا توجد دالة permission في Lua** — لا يمكن الاعتماد عليها. |
| هل اللاعبون سيرون لوحة الأوامر؟ | ❌ لا، إذا كانت داخل منطقة لا يستطيعون دخولها. |

**البنية المعتمدة للأوامر اللايف:** `خريطة مقفولة + بوابة شرطية + لوحة أوامر Lua` ← هذه الوحيدة التي تعطي جي إم "شيتات لايف" في هذا الباك، وتعمل على VPS بلا تعديل.

### 15.4.5 تصميم منطقة الجي إم + لوحة الأوامر (قرار المستخدم 2026-11-10)

**المطلوب:** منطقة يدخلها الجي إم فقط (بأيتم/صلاحية) + NPC داخلها بكل الأوامر (لفل/فلوس/بفات) للاعب أو للكل + إعلان على السيرفر باسم اللاعب المستفيد.

**قرارات ثابتة:**
- لا NPC ظاهر للاعبين · لا متجر · الشيتات للجي إم فقط.
- لوحة الأوامر تكون داخل **منطقة مقفولة**.

**ثلاث قيود تقنية حاكمة (مؤكدة):**
1. لا دالة `permission` في Lua ⇒ البوابة = **أيتم** أو **`get_account_flag`** أو **نقل يدوي**.
2. `dlg_menu` **أزرار فقط** — لا يوجد إدخال نص ⇒ "اكتب اسم اللاعب" غير ممكن مباشرة (الحلول: اللاعب ييجي بنفسه · أزرار أسماء أونلاين · `gm.ps1` للأوفلاين).
3. خصائص الأيتم (منع البيع/الإسقاط/التكسير) **ليست في قاعدة البيانات** بل في تعريف الأيتم بملفات اللعبة ⇒ الأيتم يصلح "مفتاحًا" لكن ليس ضمانًا. الأنضف: بوابة `flag`.

**منطقة مقترحة:** إنستانس/سيكرت دنجن (`enter_secret_dungeon`) للإنتاج · ركن مدينة للاختبار · الخرائط الجديدة تحتاج تعديل كلينت.
**النقل اليدوي للبداية:** `gm.ps1` → `tp OwnerZahran X Y Z LAYER`.

**الإعلان باسم اللاعب:** البايناري فيه `SCRIPT_BroadcastNotice`/`SCRIPT_Announce` لكن اسم الدالة في Lua غير مؤكد ⇒ أول بند في المسبار.

**الخطوة التالية المعتمدة: المرحلة 0 — مسبار القدرات** (`gm_probe.lua`: دوال فقط، لا تعدّل أي شيء، تطبع OK/MISSING في كونسول السيرفر).

**الملفات:** `RZ-GM-ZONE-DESIGN-AR.md` (التصميم الكامل) · `gm_probe.lua` (المسبار).

### 15.4.6 أدوات الجي إم الموجودة في المجتمع (بحث 2026-11-10)

**الأدوات:** Xijezu's GM-Tool V5 (**مفتوح المصدر — GitHub `Xijezu/GM-Tool`، C#/.NET 4.0**) · Royal GM-Tool · Shiva · Sapphire · Seizure · InstaGM (Telnet GM-Tool بسورس) · Zoidberg/Poultry. وبعض إصدارات "9.1 Official Files with Tools" تحتوي أداة رسمية.

**كيف تعمل:** إما (أ) تكتب في SQL ⇒ **ليست لايف** · أو (ب) تتصل بكونسول السيرفر Telnet `65528` ⇒ **لايف**.

**العائق المركزي:** `console._password` مشفّر (hex) ولا يُعرف نصه؛ في إعدادات 9.1 المنشورة يُكتب كـ `REPLACE.ME.WITH.PYROK.TOOL.GENERATED.PASSWORD` ⇒ يحتاج أداة **Pyrok** لتوليده. بدونه لا تتصل أي أداة (ولا الكونسول المحلي).

**مسارات الحل:** الحصول على Pyrok · اختبار قبول نص واضح في `console._password` (نسخة احتياطية + ضغط + رستارت + telnet) · أو تجاهل الكونسول كليًا والاعتماد على Lua.

**تحذير أمني ثابت:** أدوات مغلقة المصدر من المنتديات = احتمال باب خلفي. لا تُشغّل إلا مفتوحة المصدر أو بعد فحص، وعلى VM، ويمنع إعطاؤها `sa`.

**قرار المسار:** Lua أولًا (مضمون، بلا طرف ثالث، نفس السلوك على VPS) · تجربة الكونسول بالتوازي كاختبار واحد قابل للتراجع.

**الملف:** `RZ-GM-TOOLS-AR.md`.

### 15.5 الخطة المرحلية
0. نسخ احتياطي للقواعد إلى **`F:\AhmedZahran\rz-backup`** عبر `backup-rz.cmd` (مضغوط + `VERIFYONLY`).
1. `create-gm-account.sql` → إنشاء الشخصية من اللعبة → خروج كامل.
2. تشغيل `gm.ps1` → `gold` / `points` → تحقق داخل اللعبة.
3. **الاختبار الحاسم**: `perm <name> 1` ثم الدخول — هل ظهرت أوامر/أزرار GM في العميل؟
   - ظهرت ⇒ النظام مستهلك للصلاحية، نكمل عليه.
   - لم تظهر ⇒ `perm <name> 0` والاعتماد على GM Console.
4. الاعتماد على GM Console للأوامر + `GameServer.opt` للمعدلات.
5. تجهيز ما قبل الفتح للاعبين (حسابات، نسخ احتياطي، جدار ناري).

### 15.6 ماذا يعمل وماذا لا يعمل (بصراحة)
| الطلب | الحالة | الطريقة |
|---|---|---|
| فلوس / نقاط مهارات / نقاط إستات | ✅ 100% | `gm.ps1` (أعمدة مؤكدة) |
| ليفل | ✅ مع تحذير | `level` (يضبط `exp = 0`؛ جرّبه على شخصية تجريبية) |
| نقل شخصية | ✅ offline فقط | `tp` |
| قفل/فتح حساب | ✅ | `block` |
| معدلات خبرة/دروب | ✅ | `GameServer.opt` + إعادة ضغط |
| سكيلات بلا تهدئة / مشي في الحيوط | ✅ | `no_skill_cooltime` / `no_collision_check` |
| **بفات لايف** | ❌ | حالة runtime — تحتاج NPC سكربت (`SCRIPT_*`، 292 دالة في الـ exe) |
| **إنشاء أيتم / سباون مونستر** | ❌ | يحتاج سكربت/أداة |
| **أوامر شات GM** | ❌ | غير موجودة في الباك |

### 15.7 تحذيرات صلبة
- الشخصية **OUT** قبل أي `UPDATE` وإلا الحفظ التلقائي يمسح التعديل.
- لا تُعدّل `auth_ok` / `block` بالخطأ.
- `level` بدون `exp` ⇒ سلوك غير متوقع.
- نسخة احتياطية قبل التعديل الجماعي.

---

## 16) الاختصارات (Hotkeys) — الحقيقة والحل (2026-11-10)

**السبب:** في Rappelz **الحرف المفرد = شات**، والاختصارات كلها **Alt + حرف**. فتح الشات عند كتابة `i` **سلوك طبيعي** وليس عطلًا، ولذلك تغيير لغة الكيبورد لم يحل شيئًا.

| الاختصار | الوظيفة |
|---|---|
| `Alt+I` | الحقيبة |
| `Alt+Q` | المهام |
| `Alt+Y` | تكوين الكريتشر |
| `Alt+C` | الشخصية |
| `Alt+S` | المهارات |
| `Alt+G` | النقابة |
| `Alt+O` | الإعدادات |
| `Alt+V` | زاوية الكاميرا |
| `Tab` | اختيار الهدف |
| `F1–F9` | شريط المهارات |
| `Enter` | الشات |

**لو `Alt+…` لم يعمل، الترتيب:** Alt عالقة (اضغط Alt مرتين بعد أي Alt+Tab) ← استخدام **Alt اليسرى** (اليمنى = AltGr) ← إطفاء Sticky/Filter Keys ← إغلاق Overlays (Discord/GeForce/Afterburner/AutoHotkey) ← كيبورد آخر أو `osk.exe` ← `GRAPHIC_WINMODE=1` + `PLAY_ENTERCHAT` في `rappelz_v1.opt` ← حذف `rappelz_v1.opt` لإعادة توليده.
**دليل إضافي (من شاشة اللعبة عند المستخدم):** شريط المهارات يعرض التلميحات بصيغة **`Ctrl + F1…F12`** و**`Alt + F1…F12`** — أي أن نظام اللعبة نفسه يعتمد على `Alt/Ctrl + مفتاح`، ويؤكد أن الحرف المفرد مخصّص للشات.

**الملف:** `RZ-CONTROLS-AR.md`.

---

## 17) الأمان / الثغرات (2026-11-10)

### 17.1 خريطة المنافذ ومخاطرها
| المنفذ | الخدمة | يسمع | الخطر |
|---|---|---|---|
| 1433 | SQL Server | 0.0.0.0 | 🔴 الأعلى — حساب `rappelz` بلا باسورد |
| 5000 | rzauth icon/upload (HTTP) | 0.0.0.0 | 🔴 سطح هجوم ويب |
| 1996 | rzauth دخول اللاعبين | 0.0.0.0 | 🟠 مطلوب للعب |
| 4502 | rzauth ↔ GameServer | 0.0.0.0 | 🟠 داخلي |
| 4514 | GameServer acceptor | 0.0.0.0 | 🟠 مطلوب للعب |
| 4616/4617 | Upload | 0.0.0.0 | 🟢 |
| 4501 | rzauth admin console | 127.0.0.1 | 🟢 سليم |
| 65528 | GameServer console | 127.0.0.1 + باسورد | 🟢 سليم |

### 17.2 تحصين فوري
- قاعدة الجدار الناري: §14.3.
- حسابات SQL: `rz_app` بدل `rappelz` (db_datareader/db_datawriter + EXECUTE على `Auth`)، ثم تعطيل `sa` — **في جلسة منفصلة مع اختبار دخول** لأن `GameServer.opt` يستخدم `db.user.account` أيضًا.
- فحص إعدادات: `xp_cmdshell` · `Ole Automation Procedures` · `clr enabled` · `remote admin connections` = 0.
- نسخ احتياطي مجدول للقواعد الثلاث.

### 17.3 بجات معروفة في سيرفرات رابلز الخاصة
باكيتات Auth مصنوعة (سبب فشل الرسمي سابقًا) · IMBC autologin في rzauth · SQL Injection عبر أسماء الشخصيات/النقابات · التكرار (dupe) عند قطع الاتصال أثناء النقل · GM command abuse · إغراق الدخول · كلاينت معدّل (`ignore_client_binary`).
**الملف:** `RZ-SECURITY-AUDIT-AR.md`.

---

## 18) جرد كل الملفات في مساحة العمل

| الملف | الغرض | الحالة |
|---|---|---|
| `RAPPELZ-MEMORY-AR.md` | هذا الملف (المرجع الشامل) | ✅ محدّث |
| `backup-rz.cmd` | نسخ احتياطي مضغوط لكل القواعد إلى `F:\AhmedZahran\rz-backup` | ✅ جديد |
| `RZ-GM-PLAN-AR.md` | خطة الجي إم المرحلية | ✅ جديد |
| `RZ-GM-HOWTO-AR.md` | أدلة الجي إم والصلاحية الرسمية | ✅ |
| `RZ-GM-INGAME-PLAN-AR.md` | خطة أوامر الجي إم داخل اللعبة (NPC + Lua) | ✅ جديد |
| `RZ-GM-ZONE-DESIGN-AR.md` | تصميم منطقة الجي إم + لوحة الأوامر | ✅ جديد |
| `RZ-GM-TOOLS-AR.md` | أدوات الجي إم المجتمعية + عائق باسورد الكونسول | ✅ جديد |
| `gm_probe.lua` | مسبار قدرات الـ Lua (قراءة فقط) | ✅ جديد |
| `create-gm-account.sql` | إنشاء حساب GM | ✅ جديد |
| `gm.ps1` | GM Console (14 أمرًا) | ✅ جديد |
| `rz-gm-powers.sql` | قدرات GM كـ SQL خام | ✅ |
| `rz-gm-discovery.sql` | استكشاف جداول الصلاحيات | ✅ |
| `add-friend-account.sql` | حساب اللاعب | ✅ |
| `RZ-HAMACHI-GUIDE-AR.md` | دليل هاماتشي الكامل | ✅ |
| `apply-hamachi-ip.cmd` | تعديل IP + إعادة ضغط | ✅ |
| `Play-Hamachi.bat` | تشغيل الكلاينت على `25.21.212.130` | ✅ |
| `MESSAGE-TO-FRIEND-AR.txt` | رسالة جاهزة للاعب | ✅ |
| `RZ-CONTROLS-AR.md` | الاختصارات | ✅ |
| `RZ-SECURITY-AUDIT-AR.md` | الثغرات والتحصين | ✅ |
| `rz-kit/rzauth/` | rzauth + `auth.opt` النهائي | ✅ |
| `rz-kit/rzauth-v6.5-win64.zip` | حزمة rzauth (3,156,001 B) | ✅ |
| `rz-kit/configs/` | `GameServer.opt` + `GameServer.opt.LOCAL-BACKUP.bak` + `authserver.opt` + `ServerLauncher.opt` | ✅ |
| `rz-kit/sframe/SFrame-Revolution91.exe` | sframe (md5 `098bc3fa558481241772eb3d4b221b8f`) | ✅ |
| `rz-opt/GameServer.opt.FIXED.txt` | نسخة إعدادات مصححة | ✅ |
| `uploads/image-*.png` | أدلة مصورة من كل المراحل | ✅ |

---

## 19) الحالة الحالية والمتبقي (يحل محل §11)

### ✅ منجز ومُتحقق منه
1. الدخول للعبة يعمل عبر rzauth (بدل `PrincessAuroraServer.exe` المعطوب).
1.b **نسخ احتياطي كامل يعمل** لـ `Auth` · `Telecaster1` · `Arcadia` · `Billing` إلى `F:\AhmedZahran\rz-backup` مع `VERIFYONLY` (SQL Express ⇒ بدون ضغط).
2. `auth.opt` نهائي (rappelz / باسورد فارغ / salt / query مصحح).
3. القواعد الثلاث مستعادة (`Auth` · `Telecaster1` · `ArcadiaInfo`).
4. هاماتشي معدّ بملفات جاهزة على `25.21.212.130`.
5. الاختصارات مشخّصة (Alt+letter) مع دليل كامل.
6. أمان: خريطة منافذ + قواعد جدار ناري جاهزة.
7. جي إم: أداة `gm.ps1` + حساب جاهز (`create-gm-account.sql`) + خطة مرحلية.

### ⏳ مفتوح (يحتاج تنفيذًا على الجهاز)
1. **المرحلة 1**: إنشاء `gmadmin` + الشخصية + `gold` تجريبي.
2. **المرحلة 3**: اختبار `permission = 1` — هل يظهر أي واجهة GM في العميل؟
3. تطبيق IP هاماتشي + إعادة الضغط + اختبار `Test-NetConnection`.
4. تفعيل قاعدة الجدار الناري `RZ-HAMACHI-IN` وحذف `RZ-LOCK`.
5. اختبار `Alt+I` داخل اللعبة (اختصارات).
6. (اختياري) `rz_app` بدل `rappelz` في SQL + تعطيل `sa`.
7. (اختياري/لاحقًا) NPC سكربت للبفات والأيتمز.

### ❌ خارج النطاق نهائيًا (لا يُعاد فتحه)
- إصلاح `PrincessAuroraServer.exe` — مُستبدل ونهائي.
- تشغيل `UploadServer.exe` — يتعارض مع rzauth.
- `sa` / `Ahmed@7710` — لا يعمل على هذا الـ instance.
- تخمين `authority_type` للجي إم.
- انتظار أوامر شات GM من الباك — غير موجودة.

---

## 19.1 قرارات ثابتة (لا تُغيَّر بدون طلب صريح)

| القرار | القيمة |
|---|---|
| مسار النسخ الاحتياطي | **`F:\AhmedZahran\rz-backup`** (القرص F: — لا تُستخدم C: بسبب المساحة) |
| صيغة النسخ | `WITH INIT, COMPRESSION, CHECKSUM` + `RESTORE VERIFYONLY` بعدها |
| أداة النسخ | `backup-rz.cmd` (تشمل منح صلاحية الكتابة لحساب خدمة SQL تلقائيًا) |
| IP هاماتشي | `25.21.212.130` |
| ترتيب التشغيل | SQL → LogServer → rzauth → CaptainHerlockServer → الكلاينت |

---

## 20) English TL;DR v2 (for any agent)

- **Working stack:** SQL Server → `LogServer.exe` → `rzauth.exe` (1996 clients / 4502 GS / 4501 admin on loopback) → `CaptainHerlockServer.exe` (4514, console 65528 loopback) → client via `Revolution Launcher.bat` with `/auth_ip:… /auth_port:1996 /use_nprotect:0`.
- **Official `PrincessAuroraServer.exe` is permanently replaced** (input-independent parse failure). Never start `UploadServer.exe`.
- **DB login that works:** `rappelz` + empty password. `sa` fails (ODBC 18456). Salt `A4&8zx209z&8zx267Ope`, password = `md5(salt + password)`.
- **Hamachi:** `25.21.212.130`; only `GameServer.opt` → `S:io.ip_address` changes, then recompress with `RappelzCompress.exe`. Firewall: allow 1996/4514 from `25.0.0.0/8`, block 1433.
- **GM:** the pack ships **no GM command system and no GMTool** (verified). Authority exists only as data (`ArcadiaInfo.dbo.AuthorityInfo` via linked server + `dbo.Character.permission`). Practical GM = `gm.ps1` (SQL-based console) + `GameServer.opt` rates. GM `authority_type` value is unknown — never guess.
- **Hotkeys:** Rappelz uses `Alt + letter` (`Alt+I` inventory); a lone letter opening chat is by design, not a bug.
- **Open items:** test `permission = 1` in the client, create the GM account, apply the Hamachi IP, activate the firewall rule.
