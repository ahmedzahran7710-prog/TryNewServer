# Rappelz 9.1 Private Server — Handover / Handoff Brief
_Last updated: 2026-11-12 · Machine: DESKTOP-ICC037B (user: Mena) · Language of the user: Egyptian Arabic_

> This file is written so another human or AI agent can continue the work with zero prior context.
> Read sections 0 → 5 before touching anything.

---

## 0. TL;DR

The server is **running**: SQL Server + Auth Server + Game Server, and Game is registered with Auth.
The single blocker that consumed ~6 hours was: **`CaptainHerlockServer.exe` never reads `GameServer.opt`** — it reads
**`GameServer.eop`** (a compressed/encrypted copy of the same text). The pack ships `RappelzCompress.exe` for exactly this.

**Golden rule:** after ANY edit to `GameServer.opt` → drag it onto `RappelzCompress.exe` → a new `GameServer.eop` is produced → restart the game server. Editing the `.opt` alone does nothing.

Remaining work: LogServer, UploadServer, create a player account, install + point the client, tune rates, close a SQL security hole.

---

## 1. Current state

| Component | State | Evidence |
|---|---|---|
| SQL Server 2019 (MSSQLSERVER), TCP 1433 | running | `SELECT @@VERSION` → 15.0.x |
| Auth Server `PrincessAuroraServer.exe` | running | `start db initializing... ok` |
| Game Server `CaptainHerlockServer.exe` | running | `Acceptor initialize... ok(IP: 0.0.0.0, Port: 4514)` |
| Game → Auth link | OK | Auth console: `Game Server Login: IP: 127.0.0.1(4514) Name : Revolution Official Index 1` |
| Log Server `LogServer.exe` | NOT running | `cannot connect log server: ip: 127.0.0.1, port: 4516` |
| Upload Server `UploadServer.exe` | NOT running | `Connect To Upload... failed … PORT 4616` |
| Client | not installed | installer present on `F:` |
| Player account | does not exist | — |

---

## 2. Install layout / paths

```
C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\
  Auth_bin\   PrincessAuroraServer.exe  UploadServer.exe  authserver.opt
              RappelzCompress_v2.exe  Log\
  Game_bin\   CaptainHerlockServer.exe  GameServer.opt  GameServer.eop   ← eop is what the server reads
              RappelzCompress.exe  EOPUpdater.exe  EOPUpdater.opt  GameLog.txt  Log\
  Log_bin\    LogServer.exe
  Server_Launcher\  ServerLauncher.exe / ServerLauncher_x64.exe / ServerLauncher.opt
  DBupdater\  DBUpdater.exe  dbupdater.eop  (+ RDU folder)

C:\RZ\DBs\        Arcadia.bak · Telecaster.bak · Billing.bak · Auth.bak
C:\RZ\Server\GameEngine\   ← stray EMPTY folder, ignore it completely
```

Client installer: `F:\...\rappelz server\Client\Rappelz_Setup_9.1.exe` (+ `.2 .3 .4`, it is one split archive; run the `.exe` only). Install target used: `F:\RZ\Client`.

---

## 3. Ports, databases, credentials

| Port | Service | Source |
|---|---|---|
| 1433 | SQL Server | SQL config |
| 1996 | client login (Client→Auth) | `authserver.opt: io.auth.port` |
| 1995 | Auth console | `console.port` |
| 4514 | Game ↔ Auth, and player sessions | `GameServer.opt: io.port` |
| 4516 | Log server | `LogServer.exe` |
| 4616 | Upload server | `io.upload.port` |
| 65528 | Game console | `console.port` |

Databases (all ONLINE): `Auth` (accounts, table `tuser`) · `Telecaster1` (user DB) · `Arcadia` (game/resources) · `BILLING`.

Credentials:

| Login | Password | Role | Used by |
|---|---|---|---|
| `rappelz` | **empty on purpose** | sysadmin | both servers |
| `sa` | `Ahmed@7710` | sysadmin | emergency only |

**Why empty:** the binaries read `db.auth._password` / `db.c._password` / `db.user._password` (encrypted values). Those keys are absent, so the servers send an **empty password**. `db.auth.password` and `db.user.password` are **ignored entirely** (proven by `xp_readerrorlog`). Do not "fix" this by adding a password to the `.opt` — it will break the login again. SSMS cannot type an empty password → always connect with **Windows Authentication**.

---

## 4. Effective config files

### 4.1 `GameServer.opt` (working copy, exactly 2108 bytes, ANSI, CRLF)

```
S:app.name:Game001
T:auth.server_idx:1
S:auth.server_name:Revolution Official
S:db.c.account:rappelz
S:db.c.name:Arcadia
S:db.c.server:127.0.0.1
S:db.user.account:rappelz
S:db.user.server:127.0.0.1
S:db.user.name:Telecaster1
N:io.port:4514
S:io.auth.ip:127.0.0.1
S:io.ip_address:127.0.0.1
S:log.chat.ip:127.0.0.1
S:log.ip:127.0.0.1
T:log.chat.working:1
T:log.working:0
F:game.exp_rate:42
F:game.ally_pcbang_bonus_rate:0.1
F:game.ally_pcbang_chaos_bonus_rate:0.1
T:game.update.version:24
F:game.gold_drop_rate:50
F:game.item_drop_rate:20
T:game.max_level:180
T:game.PKServer:1
T:game.AdultServer:0
T:game.cash_usable_server:1
N:game.local_flag:8192
T:game.min_global_chat_usable_level:80
T:game.use_auto_trap:0
T:game.use_auto_jail:0
N:CodePage:1256
T:game.ServiceServer:1
N:console.port:65528
S:console.allow_ip:127.0.0.1
S:console._password:455600000300b13015cbe8f4ea6bb5ee979a15b993f8dc9691ed74958a6b950e69c8178b959495640b7d2294b7
S:io.upload.ip:127.0.0.1
S:io.upload.port:4616
S:game.guild_icon_base_url:http://127.0.0.1/guild/
S:game.url_list:guild.url|http://127.0.0.1/login.aspx|guild_test_download.url|guild/|web_download|5.196.124.242|web_download_port|0|shop.url|http://shop.rappelz.co|ghelp_url|http://help.gamepower7.com/help/help-page/help-page.html|guild_icon_upload.ip|5.196.124.242|guild_icon_upload.port|4617

S:game.server_screenshot_url:http://rappelz.co/launcher/server.html
S:game.helpdesk_url:http://help.gamepower7.com/help/help-page/help-page.html
S:game.newbiehelp_asura_url:http://help.gamepower7.com/help/info_asura.html
S:game.newbiehelp_deva_url:http://help.gamepower7.com/help/info_deva.html
S:game.newbiehelp_gaia_url:http://help.gamepower7.com/help/info_gaia.html
S:game.local_setting_list:log.ip|log.chat.ip|io.auth.ip|io.ip_address|db.c.server|db.user.server|N game.periodical_npc_adjustment
T:game.disable_trade:0
T:game.disable_booth:0
T:game.enhance_fail_type:2
T:game.monster_pathfinding:1
T:game.monster_wandering:1
T:game.no_collision_check:0
T:game.no_skill_cooltime:0
N:game.item_hold_time:2500
T:db.user.thread:4
```

There is deliberately **no** `db.c.password` / `db.user.password` line (empty values can abort the parser, and the binary ignores them anyway).

### 4.2 `authserver.opt` key values

`db.auth.server=127.0.0.1`, `db.auth.name=Auth`, `db.auth.account=rappelz`, `db.billing.name=BILLING`,
`db.billing.account=rappelz`, `db.auth.use_md5=1`, `db.auth.md5_key=A4&8zx209z&8zx267Ope`, `io.auth.port=1996`,
`console.port=1995`, `console.allow_ip=127.0.0.1`, `billing.use=1`, `billing.allow_login_without_billing=1`.

⛔ **Never change** `console._password` (in both opt files) or `db.auth.md5_key`.

---

## 5. Root causes already solved (do not re-investigate)

1. First download was **Revolution 7.2**, not 9.1. Correct pack: 144,010,622 bytes, md5 `497493248abf9b8024124ab89740d847`, pass `Revolution-Team`.
2. SSMS 22 refuses to install ("OS not supported") → use **SSMS 19.3** (`https://go.microsoft.com/fwlink/?linkid=2257624&clcid=0x409`).
3. GUI restore of the `.bak` silently fails → use a `RESTORE … WITH MOVE` script; logical names are `Telecaster_New_Data` / `Telecaster_New_Log`.
4. `DBCC SHRINKFILE` without `USE <db>` → Msg 8985.
5. Auth "Login failed … Password did not match" → see §3 (empty password theory).
6. Game crash `C0000005` in `?callStartupHandler@DB_OnStartUp` → DB connect failure, not memory.
7. **All env values in the crash dump were compiled defaults** (`cadb.nflavor.com`, `exp_rate 1.0`, `item_hold_time 180000`) →
   binary never parsed the opt. Disassembly of `CaptainHerlockServer.exe` (RVA 0x2e4cf0 string, loader at 0x1402e4b70,
   `LoadFromFile` at 0x14031c6b0) shows it loads **`GameServer.eop`** (binary, "EV" + version `0x00030000` + zlib payload)
   into the global env and reads `db.c.account`, `db.c._password`, `db.user.account`, `db.user._password`, `db.billing.account`,
   `console._password` from it. `GameServer.opt` only supplies keys listed in `game.local_setting_list`.
   The RAR contains **no** `GameServer.eop` (only `DBupdater/dbupdater.eop`), therefore the server could not be configured at all.
   **Fix that worked:** drag `GameServer.opt` onto `RappelzCompress.exe` → `GameServer.eop` is created → server starts.

Dead ends already ruled out: running "as administrator" (changes CWD to `C:\Windows\System32`), `.opt.txt` naming,
UTF-16/BOM encoding (file verified ASCII/CRLF 2108 bytes), firewall, heap sizes, changing `RedMoon`/`auth.server_name`.

**Never send `.ps1` / `.bat` helper scripts** — they flash-close on this machine. Do everything through Notepad / SSMS / Explorer / one-line `cmd` commands.

---

## 6. Runbook (order matters)

1. SQL Server service running; all 4 DBs ONLINE (SSMS via Windows Auth).
2. If you edited `GameServer.opt` → save (ANSI) → drag onto `RappelzCompress.exe` in `Game_bin` → verify `GameServer.eop` timestamp updated.
3. Start `Log_bin\LogServer.exe` (optional but removes the red error).
4. Start `Auth_bin\PrincessAuroraServer.exe` — wait for `start db initializing... ok`.
5. Start `Game_bin\CaptainHerlockServer.exe` — wait for `Adding acceptor to IOCP... ok`.
6. Start `Auth_bin\UploadServer.exe`; in the Game console type `connect upload`.
7. In the Auth console type `start_service`.
8. Launch the client with `/auth_ip:127.0.0.1` and log in.

If SQL service is restarted for any reason → restart Auth then Game, in that order.

---

## 7. Remaining tasks

### 7.1 Account creation
```sql
USE [Auth];
SELECT TOP 5 * FROM dbo.tuser;
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'tuser';
```
Then, depending on the `password` column type:
```sql
-- varchar/nvarchar (needs db.auth.use_md5 = 0)
INSERT INTO dbo.tuser (id,password,email,authority) VALUES ('test','test','a@a.com',0);
-- varbinary/binary (MD5)
INSERT INTO dbo.tuser (id,password,email,authority) VALUES ('test',HASHBYTES('MD5','test'),'a@a.com',0);
```
Do not guess the column list — read it first; SQL will tell you which columns are NOT NULL.
If login is refused for billing reasons → set `N:billing.use:0` in `authserver.opt` and restart Auth.
If refused for password mismatch → set `N:db.auth.use_md5:0` and store plaintext.

### 7.2 Client
Install from `Rappelz_Setup_9.1.exe` to `F:\RZ\Client`, copy `RappelzCmdLauncher.exe` (from the pack's `Launcher\` folder) into the client folder, create `Revolution Launcher.bat` containing:
```
RappelzCmdLauncher.exe sframe.exe /auth_ip:127.0.0.1 /use_nprotect:0 /help_url_w:611 /help_url_h:625 /locale:Windows-1256 /country:ME /cash /commercial_shop /layout_dir:6 /layout_auto:0 /cash_url_w:800 /cash_url_h:631
```
`/use_nprotect:0` disables GameGuard; `/locale:Windows-1256 /country:ME` matches `CodePage:1256`.

### 7.3 Rates
`game.exp_rate` (42), `game.gold_drop_rate` (50), `game.item_drop_rate` (20), `game.max_level` (180), `game.item_hold_time` (2500).
**Always**: save → recompress with `RappelzCompress.exe` → restart Game.

### 7.4 Security (do before any internet exposure)
Port 1433 listens on `0.0.0.0` with an empty-password **sysadmin** login (`rappelz`) and another sysadmin (`sa`).
Fix: SQL Configuration Manager → TCP/IP → IPAll → remove TCP Port 1433 (or disable TCP), or block 1433 in Windows Firewall
except 127.0.0.1. Set a strong `sa` password. The empty password is acceptable only locally.

### 7.5 Cosmetic
`Lua run script failed. mob( 1002 167538,53382,169050,54432):1: ')' expected near ...` — malformed spawn scripts in
`Resource\Script`. Does not block login/play; replace the Script folder with a clean copy later.

---

## 8. Diagnosing rules

* The **Environment dump** section of `Game_bin\Arcadia-<date>.txt` prints every effective option → always read it first.
* Confirm the file timestamp is older than the crash timestamp before trusting any test.
* `EXEC xp_readerrorlog 0, 1, N'Login failed';` in SSMS shows the exact login name and reason the server used.
* Logs: `Game_bin\GameLog.txt`, `Game_bin\Log\`, `Auth_bin\Log\`.

---

## 9. Existing workspace artifacts

| File | Contents |
|---|---|
| `rappelz-guide-v2.html` | full install guide (HTML) |
| `rz-setup-checklist.docx` | printable install checklist |
| `rz-telecaster/restore_telecaster1.sql` | Telecaster1 restore script (already executed successfully) |
| `rz-level200/` | level 181–200 project + Rondo farm zone + Arabic guide |
| `rappelz-real-reference.xlsx` | DB table reference |
| `rz-opt/GameServer.opt.FIXED.txt` | clean copy of the opt above |
| `rz-server-handover-guide.docx` | this document as a formatted Arabic Word file |
