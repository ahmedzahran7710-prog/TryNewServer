/* ============================================================
   Rappelz 9.1 — استكشاف نظام GM / الصلاحيات
   شغّل هذا الملف كله مرة واحدة في SSMS (Windows Authentication)
   وابعت النتيجة (Results) كما هي.
   الملف للقراءة فقط — لا يعدّل أي شيء.
   ============================================================ */

------------------------------------------------------------------
-- 1) قواعد البيانات الموجودة
------------------------------------------------------------------
SELECT name AS [Database] FROM sys.databases ORDER BY name;
GO

------------------------------------------------------------------
-- 2) هل يوجد جدول AuthorityInfo أو AllowedCommandsForPermission؟
------------------------------------------------------------------
EXEC sp_MSforeachdb '
SELECT DB_NAME() AS [db], name AS [table]
FROM sys.tables
WHERE name IN (''AuthorityInfo'',''AllowedCommandsForPermission'',''AccountFlag'')
';
GO

------------------------------------------------------------------
-- 3) كل الأعمدة اللي اسمها يشبه الصلاحيات في كل القواعد
------------------------------------------------------------------
EXEC sp_MSforeachdb '
SELECT DB_NAME() AS [db], t.name AS [table], c.name AS [column], TYPE_NAME(c.system_type_id) AS [type]
FROM sys.tables t
JOIN sys.columns c ON c.object_id = t.object_id
WHERE c.name LIKE ''%authority%''
   OR c.name LIKE ''%permission%''
   OR c.name LIKE ''%gm%''
';
GO

------------------------------------------------------------------
-- 4) أعمدة جدول الشخصيات (عشان نعرف عمود الصلاحية)
------------------------------------------------------------------
SELECT c.name AS [Character column], TYPE_NAME(c.system_type_id) AS [type], c.is_nullable
FROM Telecaster1.sys.columns c
WHERE c.object_id = OBJECT_ID('Telecaster1.dbo.Character')
ORDER BY c.name;
GO

------------------------------------------------------------------
-- 5) محتوى جداول الصلاحيات (لو موجودة)
------------------------------------------------------------------
-- لو ظهر في الخطوة 2 إن الجدولين موجودين، شغّل الأوامر دي بعد ما تبدّل
-- اسم القاعدة لو مختلفة عن Telecaster1

-- SELECT TOP 100 * FROM Telecaster1.dbo.AllowedCommandsForPermission;
-- SELECT TOP 100 * FROM ArcadiaInfo.dbo.AuthorityInfo;
-- SELECT TOP 20 * FROM Telecaster1.dbo.Character WHERE authority <> 0;  -- لو العمود موجود

------------------------------------------------------------------
-- 6) الحسابات الحالية (للمراجعة الأمنية)
------------------------------------------------------------------
SELECT account_id, login_name, block, auth_ok, age, last_login_server_idx, result
FROM Auth.dbo.Accounts ORDER BY account_id;
GO
