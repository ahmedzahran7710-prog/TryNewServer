# 1_show_opt.ps1
# ------------------------------------------------------------------
#  بيقرأ ملفات الإعداد ويوريك السطور المهمة بس
#  قراءة فقط — مبيعدّلش أي ملف
#
#  تشغيل:  كليك يمين -> Run with PowerShell
# ------------------------------------------------------------------

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "   فحص ملفات الإعداد .opt" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

# ------------------------------------------------------------- 1) لاقي فولدر السيرفر
$candidates = @(
    "C:\RZ\Server\FilesOfficial-Revolution9.1",
    "C:\RZ\Server\GameEngine",
    "C:\RZ\Server"
)

$root = $null
foreach ($c in $candidates) {
    if ((Test-Path "$c\GameEngine") -or (Test-Path "$c\Auth_bin")) {
        $root = $c
        break
    }
}

# بحث أعمق لو مفيش نتيجة
if (-not $root -and (Test-Path "C:\RZ\Server")) {
    $found = Get-ChildItem "C:\RZ\Server" -Recurse -Filter "Game_bin" -Directory -ErrorAction SilentlyContinue |
             Select-Object -First 1
    if ($found) { $root = $found.Parent.FullName }
}

if (-not $root) {
    Write-Host "❌ مش لاقي فولدر السيرفر. عدّل المسار في أول السكربت." -ForegroundColor Red
    exit
}

Write-Host "فولدر السيرفر:" -ForegroundColor Green
Write-Host "  $root"
Write-Host ""

# ------------------------------------------------------------- 2) دوّر على ملفات .opt
$optFiles = Get-ChildItem $root -Recurse -Filter "*.opt" -File -ErrorAction SilentlyContinue

if ($optFiles.Count -eq 0) {
    Write-Host "❌ مفيش ملفات .opt في المسار ده" -ForegroundColor Red
    exit
}

Write-Host "الملفات اللي لقيتها:" -ForegroundColor Green
$optFiles | ForEach-Object {
    Write-Host ("  " + $_.FullName + "   (" + [math]::Round($_.Length/1KB,1) + " KB)")
}
Write-Host ""

# ------------------------------------------------------------- 3) اطبع السطور المهمة
$patterns = @(
    "db\.", "database", "password", "passwd", "account",
    "port", "ip_address", "ip:", "server", "auth",
    "billing", "max_level", "exp_rate", "drop_rate", "gold_rate",
    "md5"
)

foreach ($f in $optFiles) {

    Write-Host "==================================================" -ForegroundColor Yellow
    Write-Host ("  " + $f.Name) -ForegroundColor Yellow
    Write-Host ("  " + $f.FullName) -ForegroundColor DarkGray
    Write-Host "==================================================" -ForegroundColor Yellow

    $lines = Get-Content $f.FullName -ErrorAction SilentlyContinue

    # لو الملف مش نص عادي (مضغوط) هنقول كده
    if (-not $lines -or ($lines -join "").Length -eq 0) {
        Write-Host "  ⚠️ الملف مش مقروء كنص — ممكن يكون مضغوط (RappelzCompress)" -ForegroundColor Red
        continue
    }

    $n = 0
    foreach ($line in $lines) {
        $n++
        foreach ($p in $patterns) {
            if ($line -match $p) {
                Write-Host ("  {0,4}:  {1}" -f $n, $line.TrimEnd())
                break
            }
        }
    }

    Write-Host ""
}

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "  خلص. مفيش أي ملف اتعدّل." -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "ابعتلي الأسطر اللي فوق (صورة كفاية) وأنا أقولك تغيّر إيه." -ForegroundColor White
Write-Host ""
