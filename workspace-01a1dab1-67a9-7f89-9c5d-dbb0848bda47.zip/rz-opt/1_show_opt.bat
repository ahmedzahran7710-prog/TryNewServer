@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

title Rappelz .opt Inspector

echo.
echo ==================================================
echo    Rappelz .opt Inspector  (read only)
echo ==================================================
echo.

REM ---------------------------------------------------------------
REM  1) find the GameEngine folder
REM ---------------------------------------------------------------
set "ROOT="

for /d /r "C:\RZ\Server" %%D in (GameEngine) do (
    if not defined ROOT set "ROOT=%%D"
)

if not defined ROOT (
    echo [X] GameEngine folder not found under C:\RZ\Server
    echo     Edit the path in this .bat file and try again.
    echo.
    pause
    exit /b
)

echo Server root:
echo   %ROOT%
echo.

REM ---------------------------------------------------------------
REM  2) list every .opt file
REM ---------------------------------------------------------------
echo ==================================================
echo    Files found:
echo ==================================================
for /r "%ROOT%" %%F in (*.opt) do (
    echo   %%F
)
echo.

REM ---------------------------------------------------------------
REM  3) show the important lines
REM ---------------------------------------------------------------
for /r "%ROOT%" %%F in (*.opt) do (
    echo ==================================================
    echo   FILE: %%F
    echo ==================================================
    findstr /i /n "db. password passwd account port ip_address billing max_level exp_rate drop_rate gold_rate md5 auth" "%%F"
    if errorlevel 1 echo   [i] no matching lines found in this file
    echo.
)

echo ==================================================
echo    Done. No file was modified.
echo ==================================================
echo.
pause
