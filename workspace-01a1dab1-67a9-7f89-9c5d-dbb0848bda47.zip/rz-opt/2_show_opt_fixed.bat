@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

title Rappelz .opt Inspector v2

echo.
echo ==================================================
echo    Rappelz .opt Inspector v2  (read only)
echo ==================================================
echo.

REM ---------------------------------------------------------------
REM  1) every .opt under C:\RZ\Server
REM ---------------------------------------------------------------
set "COUNT=0"

echo Searching: C:\RZ\Server
echo.
echo ---- .opt files found --------------------------------------
for /r "C:\RZ\Server" %%F in (*.opt) do (
    echo   %%F
    set /a COUNT+=1
)
echo ------------------------------------------------------------
echo   total: !COUNT!
echo.

if !COUNT! EQU 0 (
    echo [X] No .opt files under C:\RZ\Server
    echo     Trying C:\RZ ...
    echo.
    for /r "C:\RZ" %%F in (*.opt) do (
        echo   %%F
        set /a COUNT+=1
    )
)

if !COUNT! EQU 0 (
    echo.
    echo [X] No .opt files anywhere under C:\RZ
    echo.
    echo ---- folder tree of C:\RZ\Server (2 levels) ---------------
    for /d %%D in ("C:\RZ\Server\*") do (
        echo   [DIR] %%D
        for /d %%E in ("%%D\*") do (
            echo         - %%E
        )
    )
    echo ------------------------------------------------------------
    echo.
    echo Send this output to get the right path.
    pause
    exit /b
)

REM ---------------------------------------------------------------
REM  2) show important lines from each
REM ---------------------------------------------------------------
for /r "C:\RZ\Server" %%F in (*.opt) do (
    echo ==========================================================
    echo   FILE: %%F
    echo ==========================================================
    findstr /i /n "db. password passwd account port ip_address billing max_level exp_rate drop_rate gold_rate md5 auth ip=" "%%F"
    if errorlevel 1 echo   [i] no matching lines
    echo.
)

echo ==========================================================
echo    Done. No file was modified.
echo ==========================================================
echo.
pause
