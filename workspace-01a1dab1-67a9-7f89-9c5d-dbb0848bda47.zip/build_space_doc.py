# -*- coding: utf-8 -*-
"""يبني ملف وورد عربي RTL كامل عن سيرفر Rappelz Space."""
import json
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

NAVY = RGBColor(0x1F, 0x38, 0x64)
BLUE = RGBColor(0x2E, 0x5C, 0x8A)
RED = RGBColor(0xC0, 0x00, 0x00)
GREEN = RGBColor(0x1E, 0x6B, 0x3A)
GREY = RGBColor(0x59, 0x59, 0x59)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

FONT = "Segoe UI"


# ----------------------------------------------------------------- utilities
def rtl_par(p, align=WD_ALIGN_PARAGRAPH.RIGHT):
    pPr = p._p.get_or_add_pPr()
    b = OxmlElement("w:bidi")
    pPr.append(b)
    p.alignment = align


def rtl_run(run):
    rPr = run._r.get_or_add_rPr()
    r = OxmlElement("w:rtl")
    rPr.append(r)
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:cs"), FONT)
    rFonts.set(qn("w:ascii"), FONT)
    rFonts.set(qn("w:hAnsi"), FONT)


def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear")
    sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), hexcolor)
    tcPr.append(sh)


def cell_margins(table, top=60, bottom=60, left=90, right=90):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("start", left), ("bottom", bottom), ("end", right)):
        e = OxmlElement("w:" + k)
        e.set(qn("w:w"), str(v))
        e.set(qn("w:type"), "dxa")
        mar.append(e)
    tblPr.append(mar)


def table_borders(table, color="BFCEDD", sz=6):
    tblPr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "start", "bottom", "end", "insideH", "insideV"):
        e = OxmlElement("w:" + edge)
        e.set(qn("w:val"), "single")
        e.set(qn("w:sz"), str(sz))
        e.set(qn("w:space"), "0")
        e.set(qn("w:color"), color)
        borders.append(e)
    tblPr.append(borders)


def bidi_table(table):
    tblPr = table._tbl.tblPr
    b = OxmlElement("w:bidiVisual")
    tblPr.append(b)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    e = OxmlElement("w:tblHeader")
    e.set(qn("w:val"), "true")
    trPr.append(e)


def no_split(row):
    trPr = row._tr.get_or_add_trPr()
    e = OxmlElement("w:cantSplit")
    e.set(qn("w:val"), "true")
    trPr.append(e)


# ------------------------------------------------------------------ writers
class Doc:
    def __init__(self):
        self.d = Document()
        st = self.d.styles["Normal"]
        st.font.name = FONT
        st.font.size = Pt(11)
        st.element.rPr.rFonts.set(qn("w:cs"), FONT)
        sec = self.d.sections[0]
        sec.page_width = Cm(21)
        sec.page_height = Cm(29.7)
        sec.left_margin = Cm(2.0)
        sec.right_margin = Cm(2.0)
        sec.top_margin = Cm(1.9)
        sec.bottom_margin = Cm(1.9)
        self._footer()

    def _footer(self):
        p = self.d.sections[0].footer.paragraphs[0]
        rtl_par(p, WD_ALIGN_PARAGRAPH.CENTER)
        r = p.add_run("سيرفر Rappelz Space — دليل كامل  •  صفحة ")
        r.font.size = Pt(8.5)
        r.font.color.rgb = GREY
        rtl_run(r)
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), "PAGE")
        run = OxmlElement("w:r")
        rPr = OxmlElement("w:rPr")
        sz = OxmlElement("w:sz")
        sz.set(qn("w:val"), "17")
        rPr.append(sz)
        run.append(rPr)
        fld.append(run)
        p._p.append(fld)

    # -- text
    def p(self, text, size=11, bold=False, color=None, align=WD_ALIGN_PARAGRAPH.JUSTIFY,
          space_after=6, space_before=0, italic=False, indent=0):
        par = self.d.add_paragraph()
        rtl_par(par, align)
        pf = par.paragraph_format
        pf.space_after = Pt(space_after)
        pf.space_before = Pt(space_before)
        pf.line_spacing = 1.28
        if indent:
            pf.right_indent = Cm(indent)
        r = par.add_run(text)
        r.font.size = Pt(size)
        r.bold = bold
        r.italic = italic
        if color is not None:
            r.font.color.rgb = color
        rtl_run(r)
        return par

    def rich(self, parts, size=11, align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_after=6):
        """parts = [(text, bold, color|None), ...]"""
        par = self.d.add_paragraph()
        rtl_par(par, align)
        par.paragraph_format.space_after = Pt(space_after)
        par.paragraph_format.line_spacing = 1.28
        for text, bold, color in parts:
            r = par.add_run(text)
            r.font.size = Pt(size)
            r.bold = bold
            if color is not None:
                r.font.color.rgb = color
            rtl_run(r)
        return par

    def h1(self, num, text):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT)
        pf = par.paragraph_format
        pf.space_before = Pt(16)
        pf.space_after = Pt(8)
        pf.keep_with_next = True
        pPr = par._p.get_or_add_pPr()
        pbdr = OxmlElement("w:pBdr")
        bot = OxmlElement("w:bottom")
        bot.set(qn("w:val"), "single")
        bot.set(qn("w:sz"), "18")
        bot.set(qn("w:space"), "6")
        bot.set(qn("w:color"), "1F3864")
        pbdr.append(bot)
        pPr.append(pbdr)
        r = par.add_run(f"{num}. {text}")
        r.font.size = Pt(17)
        r.bold = True
        r.font.color.rgb = NAVY
        rtl_run(r)

    def h2(self, text, color=BLUE):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT)
        pf = par.paragraph_format
        pf.space_before = Pt(11)
        pf.space_after = Pt(4)
        pf.keep_with_next = True
        r = par.add_run(text)
        r.font.size = Pt(13.5)
        r.bold = True
        r.font.color.rgb = color
        rtl_run(r)

    def h3(self, text):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.RIGHT)
        pf = par.paragraph_format
        pf.space_before = Pt(8)
        pf.space_after = Pt(3)
        pf.keep_with_next = True
        r = par.add_run("▪ " + text)
        r.font.size = Pt(11.5)
        r.bold = True
        r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
        rtl_run(r)

    def bullet(self, text, size=11, indent=0.5):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.JUSTIFY)
        pf = par.paragraph_format
        pf.right_indent = Cm(indent + 0.4)
        pf.space_after = Pt(2.5)
        pf.line_spacing = 1.24
        r = par.add_run("•  " + text)
        r.font.size = Pt(size)
        rtl_run(r)

    def num(self, i, text, size=11):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.JUSTIFY)
        pf = par.paragraph_format
        pf.right_indent = Cm(0.9)
        pf.space_after = Pt(3)
        pf.line_spacing = 1.24
        r = par.add_run(f"{i})  ")
        r.bold = True
        r.font.size = Pt(size)
        r.font.color.rgb = NAVY
        rtl_run(r)
        r2 = par.add_run(text)
        r2.font.size = Pt(size)
        rtl_run(r2)

    def code(self, text):
        par = self.d.add_paragraph()
        rtl_par(par, WD_ALIGN_PARAGRAPH.LEFT)
        pf = par.paragraph_format
        pf.space_before = Pt(3)
        pf.space_after = Pt(7)
        pf.left_indent = Cm(0.6)
        pf.right_indent = Cm(0.6)
        pPr = par._p.get_or_add_pPr()
        sh = OxmlElement("w:shd")
        sh.set(qn("w:val"), "clear")
        sh.set(qn("w:color"), "auto")
        sh.set(qn("w:fill"), "F2F2F2")
        pPr.append(sh)
        r = par.add_run(text)
        r.font.name = "Consolas"
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(0x0A, 0x2E, 0x4F)
        return par

    def callout(self, title, body, fill="EAF1F8", bar="2E5C8A", title_color=NAVY):
        t = self.d.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        bidi_table(t)
        cell = t.cell(0, 0)
        shade(cell, fill)
        cell_margins(t, 90, 90, 130, 130)
        table_borders(t, bar, 4)
        cell.paragraphs[0]._p.getparent().remove(cell.paragraphs[0]._p)
        p1 = cell.add_paragraph()
        rtl_par(p1, WD_ALIGN_PARAGRAPH.RIGHT)
        p1.paragraph_format.space_after = Pt(2)
        r = p1.add_run(title)
        r.bold = True
        r.font.size = Pt(11)
        r.font.color.rgb = title_color
        rtl_run(r)
        p2 = cell.add_paragraph()
        rtl_par(p2, WD_ALIGN_PARAGRAPH.JUSTIFY)
        p2.paragraph_format.line_spacing = 1.26
        r2 = p2.add_run(body)
        r2.font.size = Pt(10.5)
        rtl_run(r2)
        self.p("", space_after=3)

    def verdict(self, level):
        """level in easy/med/hard/vhard/impossible"""
        return {
            "easy": ("سهل", "C6EFCE", "1E6B3A"),
            "med": ("متوسط", "FFF2CC", "7F6000"),
            "hard": ("صعب", "FCE4D6", "974706"),
            "vhard": ("صعب جداً", "FFC7CE", "9C0006"),
            "no": ("مستحيل عملياً", "D9D9D9", "404040"),
        }[level]

    def table(self, headers, rows, widths=None, vcol=None, size=9.5, head_fill="1F3864"):
        t = self.d.add_table(rows=1, cols=len(headers))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        bidi_table(t)
        table_borders(t)
        cell_margins(t, 50, 50, 80, 80)
        hdr = t.rows[0]
        repeat_header(hdr)
        for i, h in enumerate(headers):
            c = hdr.cells[i]
            shade(c, head_fill)
            c.paragraphs[0]._p.getparent().remove(c.paragraphs[0]._p)
            p = c.add_paragraph()
            rtl_par(p, WD_ALIGN_PARAGRAPH.CENTER)
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(h)
            r.bold = True
            r.font.size = Pt(size)
            r.font.color.rgb = WHITE
            rtl_run(r)
        for ri, row in enumerate(rows):
            cells = t.add_row().cells
            no_split(t.rows[-1])
            for ci, val in enumerate(row):
                c = cells[ci]
                if ri % 2 == 1:
                    shade(c, "F4F8FC")
                c.paragraphs[0]._p.getparent().remove(c.paragraphs[0]._p)
                p = c.add_paragraph()
                rtl_par(p, WD_ALIGN_PARAGRAPH.RIGHT)
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.15
                if vcol is not None and ci == vcol and val in (
                        "easy", "med", "hard", "vhard", "no"):
                    label, fill, col = self.verdict(val)
                    shade(c, fill)
                    r = p.add_run(label)
                    r.bold = True
                    r.font.size = Pt(size)
                    r.font.color.rgb = RGBColor.from_string(col)
                    rtl_run(r)
                else:
                    r = p.add_run(str(val))
                    r.font.size = Pt(size)
                    rtl_run(r)
        if widths:
            for i, w in enumerate(widths):
                for row in t.rows:
                    row.cells[i].width = Cm(w)
        self.p("", space_after=4)
        return t

    def pagebreak(self):
        par = self.d.add_paragraph()
        par.add_run().add_break(WD_BREAK.PAGE)

    def spacer(self, pt=6):
        self.p("", space_after=pt)

    def save(self, path):
        self.d.save(path)


# =============================================================== CONTENT
D = Doc()

# ---------------------------------------------------------------- cover
for _ in range(3):
    D.p("", space_after=10)

t = D.d.add_table(rows=1, cols=1)
bidi_table(t)
c = t.cell(0, 0)
shade(c, "1F3864")
c.paragraphs[0]._p.getparent().remove(c.paragraphs[0]._p)
p = c.add_paragraph()
rtl_par(p, WD_ALIGN_PARAGRAPH.CENTER)
p.paragraph_format.space_before = Pt(18)
p.paragraph_format.space_after = Pt(6)
r = p.add_run("سيرفر Rappelz Space")
r.bold = True
r.font.size = Pt(34)
r.font.color.rgb = WHITE
rtl_run(r)

p2 = c.add_paragraph()
rtl_par(p2, WD_ALIGN_PARAGRAPH.CENTER)
p2.paragraph_format.space_after = Pt(4)
r2 = p2.add_run("كل التفاصيل — بشرح مبسّط ومفهوم")
r2.font.size = Pt(17)
r2.font.color.rgb = RGBColor(0xDC, 0xE6, 0xF1)
rtl_run(r2)

p3 = c.add_paragraph()
rtl_par(p3, WD_ALIGN_PARAGRAPH.CENTER)
p3.paragraph_format.space_after = Pt(18)
r3 = p3.add_run("الأنظمة • المناطق • الأرقام الحقيقية • وإزاي اتعملت فعلياً")
r3.font.size = Pt(12)
r3.font.color.rgb = RGBColor(0xBF, 0xD3, 0xE8)
rtl_run(r3)

D.spacer(30)
D.p("دليل مُجمَّع من فحص صفحات السيرفر الرسمية + السجل الكامل للتحديثات (Patch Notes) + ملفات سيرفر 9.1 اللي عندك، "
    "عشان تعرف مش بس «إيه اللي موجود» — لكن كمان «إزاي اتعمل» و«تقدر تعمله ولا لأ».",
    align=WD_ALIGN_PARAGRAPH.CENTER, color=GREY, size=10.5)
D.spacer(24)
D.p("آخر تحديث للملف: نوفمبر 2026", align=WD_ALIGN_PARAGRAPH.CENTER, color=GREY, size=9.5)
D.spacer(4)
D.p("ملف شخصي — للاستخدام الداخلي", align=WD_ALIGN_PARAGRAPH.CENTER, color=GREY, size=9.5)

D.pagebreak()

# ---------------------------------------------------------------- toc
D.h1("٠", "الملف ده فيه إيه؟ وإزاي تستخدمه")
D.p("الملف مقسوم ١٥ فصل. أول ٩ فصول بيشرحوا السيرفر نفسه: نظام اللفل، مناطق التجميع، الأنظمة الكبيرة، "
    "الموسمية، الكلاسات. الفصول من ١٠ لـ ١٣ هي الجزء المهم بالنسبالك: «إزاي اتعملت تقنياً» و«تقدر تعملها ولا لأ»، "
    "وفي الآخر خطة عملية على سيرفرك ٩.١ والملاحق.")
D.p("مش لازم تقرأه بالترتيب. لو مستعجل: اقرأ الفصل ١١ (الحكم الصريح) والفصل ١٣ (خطتك).")

rows = [
    ["١", "قبل ما تبدأ + قاموس المصطلحات", "تفهم كل كلمة قبل أي حاجة"],
    ["٢", "بطاقة السيرفر", "هو مين، إصداره، رايتسه، لغته"],
    ["٣", "حكاية اللفل ١٨٠ ← ٢٠٠", "الرقم اللي كان مستحيل وبقى عادي"],
    ["٤", "خريطة مناطق التجميع", "كل منطقة ولفلها وشرط دخولها"],
    ["٥", "السيرفرات الموسمية", "أهم فكرة في السيرفر كله"],
    ["٦–٨", "الأنظمة الكبيرة + الرفاهية", "Tower / Lab / Guild Zone / Crucible / QoL"],
    ["٩", "الكلاسات والأسلحة الجديدة", "٤ كلاسات + سلاحين"],
    ["١٠", "السر التقني", "كل نظام ← فين مكانه بالظبط في الملفات"],
    ["١١", "الحكم الصريح", "سهل / متوسط / صعب / مستحيل"],
    ["١٢", "الحقيقة عن الفريق", "هما عملوها بإيدهم فعلاً؟"],
    ["١٣", "خطتك على ٩.١", "خطوة بخطوة من بكرة"],
    ["١٤–١٥", "الملاحق", "٨٦ جدول Resource + المصادر"],
]
D.table(["#", "الفصل", "هيوصلك إيه"], rows, widths=[1.3, 6.4, 8.6], size=9.5)

D.h2("قاموس المصطلحات — اقرأه مرة واحدة وخلاص")
gloss = [
    ["Resource / جدول", "ملف أو جدول في الداتابيز فيه بيانات اللعبة (أدوات، مونسترز، دروب، لفل). كل «نظام» في اللعبة مبني على جدول."],
    ["RDU", "صيغة ملفات السيرفر اللي بتشيل الجداول (زي ItemResource.rdu). مش ملف مضغوط — صيغة خاصة، بتتقرأ بأدوات زي Grimoire."],
    ["Lua", "لغة السكربتات اللي السيرفر بيستخدمها عشان يشغّل «سلوك» — يعني NPC بيقولك إيه، دانجن بيفتح إمتى، مونستر بيطلع فين."],
    ["Instance Dungeon", "دانجن «نسخة خاصة» — كل فريق بيدخل نسخة لوحده من نفس الخريطة، مش بيتلاقوا مع حد تاني."],
    ["Spawn / Respawn", "ظهور المونستر. الـRespawn = إعادة ظهوره بعد ما يموت."],
    ["Drop Group", "جدول الدروب: كل مونستر مرتبط بمجموعة دروب، والمجموعة فيها احتمالات."],
    ["Level Cap", "أقصى لفل ممكن توصله في السيرفر. الرسمي ١٧٥/١٨٠، سبيس وصّلوه ٢٠٠."],
    ["Patch Notes / باتش نوت", "سجل التغييرات اللي السيرفر بينشرها كل تحديث. ده أهم مصدر لمعرفة «إيه اللي اتعمل»."],
    ["QoL", "اختصار Quality of Life = تحسينات رفاهية مش محتوى جديد (زي المتجر أوفلاين أو بوت تليجرام)."],
]
D.table(["المصطلح", "معناه ببساطة"], gloss, widths=[3.6, 13.0], size=9.5)

D.callout("نصيحة قبل ما تكمّل",
          "أي رقم في الملف ده جاي من مصدر حقيقي (صفحة السيرفر أو باتش نوت أو ملفاتك). "
          "ولو حاجة تغيّرت بعد آخر تحديث — الرقم بيفضل صح كـ«مثال حقيقي» بس مش شرط يكون الحالي. "
          "الفكرة إنك تفهم النمط، مش تحفظ الرقم.")

D.pagebreak()

# ---------------------------------------------------------------- ch 2
D.h1("١", "بطاقة السيرفر — هو مين؟")
D.p("Rappelz Space سيرفر خاص (Private Server) روسي، بدأ على إصدار Epic 7.4 وطلع بالتدريج لحد 9.5.2 + 9.6. "
    "معناه إنه مش سيرفر «نسخة طبق الأصل» — ده سيرفر اتبنى عليه محتوى من صنع الفريق نفسه.")
rows = [
    ["الاسم", "Rappelz Space  (الموقع: rappelz.space)"],
    ["الإصدار", "بدأ 7.4  ←  دلوقتي 9.5.2 + 9.6"],
    ["الرايتس", "بتتغير من موسم لموسم (شوفنا x15 خبرة / x40 دروب، وفترة x60، وفي قوايم x150/x150). الرقم مش ثابت."],
    ["اللغة", "الإنجليزية فقط في الشات (قرار إداري عشان يمنع تقسيم اللاعبين)"],
    ["أقصى لفل", "١٨٠ ← ٢٠٠ (وبتس من ١٨٠ ← ٢٠٠ ← ٢١٠)"],
    ["أسلوب التطوير", "باتش نوتس مُرقّمة (Patchnote 3.0 → 8.0 …) + سيرفرات موسمية كل فترة"],
    ["الفلسفة", "إعادة استخدام محتوى اللعبة الأصلي + أنظمة جديدة فوقه، مش خريطة من الصفر"],
]
D.table(["البند", "التفصيل"], rows, widths=[3.4, 13.2], size=9.5)

D.h2("طب إيه اللي بيميّزه عن أي سيرفر خاص تاني؟")
D.p("تلات حاجات بس:")
D.num(1, "إنه مدّد اللفل لـ٢٠٠ — ومعاها بنى محتوى كامل للفترة ١٨٠–٢٢٠ (مناطق تجميع + دانجنات + برج).")
D.num(2, "إنه عمل «أنظمة» مش مجرد «محتوى» — نظام جيلد زون بمستويات، برج ١٠٠ دور، دانجن بجينومات.")
D.num(3, "إنه بيعمل سيرفرات موسمية (Seasons) كل فترة — ودي أذكى حاجة عملها، وهنشرحها في الفصل ٤.")

D.pagebreak()

# ---------------------------------------------------------------- ch 3
D.h1("٢", "حكاية اللفل: من ١٨٠ لـ ٢٠٠")
D.p("في اللعبة الأصلية، أقصى لفل كان بيتقفل عند رقم معين (١٦٠ ثم ١٧٠ ثم ١٨٠ في الإصدارات المختلفة). "
    "الرقم ده مش «جدار تقني» — هو مجرد رقمين: واحد في السيرفر وواحد في الكلاينت.")
D.h2("فكرة الرفع — ببساطة شديدة")
D.p("عشان تخلّي اللاعب يوصل ٢٠٠ بدل ١٨٠، محتاج تلات حاجات بس:")
D.num(1, "جدول الخبرة (LevelResource) يكون فيه صفوف للفلات ١٨١ إلى ٢٠٠، وكل صف فيه: كام خبرة محتاجة، وكام HP/MP هيزيد، وكام نقطة تتوزع.")
D.num(2, "ملف إعدادات السيرفر (.opt) يكون فيه max_level = 200 بدل 180.")
D.num(3, "الكلاينت يعرف يعرض الفل ده — مش يقطع الشريط عند ١٨٠ أو يرفض الأرقام.")
D.callout("في ملفاتك بالظبط",
          "ملف السيرفر ٩.١ اللي عندك فيه max_level = 180 في إعدادات .opt، "
          "وجدول LevelResource موجود جوه Arcadia.bak. يعني الخطوة الأولى عندك جاهزة — محتاج بس تعرف صفوف ١٨١–٢٠٠.",
          fill="FFF2CC", bar="BF9000", title_color=RGBColor(0x7F, 0x60, 0x00))

D.h2("واللي بيتبعه عادةً")
D.bullet("لفل البتس (Creatures): سبيس رفعوه ١٨٠ ← ٢٠٠ ← ٢١٠ — نفس الفكرة بس في جدول Creature/Pet.")
D.bullet("محتوى للفترة الجديدة: لو رفعت اللفل ومفيش مونسترز مناسبة، اللاعب هيفضل يضرب في مونسترز لفلها ١٥٠ ويكسب صفر. عشان كده أي سيرفر بيرفع اللفل، لازم يعمل «مناطق تجميع» — وده الفصل الجاي.")

D.pagebreak()

# ---------------------------------------------------------------- ch 4
D.h1("٣", "خريطة مناطق التجميع — الرقم الحقيقي")
D.p("دي أهم صفحة في الملف. كل الأرقام دي من صفحات السيرفر وباتش نوتاتهم. "
    "«منطقة تجميع» = منطقة مونسترزها كثيفة ولفلها مناسب، عشان تلفل فيها بسرعة بدون دانجن.")
rows = [
    ["Salt Mines", "١٦١ – ١٦٩", "بدون PK", "منطقة تجميع آمنة — تتفرج على فيلم وإنت بتلفل"],
    ["Devildom", "١٧٥+", "بدون شروط غير اللفل", "دانجن الشيطان — أول دانجن «جدي»"],
    ["Crystal Mountain Gate (Rondo)", "١٨٠ – ٢٠٠", "للاعبين تحت ٢٠٠ بس", "★ منطقة التجميع الشهيرة بتاعتهم — المونسترز اتغيّروا مخصوص للتجميع"],
    ["Harvesting Woods / Harvest Forest", "١٩٥ – ٢١٤", "مفتوحة", "للفترة اللي بعد ٢٠٠"],
    ["Fairy Forest", "٢١٠ – ٢٢٠", "مفتوحة", "للفل العالي جداً (بعد ما البتس واللفل اتفتحوا)"],
    ["Dark Laboratory (١)", "٢٠٠+", "دانجن", "أول دور معملي"],
    ["Dark Laboratory (٢)", "٢٠٥+", "دانجن", "أصعب، وعقوبة موت إضافية"],
    ["Dark Laboratory (٣)", "٢١٠+", "دانجن", "أصعب دور — عقوبتين + منع هجوم"],
    ["Endless Tower", "١٥٠+", "مرة واحدة في اليوم لكل شخصية", "١٠٠ دور، والمونسترز بتتكيّف مع لفلك"],
]
D.table(["المنطقة", "اللفل", "شرط/ملاحظة", "ليه مهمة"],
        rows, widths=[4.2, 2.3, 3.6, 6.5], size=9)

D.h2("الحاجة اللي لازم تدركها")
D.p("كل المناطق دي — ما عدا المعمل والبرج — مش خرائط جديدة. دي خرائط موجودة في اللعبة من زمان "
    "(Rondo، الغابات، المناجم) واتعملها حاجتين بس:")
D.bullet("تغيير أرقام المونسترز (لفل، HP، خبرة) في جدول MonsterResource + جداول الخبرة.")
D.bullet("زيادة كثافة الظهور (كم مونستر بيطلع في نفس المكان) وضبط الدروب.")
D.p("يعني بالعربي: «منطقة تجميع ١٨٠–٢٠٠» مش مشروع برمجة — دي نصف يوم شغل على جداول، "
    "لو فاهم إن الخريطة نفسها موجودة والاسم موجود. وده اللي هنعمله في الفصل ١٣.")

D.pagebreak()

# ---------------------------------------------------------------- ch 5
D.h1("٤", "السيرفرات الموسمية (Seasons) — أذكى فكرة عندهم")
D.p("ده مش نظام في اللعبة — ده نظام إدارة سيرفر. الفكرة: كل فترة بيفتحوا سيرفر جديد اسمه «[Season N] Space» "
    "بيقفل بعد مدة، وأحسن اللاعبين والجيلدز بياخدوا جوائز تتحول لحساباتهم في السيرفر الأساسي.")
D.h2("إزاي الموسم شغال؟")
D.num(1, "السيرفر الموسمي بيفتح كل فترة (شافنا Season 1 لحد Season 5 على الأقل).")
D.num(2, "فيه قيود مخصوصة: حد أعضاء الجيلد ٢٠ لاعب، والتحالفات (Alliances) مقفولة — عشان مايبقاش فيه جيلد واحد مسيطر.")
D.num(3, "المحتوى الكبير (البرج) بيفتح بالتدريج: الشهر الأول مقفول، التاني لحد الدور ٧٠، التالت لحد الدور ١٠٠. "
      "السبب: مايخلصوش المحتوى في أسبوع.")
D.num(4, "في نهاية الموسم: ترتيب الشخصيات وترتيب الجيلدز بياخدوا تليتلات وجوائز. الجيلد اللي واخد مركز بياخد Crucible Souls "
      "ينقلها للسيرفر الأساسي عشان يفتح جيلد زون.")
D.h2("ليه الفكرة دي قوية؟")
D.p("لأنها بتحل أكبر مشكلة في أي سيرفر خاص: إن بعد ٦ شهور اللاعبين الجدد مش هيلاقوا مكان. "
    "الموسم بيدي الجميع بداية متساوية، والسيرفر الأساسي بيفضل فيه القدامى يلعبوا PvP. "
    "وكمان الرايتس بتتغير من موسم لموسم (ودي حاجة مقصودة عشان يجرّبوا توازن جديد).")
D.callout("معلومة مهمة بالمناسبة",
          "الرايتس اللي بتشوفها على مواقع القوايم (x150/x150 مثلاً) بتبقى غالباً من موسم معين، "
          "مش رقم ثابت للسيرفر. عشان كده أي سؤال «كام إكسب سيرفر سبيس؟» — الجواب الصحيح: "
          "«حسب الموسم، وبيتغير».")

D.pagebreak()

# ---------------------------------------------------------------- ch 6
D.h1("٥", "نظام ١ — Endless Tower (البرج اللانهائي)")
D.p("ده أكبر نظام عندهم، وأشهر حاجة في السيرفر. باختصار: ١٠٠ دور، بتلعبه لوحدك (Solo)، "
    "وكل مونستر وبوس جواه «بيتكيّف» مع لفلك — يعني البرج صالح مهما كان لفلك.")

D.h2("القواعد الحقيقية")
rows = [
    ["الدخول", "لازم تتكلم مع Gatekeeper البرج (موجود في القرية المخفية). متاح من لفل ١٥٠+، مرة واحدة في اليوم لكل شخصية."],
    ["عدد الأدوار", "١٠٠ دور."],
    ["مقياس القوة", "كل المونسترز والبوسات بيتظبطوا على لفل الشخصية اللي داخلة. مش ثابتين."],
    ["نظام الـCheckpoint", "تقدر تخرج من أي دور، وترجع تكمل بعدين من نفس المكان — من غير ما تعيد من الأول."],
    ["عقوبة الخروج", "لو خرجت قبل ما تخلّص مهمة الدور، بتاخد عقوبة على الدروب اللي جبته من الدور ده بس. مش على كل البرج."],
    ["البوسات", "كل ٥ أدوار فيه بوس «جزء من البرج». وفي أدوار بوسات ممكن تظهر أوضة سرية — محتاج تلاقي مدخلها."],
    ["شرط التقدم", "الدور ما بيتفتحش غير لما تخلص كل مونسترز الدور اللي قبله."],
]
D.table(["البند", "التفصيل"], rows, widths=[3.2, 13.4], size=9.5)

D.h2("الجوايز — دي اللي بتخلي الناس تعلّي")
D.p("البرج مش بيدي أدوات عادية. بيدي «مواد» بتتحوّل أدوات. وفي كل نطاق أدوار فيه جوايز مخصوصة:")
rows = [
    ["١ – ٣٥", "Rune skill card box • Sign of Forgotten Gods • Awakening Stone: Accessories • Power of Change: Artifact • Black Crystal Box • Black Scale Piece • Power of Change: Armor • Devil Orb Piece"],
    ["٧٦ – ٨٠", "Dark Cube • Sand Dragon's Cloak of Devildom (+0 و +10، مدة ٢٤ ساعة)"],
    ["٩٠ (بوس)", "Purple Cube • Boss Card: Dark Priest Margar"],
    ["٩١ – ٩٥", "Subject Tag • Black Piece of Fabric • Subject's Blood • Subject's Tears • Laboratory Permit • Box of Lab Stones (Change Laboratory: Armor)"],
    ["٩٤ (بوس)", "Green Cube • Boss Card: Dark Laboratory Assistant"],
    ["٩٥ (بوس)", "Purple Cube • Boss Card: Sniper Triss"],
    ["٩٦ – ١٠٠", "Token Irbis"],
    ["١٠٠ (بوس)", "Irbis Amulet: Wings"],
]
D.table(["نطاق الأدوار", "الجوايز المحتملة"], rows, widths=[3.2, 13.4], size=9)

D.h2("اللي جوه البرج: Lord Tanuki")
D.p("جوه البرج هتلاقي حارسه القديم، Lord Tanuki. مش مجرد NPC كلام: عنده خدمتين مهمين:")
D.bullet("بيطوّر لك معداتك بالمواد اللي بتجمعها من البرج.")
D.bullet("بيعمل لك «كوليكشن» خاص بالبرج (مجموعة أدوات مشتركة بين الشخصيات — Bound).")
D.h2("والتليتلات")
D.p("في شروط معينة لو عملتها في البرج، بتاخد تليتل «خاص». وشروط الحصول عليها مش مكتوبة — لازم تلفل البرج وتعرفها بالتجربة. "
    "وفي باتش ٨.٠ صلّحوا مشكلة إن تليتلات البرج ما كانتش بتدي Weight (وزن) — وبعدين زوّدوا +١٠٠٠٠ أقصى وزن لكوليكشن البرج.")
D.callout("ليه البرج ذكي؟",
          "لأنه حل مشكلة «فرق اللفلات» بحل واحد: بدل ما يعملوا ٥ دانجنات لكل فترة لفل، عملوا دانجن واحد بيتظبط على لفلك. "
          "المحتوى واحد، بس التجربة مختلفة لكل لاعب. ده توفير هائل في الشغل — ودي فكرة تقدر تنقلها لأي سيرفر.")

D.pagebreak()

# ---------------------------------------------------------------- ch 7
D.h1("٦", "نظام ٢ — Dark Laboratory (المعمل المظلم)")
D.p("دانجن من ٣ أدوار (وأعلنوا عن دور رابع مستقبلاً)، وكل دور أعقد من اللي قبله. الدخول من القرية المخفية.")

rows = [
    ["الدور الأول", "٢٠٠+", "مونسترز أقوى من Devildom بكتير", "عند Lab Keeper (Blinmos) تقدر «تشيل حدود جسمك» وتعمل Genome يسمحلك تستخدم واحد من ١٦ Mutagen. جواه هتلاقي Laborer Dikre."],
    ["الدور التاني", "٢٠٥+", "سحر ملعون", "كل موتة تكلفك Bottle إضافي (God Mother Fairy's Bottle). هتلاقي Laborer Ord اللي نجا من الجنون."],
    ["الدور التالت", "٢١٠+", "أصعب دور", "كل موتة = ٢ بوتل إضافيين. وكل الكريتشرز عندها Debuff بيمنع استخدام الهجمات والسكلز — وممنوع تحاول تشيله (عقوبة إدارية)."],
]
D.table(["الدور", "الدخول", "الطبيعة", "التفاصيل"],
        rows, widths=[2.4, 1.8, 3.0, 9.4], size=9)

D.h2("الـGenomes والـMutagens — دي إيه بالظبط؟")
D.p("ده أخطر نظام عندهم، ومحتاج تفهمه صح:")
D.bullet("الـGenome = «تعديل» بتعمله لجسم الشخصية عند NPC (Blinmos). زي شريحة بتتركب فيك.")
D.bullet("الـMutagen = القدرة اللي بتفتحها بعد ما تركب الـGenome. كل Genome بيفتح واحد من مجموعة Mutagens (١٦ في الدور الأول، ووصلوا ٢٦).")
D.bullet("في باتش ٦.٠ ضافوا Genomes جديدة لتحكم في الـAggro: «Genome: Aggression» بتعمل Hate Aura (كولداون ١٠ ثواني، متاح لكل الكلاسات)، "
      "و«Genome: Peace» بتعمل Distortion of Rage (للتيمبلار بس).")
D.p("بالعربي المبسّط: Genome = مفتاح، Mutagen = باب. المفتاح بيتعمل عند NPC، والباب بيدي قدرة.")
D.callout("أهمية الفكرة",
          "ده مش «أدوات بتزيد ستات». ده نظام بيلزمك تختار وتلتزم: Genome واحد في الوقت ده، وله كولداون مشترك. "
          "عشان كده هو نظام «بناء شخصية» (Build) وليس مجرد إكسسوار.")

D.h2("اللي في المعمل غير كده")
D.bullet("مونسترز وبوسات بأسماء وقصص: Dark Priest Margar • Sniper Triss • Dark Laboratory Assistant • Devourer.")
D.bullet("كوليكشنز خاصة بكل بوس (Collection) — بتجمع منها قطع عشان تفتح حاجات.")
D.bullet("مواد المعمل: Laboratory Permit • Box of Lab Stones (تغيير المعمل: دروع) — ودي بتتحول أدوات.")
D.bullet("سكلات بتقع من المعمل: Change: Laboratory (Void Mage) و Change: Laboratory (Deadeye) — وبعدين غيّروها في باتش.")
D.bullet("بوسات بساعات ظهور محددة: بعضهم له «مدة حياة» ١٢٠ دقيقة — لو محدش قتلهم بيمشوا ومش بيتحسبوا في الـWorld Quest.")

D.pagebreak()

# ---------------------------------------------------------------- ch 8
D.h1("٧", "نظام ٣ — Guild Zone (منطقة الجيلد)")
D.p("دي أطمح نظام في السيرفر: الجيلد بيبني منطقته الخاصة، بترقى من لفل ٠ لـ ١٠، وكل لفل بيفتح حاجات. "
    "مش مجرد «بيت للجيلد» — دي مدينة صغيرة بمصانع وNPCs.")

D.h2("بتفتحها إزاي؟")
D.p("مش بالفلوس. لازم الجيلد يشارك في إيفنت اسمه **Crucible**، ويجمع عملة اسمها **Crucible Souls**، وبعدين يصرفها على ترقية المنطقة. "
    "الترقية يقدر يعملها **قائد الجيلد أو نائبه بس**.")
rows = [
    ["٠ – ١", "١٠٠٠ ← ١٢٥٠ روح", "مهام يومية (٤ مهام، جايزة كل مهمة ×٧ Crystal Ore) + شراء من NPC"],
    ["٢ – ٥", "١٥٠٠ ← ٢٠٠٠", "تفتيح NPCs ومصانع، ولفل البتس عند NPC Breeder"],
    ["٥", "≈٢٢٥٠", "NPC «Master of Summon Monsters» بيستدعي ٥٠ مونستر من الدور الأول للمعمل — بس ستاتهم ودروبهم ÷٥. كولداون ٢٤ ساعة"],
    ["٦", "≈٢٥٠٠", "استدعاء بوسات: Devourer (كولداون ٣٦ ساعة، ٣٠٠٬٠٠٠ لاك) • Dark Laboratory Assistant (٤٨ ساعة، ٣٥٠٬٠٠٠ لاك)"],
    ["٧", "≈٢٧٥٠", "استدعاء ٥٠ مونستر من الدور التاني للمعمل (÷٥ ستات ودروب)"],
    ["٨ – ٩", "٣٠٠٠ ← ٣٢٥٠", "توسعات: معمل الطفل، تطوير القلادات، إيجار البافات، تصنيع Soul Stones"],
    ["١٠", "٣٥٠٠", "استدعاء بوس البرج (كولداون ١٦٨ ساعة، ٥٥٠٬٠٠٠ لاك) + نظام حساب الخبرة"],
]
D.table(["مستوى الجيلد", "التكلفة (Souls)", "اللي بيتفتح"],
        rows, widths=[2.6, 3.4, 10.6], size=9)

D.h2("اللي جوه المنطقة فعلياً")
D.bullet("مهام يومية (٤ مهام) ومواد تصنيع للفل ٣٠.")
D.bullet("مصانع: تصنيع Soul Catalysts للبتس [Epic] بنسبة ١٠٠٪، وتصنيع Soul Stones، وتطوير القلادات.")
D.bullet("NPC Breeder بيرفع لفل البتس — وبيدي نسبة أعلى لمورال البتس.")
D.bullet("باف للشخصية والبتس (World Buff) — وفي باتش ٧.٠ بقى ينفع يتطبق حتى لو مش موجود، وللبتس كمان، بـ٥٠ ألف لاك.")
D.bullet("استدعاء وحوش وبوسات قوية، وأحداث جيلد، وإمكانية تنزيل بتس Epic وتهجينه.")
D.bullet("تيليبورت لمناطق خاصة جوه المنطقة.")
D.p("ملاحظة أمنية مهمة: في باتش ٧.٠ ضافوا «تحديد صلاحيات الدخول للمنطقة» — يعني قائد الجيلد يقدر يحدد مين يدخل. "
    "وطبعاً كل ده لازم يتعمله استدعاء عند NPC داخل Crucible.")

D.h2("Crucible — الإيفنت اللي بيغذي المنطقة")
rows = [
    ["الشكل", "١٠٠ Wave، الفريق بيدخل بترتيب، وتقدر تخرج قبل ما تخلص بس بتاخد عقوبة"],
    ["عدد المحاولات", "٧ محاولات في الأسبوع لكل جيلد (محاولة واحدة في اليوم)"],
    ["الدخل", "١ Crucible Soul لكل Wave من ٩١ لـ١٠٠"],
    ["عقوبة الدخول/الخروج", "اتقللت لـ١٠ دقايق (كانت أكتر)"],
    ["الترتيب الشهري", "المركز الأول ١٠٠ روح • التاني ٧٥ • التالت ٥٠ • الرابع ٢٥ • الخامس ١٠"],
]
D.table(["البند", "التفصيل"], rows, widths=[3.4, 13.2], size=9.5)
D.callout("خد بالك",
          "الروح (Souls) بتاعة الجيلد مش بتتحول لرصيد جيلد تاني — ده مكتوب صريح في شروط مواسمهم. "
          "يعني العملة «مقفولة» على الجيلد، وده قرار تصميمي مقصود لمنع السمسرة.")

D.pagebreak()

# ---------------------------------------------------------------- ch 9
D.h1("٨", "الأنظمة الصغيرة — اللي بتخلي السيرفر «مريح»")
D.p("دي أنظمة مش «محتوى»، لكنها الفرق بين سيرفر بتحس فيه إنه محترف وسيرفر بدائي.")

D.h2("١) التداول أوفلاين (Offline Trading)")
D.p("بدل ما تسيب اللعبة مفتوحة والكمبيوتر شغال عشان متجرك يفضل شغال:")
D.code("/atrade                  ← يبدأ التداول وأنت أوفلاين\n/atrade nickname         ← نفس الحاجة، وتحوّل الرسائل لشخص معين")
D.p("وباتش ٨.٠ قال: «الفانكشن دي اتصلحت في الكلاينت الجديد، ولما تستخدمها بتقطع الاتصال بالسيرفر أوتوماتيك» — "
    "يعني الفكرة إنه بيفصل عمداً عشان يشتغل أوفلاين.")

D.h2("٢) الـMarketplace (سوق بحث)")
D.p("تقدر تبحث عن الأدوات اللي معروضة في البازارات (Flea Market)، وكمان تشوف **تاريخ الأسعار** — "
    "مش بس السعر الحالي. ده بيخليك تعرف الأداة بتتباع بكام قبل ما تشتري.")

D.h2("٣) PvP Arena بين أعضاء نفس الجيلد")
D.p("حاجة نادرة: تقدر تعمل ماتش PvP مع جيلدك من غير ما تخسر سمعة الجيلد.")
D.code("/bp_oinvite nickname     ← تدعو قائد الفريق التاني")
D.bullet("بتعمل ماتش نوعه «Skirmish».")
D.bullet("الحد الأدنى ٢ لاعبين، الأقصى ١٦ (يعني ينفع ١ ضد ١).")
D.bullet("كل المشاركين لازم يعلنوا الجاهزية بزر، وبعدين القائد يبدأ المعركة.")
D.bullet("الماتش بيتلعب في منطقة Pyre Site.")

D.h2("٤) منع الماكرو (Macro Restriction)")
D.p("السيرفر فيه نظام كشف للبوتات/الماكرو. سيرفرات تانية بتقيسه بـ«وقت الدانجن» و«عدد الـOverlevel» "
    "و«تناسق ستات الشخصية». الفكرة إن أي سلوك آلي غير طبيعي بيتكشف — وده اللي بيخلي الاقتصاد سليم.")

D.h2("٥) Helper NPC — البوت بتاعك الرسمي")
D.p("ده NPC في كل مدينة بيعمل لك شغل متكرر ممل. اللي بيعمله (من الباتشات):")
D.bullet("فتح الصناديق الخشبية أوتوماتيك.")
D.bullet("فتح الخواتم والأسلحة من جزيرة الآلهة المنسية (Philosopher Scroll).")
D.bullet("فتح صناديق العالم الموازي (BPOC).")
D.bullet("تصنيع سكلات Ancient Element وCube (×١٠٠ قطعة).")
D.bullet("فانكشن «تكرار» لتبديل العملات ودمج كروت السكلات.")
D.bullet("استبدال الأدوات مقابل Morale Powders بنسبة أعلى ٥٪.")

D.h2("٦) البافات الموحّدة (Unified Blessing)")
D.bullet("Monarch Awakening — باف قوي (زي DT).")
D.bullet("Altered Almighty Pieces — +٥٠ ستات.")
D.bullet("Deva Blessing — باف من نوع تاني.")
D.p("كل دي بتتطبق من NPC واحد، وده اللي بيمنع اللاعب يلف على ١٠ NPCs.")

D.h2("٧) التليتلات والكوليكشنز")
D.bullet("تليتلات موسمية بألوان (Explorer ذهبي/فضي/برونزي/أزرق) حسب ترتيبك في السيرفر الموسمي.")
D.bullet("تليتلات من البرج بشرط سري — وتليتلات Weight (وزن) بعد باتش ٨.٠.")
D.bullet("كوليكشنز لكل بوس ولكل نظام — بتجمّع قطع، والكوليكشن نفسه بيدي ستات.")
D.bullet("وفيه ملاحظة باتش مهمة: «صلّحنا مشكلة إن تليتلات ما كانتش بتدي وزن» — تفصيلة صغيرة بتفرق جداً في اللعب.")

D.h2("٨) حاجات صغيرة بس بتفرق")
D.bullet("تيليبورتر NPC بقى فيه اختصار للبرج والمعمل، وفيه تيليبورت من الهاوية لـ Rondo والقرية المخفية ومدينة الأطلال.")
D.bullet("Unknown Pierrot — NPC مهام يومية في كل مدينة، جايزته صناديق مرقّمة.")
D.bullet("استرجاع الشخصيات (Character Restoration) من الكاش شوب — لو عملت حاجة غلط.")
D.bullet("عقوبة «العودة للمدينة»: −٩٠٪ سرعة حركة لمدة ١٠ دقايق، وتقدر تشيلها بأداة (٣٠٠ مليون لاك أو ٣ Ingot). سببها منع الهروب السريع من PvP.")
D.bullet("كل لاعب لحد لفل ١٨١ عليه جير +٢٣، والمبتدئين عليهم جير بتس — عشان محدش يتعطل في البداية.")

D.pagebreak()

# ---------------------------------------------------------------- ch 10
D.h1("٩", "الكلاسات والأسلحة الجديدة")
D.p("سبيس أضافوا كلاسات مش موجودة في الإصدار الرسمي. ودي حاجة أصعب بكتير من تعديل جداول — لأن الكلاس الجديد "
    "محتاج: أيقونات، أنيميشن، سكلات، شجرة مهارات، وواجهة.")
rows = [
    ["Elementalist", "فرع Druid", "سكلات عنصرية قوية، ومحتاجة كرات عنصرية (نار / ماء / أرض)", "١H Axe + Shield", "بقاء ضعيف، ضرر عالي، تحكم كتير"],
    ["Sniper", "كلاس قنص", "ضرر من مسافة عالية", "غالباً قوس/كروسبو", "كلاس جديد في Season 3"],
    ["Legionary", "كلاس عسكري", "سكلات هجومية ودفاعية للـPvP الجماعي", "—", "بيستخدم جينومات المعمل في بعض السكلات"],
    ["كلاس Breeder الجديد", "فرع Breeder", "استدعاء مزدوج، بس البتس أضعف", "٢H Staff", "قوي في PvP الجماعي، محتاج خبرة"],
]
D.table(["الكلاس", "الفرع", "الفكرة", "السلاح", "ملاحظات"],
        rows, widths=[3.0, 2.6, 5.0, 3.0, 3.0], size=8.5)
D.h2("أسلحة جديدة")
D.bullet("Magic Bow — لفل ١٦٠.")
D.bullet("Magic Spear — لفل ١٧٠.")
D.p("والأسلحة دي مش مجرد شكل: معاها سكلات وخط ستات. وبعض الكلاسات الجديدة «بتقفل» لو ماعندهاش الـGenome بتاعها من المعمل — "
    "وده ربط ذكي بين نظامين، بيخلي المعمل له قيمة دائمة.")

D.pagebreak()

# ---------------------------------------------------------------- ch 11
D.h1("١٠", "السر التقني — كل نظام وفين مكانه بالظبط")
D.p("دلوقتي الجزء اللي يهمك. كل حاجة شرحناها فوق، هقولك بتتعمل بأنهي أداة، وفين في ملفاتك بالظبط، والحكم.")
D.p("القاعدة الذهبية: **٩٠٪ من «الأنظمة» = جداول + سكربت Lua.** مش كود C++ جديد. "
    "الكود بيتكتب مرة واحدة في الإنجن، وبعد كده كل المحتوى أرقام.")

rows = [
    ["منطقة تجميع ١٨٠–٢٠٠", "نفس الخريطة + تغيير أرقام المونسترز + تكثيف الظهور + ضبط الدروب", "MonsterResource • monster_respawn.lua • DropGroupResource", "easy"],
    ["منطقة بدون PK", "علامة منع الهجوم في منطقة معينة", "RegionResource / EventAreaResource", "easy"],
    ["بوابة «تحت ٢٠٠ بس»", "NPC بيرفض التيليبورت لو لفلك أكبر", "NPC_TeleportField.lua + RunTeleport()", "easy"],
    ["رفع اللفل لـ٢٠٠", "صفوف خبرة جديدة + تغيير max_level", "LevelResource + .opt (max_level = 180)", "med"],
    ["رفع لفل البتس لـ٢١٠", "نفس الفكرة في جدول البتس", "Creature / PetResource + SummonLevelResource", "med"],
    ["بافات Unified Blessing", "NPC بيطبق State على الشخصية", "NPC_Buff.lua + StateResource + SkillResource", "easy"],
    ["جير +٢٣ وجير المبتدئين", "صفوف أدوات عادية بأيقونات", "ItemResource + أيقونات (2,771 اسم حقيقي)", "easy"],
    ["تليتلات Explorer", "شروط تليت + ترتيب", "TitleResource • TitleConditionResource", "easy"],
    ["Helper NPC (فتح صناديق)", "سكربت NPC بينادي دوال الأدوات", "NPC_ItemUP.lua + get_item_*", "med"],
    ["Marketplace بتاريخ أسعار", "جدول أسعار + واجهة/لوحة", "MarketResource • AutoAuctionResource", "med"],
    ["Crucible / Guild Zone", "انستانس + عملة + عدّاد أسبوعي + سكربت waves", "InstanceDungeon* + ItemResource + Lua", "hard"],
    ["Dark Laboratory + Genomes", "خريطة موجودة + موديلات + نظام States/Skills", "InstanceDungeon* • MonsterResource • StateResource", "hard"],
    ["Endless Tower (مقياس باللفل)", "سباون ديناميكي حسب لفل اللاعب + Checkpoint + بوس كل ٥", "InstanceDungeon* + سكربت Lua مخصص", "hard"],
    ["Offline Trading", "مش جدول — نظام سيرفر بيحفظ حالة المتجر", "برمجة سيرفر + DB (مش في الجداول)", "vhard"],
    ["استرجاع الشخصيات", "لوحة + داتابيز + صلاحيات", "DB + backend", "vhard"],
    ["كلاس جديد كامل", "أيقونات + أنيميشن + شجرة سكلات + UI", "SkillResource • SkillTreeResource • AnimationResource + كلاينت", "no"],
    ["خريطة جديدة من الصفر", "تصميم 3D + ملفات خريطة", ".nfa .nfc .nfe .nfm .nfs .qpf", "no"],
]
D.table(["النظام", "إزاي اتعمل فعلياً", "فين بالظبط في ملفاتك", "الحكم"],
        rows, widths=[4.0, 5.2, 5.4, 2.4], vcol=3, size=8.5)

D.h2("شرح الحكم ده بإيه؟")
D.bullet("سهل = شغل جداول وسكربت بسيط، تقدر تخلصه في يوم، بدون تعديل كلاينت.")
D.bullet("متوسط = محتاج تفكير وتجربة وتوازن، أو تعديل بسيط في الكلاينت.")
D.bullet("صعب = محتاج سكربت مخصص طويل + تجربة على السيرفر الحي + توازن.")
D.bullet("صعب جداً = محتاج برمجة على مستوى السيرفر نفسه ولوحة إدارة.")
D.bullet("مستحيل عملياً = محتاج فريق تصميم 3D وأدوات الكلاينت الرسمية.")

D.pagebreak()

# ---------------------------------------------------------------- ch 12
D.h1("١١", "الحكم الصريح — تقدر تقلّدهم؟")
D.p("هقولك الحقيقة من غير مجاملة، على ٤ مستويات:")

D.h2("المستوى الأول: سهل — وتعمله إنت لوحدك")
D.p("منطقة تجميع • منع PK • بوابة لفل • رفع اللفل كاب على السيرفر • بافات • جير جديد • تليتلات • Helper NPC بسيط.")
D.rich([("دي الحاجات اللي لو عملتها، سيرفرك هيبقى شكله «سيرفر محترم» مش «سيرفر تجربة». ", False, None),
        ("والوقت المتوقع: من يوم لأسبوع.", True, GREEN)])

D.h2("المستوى الثاني: متوسط — محتاج صبر وتجربة")
D.p("دانجن انستانس بسيط • نظام عملة تكرارية • Market بواجهة • توازن ستات للأدوات الجديدة • ربط نظامين ببعض (زي Genome + Skill).")
D.rich([("الوقت المتوقع: من أسبوع لشهر، ومعاك تجربة على السيرفر الحي. ", True, RGBColor(0x7F, 0x60, 0x00)),
        ("لو غلطت في التوازن، اللاعبين هيعرفوا قبل ما تكتشف إنت.", False, None)])

D.h2("المستوى الثالث: صعب — محتاج فريق صغير (٢–٣ أشخاص)")
D.p("Endless Tower بمقياس لفل • Dark Laboratory بـ٣ أدوار و١٦ Mutagen • Guild Zone بـ١١ مستوى وNPCs ومصانع • Crucible بـ١٠٠ Wave.")
D.rich([("دي مش «مستحيلة» — دي ", False, None),
        ("أشهر شغل عندهم، وماخدتش أسبوع.", True, RED),
        (" كل واحد منها فيه مئات الساعات: سكربت + تجربة + باتشات تصحيح (شوف كام باتش صلّحوا في نفس النظام).", False, None)])

D.h2("المستوى الرابع: مستحيل عملياً لوحدك")
D.p("كلاس جديد كامل • خريطة جديدة من الصفر • تعديلات كلاينت كبيرة • Offline trading من غير برمجة سيرفر.")

D.callout("الخلاصة اللي أنا عايزك تخرج بيها",
          "سبيس مش «ساحر». هما عملوا ٣ حاجات صح: (١) فهموا إن معظم المحتوى أرقام في جداول، "
          "(٢) استخدموا اللي موجود (خرائط، موديلات، أنظمة) بدل ما يبنوا من الصفر، "
          "(٣) عملوا باتشات صغيرة كتير بدل باتش ضخم واحد. "
          "لو مشيت على نفس التلاتة، هتوصل لأغلب اللي وصلوا له — بس بوقت أطول، ومش لوحدك.",
          fill="E2EFDA", bar="1E6B3A", title_color=GREEN)

D.pagebreak()

# ---------------------------------------------------------------- ch 13
D.h1("١٢", "الحقيقة عن الفريق — هما عملوها بإيدهم؟")
D.p("سؤال يستحق إجابة صريحة:")
D.bullet("السيرفر شغال من سنين، وفيه إصدارات 9.5.2 و9.6 — يعني عندهم إنجن أحدث من الـ9.1 اللي عندك، ومصدره مش رسمي.")
D.bullet("فريق مش شخص. فيه مبرمجين، وفيه ناس بتكتب باتش نوتس، وفيه دعم فني.")
D.bullet("وحتى هما، في صفحة منطقة الجيلد، شكروا شخص اسمه **[MD] Black** على إنه «صمّم الموقع الرائع ده». "
      "يعني حتى الخريطة/المنطقة، معمولة بمصمم خارجي.")
D.p("اللي عايزك تفهمه: مفيش سيرفر خاص في الدنيا عامل كل حاجة بإيده. النجاح مش «تعمل كل حاجة» — "
    "النجاح إنك تعرف **إيه تعمله بنفسك، وإيه تجيبه جاهز، وإيه تسيبه.**")
D.p("وعشان أكون منصف: هما كمان عندهم مشاكل. الباتشات بتصلّح أخطاء في أنظمتهم نفسها (زي مشكلة تليتلات البرج ما كانتش بتدي وزن، "
    "أو Genome بيسبب مشاكل aggro). يعني الأنظمة الكبيرة عمرها ما بتخلص — بتتظبط بالباتشات.")

D.pagebreak()

# ---------------------------------------------------------------- ch 14
D.h1("١٣", "خطتك العملية على سيرفر ٩.١ — من بكرة")
D.p("دي خطة ٥ مراحل. كل مرحلة بتنتهي بحاجة **شغالة**، مش «مكتوبة». وكل مرحلة أكبر من اللي قبلها.")

D.h2("المرحلة ٠ — التجهيز (قبل أي تعديل)")
D.num(1, "رجّع الداتابيز: Arcadia.bak و Billing.bak و Telecaster.bak لازم يترجعوا في SQL Server.")
D.num(2, "شغّل السيرفر وشوف اللعبة بتشتغل — لازم تلعب بنفسك قبل ما تعدّل.")
D.num(3, "اعمل نسخة احتياطية كاملة قبل أي تعديل. من غير ده، متلمسش حاجة.")
D.num(4, "ثبّت أداة تعديل الجداول (Grimoire أو ما يعادلها) — عشان تشوف الجداول من غير كود.")

D.h2("المرحلة ١ — منطقة تجميع ١٨٠–٢٠٠ (أسبوع ١)")
D.num(1, "اختار خريطة موجودة مناسب شكلها (زي Rondo).")
D.num(2, "في MonsterResource: غيّر لفل المونسترز لنطاق ١٨٠–٢٠٠، وظبط HP والخبرة.")
D.num(3, "في monster_respawn.lua: زوّد عدد الظهور في نفس البقعة.")
D.num(4, "في DropGroupResource: ظبط الدروب — الرقم بيبقى على مقياس ١٠٠٠٠ (٥٠٠ = ٥٪).")
D.num(5, "اعمل NPC بوابة في NPC_TeleportField.lua بـRunTeleport()، وحط شرط اللفل.")
D.num(6, "اختبر: ادخل بلفل ١٧٩ وبلفل ٢٠١ — لازم الأول يدخل والتاني يترفض.")
D.rich([("النتيجة: ", True, NAVY), ("منطقة تجميع حقيقية شغالة. ودي أهم حاجة هتعملها في السيرفر، لأنها اللي بتخلي اللفلات العالية لها لعب.", False, None)])

D.h2("المرحلة ٢ — اللفل كاب (أسبوع ٢)")
D.num(1, "افتح LevelResource وشوف آخر صف (١٨٠) — خد منه نمط الزيادة.")
D.num(2, "ضيف صفوف ١٨١–٢٠٠ بنفس المنطق (زيادة تدريجية في الخبرة المطلوبة).")
D.num(3, "غيّر max_level في .opt لـ٢٠٠.")
D.num(4, "اختبر صعود لفل ١٨٠ ← ١٨١ ← ١٨٢. لو اللعبة اتهنجت أو الشريط اتقطع، فده الكلاينت — محتاج تعديل بسيط.")
D.callout("تحذير حقيقي",
          "تعديل اللفل كاب ممكن يبان شغال في السيرفر ويقطع في الكلاينت. اختبر دايماً من الكلاينت، مش من الداتابيز. "
          "ولو الكلاينت قطع، ابدأ بـ١٨٥ كحد أقصى واختبر تاني.",
          fill="FFC7CE", bar="9C0006", title_color=RGBColor(0x9C, 0x00, 0x06))

D.h2("المرحلة ٣ — الرفاهية (أسبوع ٣)")
D.bullet("Helper NPC بسيط: فتح صندوق واحد أوتوماتيك.")
D.bullet("باف موحّد من NPC واحد (بدل ما اللاعب يلف على ١٠).")
D.bullet("جير بداية لكل لفل ١٦٠+ — بيقلل شكاوى المبتدئين أكتر من أي حاجة.")
D.bullet("تليتل بسيط بأول مرتبة في الترتيب الأسبوعي.")

D.h2("المرحلة ٤ — أول دانجن انستانس (شهر ٢)")
D.p("ابدأ بحاجة صغيرة: أوضة واحدة، ٣ مونسترز، بوس بسيط، ودروب واحد نادر. الهدف مش الإبهار — الهدف تفهم السايكل:")
D.code("NPC بيفتح الدانجن ← InstanceDungeonResource ← Respawn ← DropGroup ← Reward")
D.p("أول ما الفكرة تتظبط مرة، هتعمل ١٠ دانجنات بعدها.")

D.h2("المرحلة ٥ — النظام الكبير (شهر ٣+)")
D.p("ساعتها بس ابدأ في نظام زي البرج أو الجيلد زون. ومتبدأهاش لوحدك — محتاج حد يساعدك في التجربة والتوازن.")

D.h2("أخطاء بتقتل السيرفرات الخاصة — اتجنبها")
rows = [
    ["تعديل من غير باك أب", "تخسر شغل أسابيع. اعمل نسخة قبل أي حاجة."],
    ["رفع اللفل قبل المحتوى", "لاعبين بيوصلوا ٢٠٠ ومفيش مونسترز → بيسيبوا السيرفر."],
    ["توازن على الورق", "أي رقم جديد لازم يتجرب في اللعب الفعلي. الورق بيكدب."],
    ["باتش ضخم واحد", "سبيس بيعملوا باتشات صغيرة كتير. الصغير بيصلّح نفسه، الكبير بيكسر نفسه."],
    ["كلام كتير على السوشيال", "وعد بمحتوى مش جاهز = فقدان ثقة مش هترجع."],
    ["نسيان الكلاينت", "أي حاجة جديدة (أيقونة، كلاس، لفل) محتاجة كلاينت. اختبر من اللاعب مش من قاعدة البيانات."],
]
D.table(["الخطأ", "النتيجة"], rows, widths=[4.6, 12.0], size=9.5)

D.pagebreak()

# ---------------------------------------------------------------- ch 15 appendix
D.h1("١٤", "ملحق أ — الجداول الموجودة في Arcadia.bak بتاعك")
D.p("دي ٨٦ جدول Resource موجودين فعلاً في ملف الداتابيز اللي معاك (استخرجتهم بفحص الملف مباشرة). "
    "كل واحد منهم بيتحكم في نظام. اطبع الصفحة دي وعلّم على اللي هتشتغل عليه.")

tables = json.load(open("/home/user/notebook/arcadia_tables_clean.json"))
meaning = {
    "ItemResource": "الأدوات — أهم جدول في اللعبة",
    "MonsterResource": "الوحوش (لفل، HP، دروب)",
    "NPCResource": "الـNPCs",
    "LevelResource": "جدول الخبرة واللفلات",
    "SkillResource": "المهارات",
    "SkillTreeResource": "شجرة المهارات",
    "StateResource": "الحالات (باف/ديباف)",
    "DropGroupResource": "مجموعات الدروب",
    "MonsterDropTableResource": "جدول دروب كل وحش",
    "InstanceDungeonResource": "الدانجنات الانستانس",
    "InstanceDungeonMonsterRespawnResource": "ظهور وحوش الدانجن",
    "DungeonResource": "الدانجنات العادية",
    "SecretDungeonResource": "الدانجنات السرية",
    "TitleResource": "التليتلات",
    "TitleConditionResource": "شروط التليتلات",
    "PetResource": "البتس",
    "SummonResource": "الاستدعاءات",
    "QuestResource": "المهام",
    "MarketResource": "السوق",
    "MixResource": "التصنيع/الخلط",
    "EnhanceResource": "التطوير (+١ إلى +٢٠)",
    "DecomposeResource": "التحليل (تفكيك الأدوات)",
    "RandomItemOptionResource": "الخواص العشوائية للأدوات",
    "AwakenResource": "الصحوة (Awaken)",
    "BattleArenaResource": "أرينا الباتل",
    "HuntaholicResource": "نظام صيد الوحوش (Huntaholic)",
    "CreatureFarmResource": "مزرعة البتس",
    "ChannelResource": "قنوات السيرفر",
    "BanWordResource": "الكلمات الممنوعة",
    "JobResource": "الوظائف/الكلاسات",
    "StringResource": "نصوص اللعبة",
    "TextureResource": "الصور/التكستشر",
    "SoundResource": "الأصوات",
    "EffectResource": "التأثيرات",
    "FieldPropResource": "عناصر البيئة في الخريطة",
    "RoamingResource": "تجوال الوحوش",
}
rows = [[t, meaning.get(t, "—")] for t in tables]
D.table(["اسم الجدول", "بيتحكم في إيه"], rows, widths=[7.4, 9.2], size=7.5)

D.pagebreak()

D.h1("١٥", "ملحق ب — المصادر")
src = [
    ["صفحة معلومات السيرفر الرسمية", "rappelz.space/en/Information و /EN/Information — مناطق التجميع، الأنظمة، الباتشات"],
    ["صفحة منطقة الجيلد", "rappelz.space/En/Page/gildeyskaya_zona_1771 — مستويات الجيلد والأسعار"],
    ["صفحة البرج اللانهائي", "rappelz.space/En/Page/__1732 — تفاصيل الـ١٠٠ دور والجوايز"],
    ["صفحات المواسم", "novyy_server_season_4_space / season_5 — نظام الموسمية والجوايز"],
    ["موضوع Rappelz Space على ElitePvPers", "elitepvpers.com — سجل كامل للباتشات ٣.٠ → ٨.٠ وتفاصيل الأنظمة"],
    ["قوايم السيرفرات", "rappelzdc.weebly.com — الرايتس المعلنة"],
    ["ملفاتك", "FilesOfficial-Revolution9.1 (RDU, Script, dbs) — تحليل مباشر"],
]
D.table(["المصدر", "فيه إيه"], src, widths=[4.6, 12.0], size=9)

D.h2("ملاحظة أمانة أخيرة")
D.p("الأرقام في الفصل ٣ والفصل ٦ (أسعار الجيلد زون، وجوايز البرج) مأخوذة من صفحات وباتشات في فترات مختلفة. "
    "الأسعار تحديداً اتغيرت أكتر من مرة — مثلاً صرحوا إنهم «قللوا عدد الأرواح المطلوبة لترقية الجيلد زون»، "
    "وإن عقوبة الدخول للـCrucible اتقللت لـ١٠ دقايق. فخدها كنِسَب مقارنة، لا كأرقام نهائية.")
D.p("ولو حاجة في الملف ده غلط، أو لقيت رقم أحدث — عدّله بالقلم. ده ملفك إنت.")

D.spacer(20)
t2 = D.d.add_table(rows=1, cols=1)
bidi_table(t2)
c2 = t2.cell(0, 0)
shade(c2, "1F3864")
c2.paragraphs[0]._p.getparent().remove(c2.paragraphs[0]._p)
pp = c2.add_paragraph()
rtl_par(pp, WD_ALIGN_PARAGRAPH.CENTER)
pp.paragraph_format.space_before = Pt(10)
pp.paragraph_format.space_after = Pt(10)
rr = pp.add_run("خلص الملف  •  ابدأ من الفصل ١٣ — وبلاش تحاول تعمل كل حاجة في يوم")
rr.bold = True
rr.font.size = Pt(12)
rr.font.color.rgb = WHITE
rtl_run(rr)

D.save("/home/user/rappelz-space-full-details.docx")
print("saved")
