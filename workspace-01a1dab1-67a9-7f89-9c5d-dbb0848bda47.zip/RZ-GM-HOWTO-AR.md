# إزاي تبقى "جي إم" في باك 9.1 ده — الحقيقة والحل العملي
**2026-11-10 · Revolution 9.1 + rzauth v6.5**

---

## 1) الحقيقة الأول (بدليل من ملفات الباك نفسها)

فحصت `CaptainHerlockServer.exe` و`Telecaster.bak` بنفسي، والنتيجة قاطعة:

| اللي بتدوّر عليه | موجود؟ | الدليل |
|---|---|---|
| أوامر شات للجي إم (`.buff` / `.item` / `.level`) | ❌ **لا** | لا يوجد جدول أوامر شات في السيرفر، مافيش غير `"Invalid command..."` بتاع الكونسول |
| أوامر كونسول فيها شيت | ❌ **لا** | أوامر الكونسول: `about / set / get / show / del / watch / list / history / terminate / quit` بس |
| أداة `GMTool.exe` في الباك | ❌ **لا** | الباك فيه: Auth, Upload, Log, Game, ServerLauncher, DBUpdater فقط |
| Stored procs للأداة (`gmtool_cheat_*`) | ❌ **لا** | الموجود 4 فقط: `gmtool_Remove_Delete_item_rows`, `gmtool_set_character_quest`, `gmtool_v3_DTS_character_info`, `gmtool_v3_DTS_item_summon_info` |
| نظام صلاحيات (`AuthorityInfo` + `permission`) | ✅ **موجود** | `smp_read_authority_info` / `smp_set_authority_info` في `Telecaster.bak` |

**معنى ده:** الصلاحية موجودة كـ **بيانات**، لكن **الواجهة اللي تنفّذ الأوامر غير موجودة في الباك**. فمهما عملت، مش هتلاقي شات تكتب فيه `!buff`.

> **خلاصة:** ما تضيّعش وقت في تدوير أداة GM أو تفعيل `use_account_authority_db` وتتوقع أوامر. الطريق العملي تحت.

---

## 2) الحل العملي: 3 مستويات (من الأسهل للأقوى)

### المستوى ١ — معدلات السيرفر (أسرع حاجة، ومجانية المخاطر) ⭐
تأثيرها على **الاتنين** فورًا. عدّل في `GameServer.opt` وأعد الضغط:

```
F:game.exp_rate:100          →  F:game.exp_rate:1000
F:game.gold_drop_rate:100    →  F:game.gold_drop_rate:500
F:game.item_drop_rate:100    →  F:game.item_drop_rate:500
T:game.no_skill_cooltime:0   →  T:game.no_skill_cooltime:1
T:game.no_collision_check:0  →  T:game.no_collision_check:1
```

```cmd
cd /d "C:\RZ\Server\FilesOfficial-Revolution9.1\GameEngine\Game_bin" && RappelzCompress.exe GameServer.opt
```
> `no_skill_cooltime` = سكيلات بدون تهدئة، و`no_collision_check` = تمشي في الحيطة. دي أقرب حاجة لـ "إحساس الجي إم" من غير نظام صلاحيات.

**تحقق:** بعد إعادة تشغيل السيرفر، اقتل مونستر وشوف الخبرة/الفلوس — لازم تتضاعف.

---

### المستوى ٢ — تعديل مباشر في قاعدة البيانات (تحكم كامل) ⭐⭐

عمود `permission` **موجود فعلًا** في `Telecaster1.dbo.Character` — ده علم الجي إم على مستوى الشخصية.

الأعمدة المهمة اللي تأكدت منها من سكيما الباك:

`name · lv · exp · max_reached_level · jp · total_jp · talent_point · gold · cha · chaos · huntaholic_point · arena_point · permission`

شغّل **`rz-gm-powers.sql`** (نفس المجلد) — فيه أوامر جاهزة لكل حاجة.

**⚠️ القاعدة الحاسمة:** عدّل والشخصية **خارج اللعبة** (Logout كامل، مش واقف في شاشة اختيار الشخصية). لو عدّلت وهو داخل، تعديلك هيتمسح أول حفظ تلقائي.

**⚠️ خد backup للقاعدة قبل أي `UPDATE`:**
```cmd
sqlcmd -S . -E -b -Q "BACKUP DATABASE Telecaster1 TO DISK='F:\AhmedZahran\rz-backup\Telecaster1.bak' WITH INIT, COMPRESSION" -b
```

---

### المستوى ٣ — "البفات" بالتحديد: ليه مش من الداتابيز

> البفات **مش عمود في جدول** — دي حالة وقت التشغيل (runtime) بتتحسب في ذاكرة السيرفر. مافيش `UPDATE` بيدّي بفات.

**البدائل اللي بتشتغل فعلًا:**
1. **أيتم/بوتشن بفات** — تدّيهوله جولد (المستوى ٢) وهو يشتري من NPC أو من Cash Shop.
2. **معدلات عالية** — بديل نفسي عن البفات (بيخلي كل حاجة أسهل).
3. **NPC سكربت** — الباك فيه محرك سكربت قوي (292 دالة `SCRIPT_*`: `SCRIPT_DropItem`, `SCRIPT_DropGold`, `SCRIPT_AddExpJP`, `SCRIPT_ChangeItemCode`…). ممكن نعمل NPC يعطي أيتم/بفات بضغطة. **ده مشروع منفصل** — قولي لو عايزه، وأعملك الـ Lua خطوة بخطوة.

---

## 3) طريق "الصلاحية الرسمية" (لو مصمم تعرف)

هو موجود في الكود، ومحتاج 4 حاجات كلهم مع بعض:

1. Restore قاعدة **`ArcadiaInfo`** (في الباك: `dbs/Arcadia.bak`).
2. Linked server اسمه **`ArcadiaInfo`** — لأن الـ procs بتقرا
   `ArcadiaInfo.ArcadiaInfo.dbo.AuthorityInfo` (اسم مزدوج = linked server).
   ```sql
   EXEC sp_addlinkedserver @server='ArcadiaInfo', @srvproduct='', @provider='SQLNCLI', @datasrc='.';
   ```
3. تفعيل `game.use_account_authority_db` في `GameServer.opt` (مش موجود عندك أصلًا ⇒ مطفّي).
4. صف في `AuthorityInfo(account, authority_type, expire_time)`.

**بس خُد بالك:** قيمة `authority_type` للجي إم **مش موجودة في أي مكان في الباك** (اللي اتأكدت منه: `910000` = صلاحية كاش شوب من جدول `Billing.dbo.PaidItem`). وأهم من ده: **حتى لو فعّلتها، مافيش أوامر تنفّذها** — الصلاحية بتفتح دوال سكربت (`PERMISSION_FOR_GM`) مش أوامر شات.

⇒ يعني شغل كتير ومكسب صفر عمليًا. **متجربهاش دلوقتي.**

---

## 4) الأمان في التعامل مع الداتابيز

| خطأ شائع | النتيجة | الصح |
|---|---|---|
| `UPDATE` والشخصية داخل اللعبة | التعديل يتمسح | اقفل اللعبة بالكامل |
| تغيير `lv` بدون `exp` | السيرفر يرجّع الليفل أو سلوك غريب | غيّرهم مع بعض |
| تعديل `auth_ok` أو `block` | منع الدخول / قفل الحساب | سيبهم زي ما هما |
| تعديل بدون backup | صعب الرجوع | `BACKUP DATABASE` قبل أي حاجة |
| تجربة على شخصيتك الأساسية | تخسرها | اعمل شخصية تجريبية `gmtest` |

---

## 5) ترتيب التنفيذ المقترح (وانت مستني صاحبك يحمّل)

1. **المعدلات** (المستوى ١) — دقيقتين، وتأثيرها فوري على الاتنين.
2. **جولد + نقاط** لشخصيتك وشخصيته من `rz-gm-powers.sql` — وهم offline.
3. **جرّب `permission = 1`** على شخصية تجريبية وشوف إذا العميل أظهر أي حاجة. لو مافيش، رجّعه `0` وانسى الموضوع.
4. لو عايز بفات حقيقية → نبدأ NPC سكربت.
