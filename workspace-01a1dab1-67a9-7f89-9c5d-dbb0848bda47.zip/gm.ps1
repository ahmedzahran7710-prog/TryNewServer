param(
    [string]$Server = ".",
    [string]$Db     = "Telecaster1",
    [string]$AuthDb = "Auth"
)

# ==========================================================================
#  Rappelz 9.1 GM Console  (ASCII only - safe for Windows PowerShell 5.1)
#  Usage:  powershell -NoProfile -ExecutionPolicy Bypass -File gm.ps1
#  Rule:   the character must be OFFLINE before any change command.
# ==========================================================================

$ErrorActionPreference = "Continue"

function Run-Sql {
    param([string]$Query, [string]$Database)
    if ([string]::IsNullOrEmpty($Database)) { $Database = $Db }
    & sqlcmd -S $Server -d $Database -E -b -h -1 -W -Q $Query
}

function Is-Name { param([string]$v) return ($v -match '^[A-Za-z0-9_\-]{1,31}$') }
function Is-Num  { param([string]$v) return ($v -match '^-?[0-9]{1,10}$') }

function Show-Help {
    Write-Host ""
    Write-Host "  list                        all characters (sid, name, lv, gold, perm)"
    Write-Host "  who NAME                    one character"
    Write-Host "  gold NAME AMOUNT            add money (negative to remove)"
    Write-Host "  goldset NAME AMOUNT         set money to exact value"
    Write-Host "  points NAME JP STAT         add skill points and stat points"
    Write-Host "  level NAME LV               set level"
    Write-Host "  perm NAME 0|1               GM flag (permission column)"
    Write-Host "  tp NAME X Y Z LAYER         move character (must be offline)"
    Write-Host "  block LOGIN 0|1             block or unblock an account"
    Write-Host "  accounts                    all login accounts"
    Write-Host "  sql QUERY                   raw SQL (dangerous)"
    Write-Host "  help / exit"
    Write-Host ""
}

if (-not (Get-Command sqlcmd -ErrorAction SilentlyContinue)) {
    Write-Host "[X] sqlcmd not found in PATH. Open a new CMD window and try again." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "  Rappelz 9.1 GM Console   DB: $Server / $Db" -ForegroundColor Yellow
Write-Host "  WARNING: character must be OFFLINE before any change command." -ForegroundColor Red
Write-Host "  Type help for the command list." -ForegroundColor DarkGray
Write-Host ""

while ($true) {

    $line = Read-Host "GM>"
    if ([string]::IsNullOrWhiteSpace($line)) { continue }

    $p   = $line.Trim() -split '\s+'
    $cmd = $p[0].ToLower()

    if ($cmd -eq 'exit' -or $cmd -eq 'quit') {
        Write-Host "bye."
        break
    }
    elseif ($cmd -eq 'help') {
        Show-Help
    }
    elseif ($cmd -eq 'list') {
        Run-Sql "SET NOCOUNT ON; SELECT CAST(sid AS VARCHAR(12)) + '  ' + name + '  lv=' + CAST(lv AS VARCHAR(6)) + '  gold=' + CAST(gold AS VARCHAR(20)) + '  perm=' + CAST(permission AS VARCHAR(4)) FROM dbo.Character WHERE name NOT LIKE '@%' ORDER BY sid;"
    }
    elseif ($cmd -eq 'who') {
        if ($p.Count -lt 2) { Write-Host "[X] usage: who NAME"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad name"; continue }
        $n = $p[1]
        Run-Sql "SET NOCOUNT ON; SELECT sid,name,account_id,lv,exp,jp,total_jp,talent_point,gold,chaos,permission FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'gold') {
        if ($p.Count -lt 3) { Write-Host "[X] usage: gold NAME AMOUNT"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad name"; continue }
        if (-not (Is-Num  $p[2])) { Write-Host "[X] amount must be a number"; continue }
        $n = $p[1]; $a = $p[2]
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Character SET gold = gold + ($a) WHERE name = N'$n'; SELECT 'new gold = ' + CAST(gold AS VARCHAR(20)) FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'goldset') {
        if ($p.Count -lt 3) { Write-Host "[X] usage: goldset NAME AMOUNT"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad name"; continue }
        if (-not (Is-Num  $p[2])) { Write-Host "[X] amount must be a number"; continue }
        $n = $p[1]; $a = $p[2]
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Character SET gold = ($a) WHERE name = N'$n'; SELECT 'new gold = ' + CAST(gold AS VARCHAR(20)) FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'points') {
        if ($p.Count -lt 4) { Write-Host "[X] usage: points NAME JP STAT"; continue }
        if (-not (Is-Name $p[1]) -or -not (Is-Num $p[2]) -or -not (Is-Num $p[3])) { Write-Host "[X] bad arguments"; continue }
        $n = $p[1]; $jp = $p[2]; $st = $p[3]
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Character SET jp = jp + ($jp), total_jp = total_jp + ($jp), talent_point = talent_point + ($st) WHERE name = N'$n'; SELECT 'jp=' + CAST(jp AS VARCHAR(12)) + ' total_jp=' + CAST(total_jp AS VARCHAR(12)) + ' talent=' + CAST(talent_point AS VARCHAR(12)) FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'level') {
        if ($p.Count -lt 3) { Write-Host "[X] usage: level NAME LV"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad name"; continue }
        if (-not (Is-Num  $p[2])) { Write-Host "[X] level must be a number"; continue }
        $n = $p[1]; $lv = $p[2]
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Character SET lv = ($lv), max_reached_level = ($lv), exp = 0 WHERE name = N'$n'; SELECT 'lv=' + CAST(lv AS VARCHAR(6)) + ' exp=' + CAST(exp AS VARCHAR(20)) FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'perm') {
        if ($p.Count -lt 3) { Write-Host "[X] usage: perm NAME 0|1"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad name"; continue }
        if ($p[2] -notmatch '^[0-9]$') { Write-Host "[X] value must be 0 to 9"; continue }
        $n = $p[1]; $v = $p[2]
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Character SET permission = ($v) WHERE name = N'$n'; SELECT 'permission = ' + CAST(permission AS VARCHAR(4)) FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'tp') {
        if ($p.Count -lt 5) { Write-Host "[X] usage: tp NAME X Y Z LAYER"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad name"; continue }
        $n = $p[1]; $x = $p[2]; $y = $p[3]; $z = $p[4]
        if ($p.Count -ge 6) { $layer = $p[5] } else { $layer = "1" }
        if (-not (Is-Num $x) -or -not (Is-Num $y) -or -not (Is-Num $z) -or -not (Is-Num $layer)) { Write-Host "[X] coordinates must be numbers"; continue }
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Character SET x = ($x), y = ($y), z = ($z), layer = ($layer) WHERE name = N'$n'; SELECT 'pos=' + CAST(x AS VARCHAR(12)) + ',' + CAST(y AS VARCHAR(12)) + ',' + CAST(z AS VARCHAR(12)) + ' layer=' + CAST(layer AS VARCHAR(6)) FROM dbo.Character WHERE name = N'$n';"
    }
    elseif ($cmd -eq 'block') {
        if ($p.Count -lt 3) { Write-Host "[X] usage: block LOGIN 0|1"; continue }
        if (-not (Is-Name $p[1])) { Write-Host "[X] bad login"; continue }
        if ($p[2] -notmatch '^[01]$') { Write-Host "[X] value must be 0 or 1"; continue }
        $l = $p[1]; $v = $p[2]
        Run-Sql "SET NOCOUNT ON; UPDATE dbo.Accounts SET block = ($v) WHERE login_name = N'$l'; SELECT login_name + ' block=' + CAST(block AS VARCHAR(4)) FROM dbo.Accounts WHERE login_name = N'$l';" $AuthDb
    }
    elseif ($cmd -eq 'accounts') {
        Run-Sql "SET NOCOUNT ON; SELECT CAST(account_id AS VARCHAR(12)) + '  ' + login_name + '  block=' + CAST(block AS VARCHAR(4)) + '  auth_ok=' + CAST(auth_ok AS VARCHAR(4)) FROM dbo.Accounts ORDER BY account_id;" $AuthDb
    }
    elseif ($cmd -eq 'sql') {
        if ($p.Count -lt 2) { Write-Host "[X] usage: sql QUERY"; continue }
        $q = $line.Substring(3).Trim()
        Write-Host "[!] running raw SQL - make sure you know exactly what it does." -ForegroundColor Yellow
        Run-Sql $q
    }
    else {
        Write-Host "[X] unknown command: $cmd   (type help)" -ForegroundColor Red
    }
}
