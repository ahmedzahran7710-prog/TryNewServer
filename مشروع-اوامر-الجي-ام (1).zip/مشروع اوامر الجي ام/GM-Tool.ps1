<#
  RZ-GM Tool v1.0  --  Windows GUI for Rappelz 9.1
  ASCII ONLY. Do not add non-ASCII characters to this file.

  Talks to SQL Server directly (no console password needed).
  Changes are stored in the database and take effect when the
  character logs in (or relogs).

  Run:  powershell -ExecutionPolicy Bypass -File .\GM-Tool.ps1
#>

param([switch]$SelfTest)

if ($SelfTest) {
    Write-Host "GM-Tool.ps1 self-test: file loads and parses OK."
    Write-Host "GUI needs Windows + .NET WinForms (PowerShell 5.1)."
    exit 0
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------------------------------------------------------------- helpers
$script:Conn = $null
$script:SelectedSid = $null
$script:SelectedName = $null

function Log([string]$msg) {
    $ts = (Get-Date).ToString('HH:mm:ss')
    $txtLog.AppendText("[$ts] $msg`r`n")
    $txtLog.SelectionStart = $txtLog.Text.Length
    $txtLog.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Connect-Db {
    $cs = "Server=$($txtServer.Text);Database=$($txtDb.Text);User Id=$($txtUser.Text);Password=$($txtPass.Text);TrustServerCertificate=True;Connect Timeout=5;"
    try {
        if ($script:Conn -ne $null) { $script:Conn.Close() }
        $script:Conn = New-Object System.Data.SqlClient.SqlConnection $cs
        $script:Conn.Open()
        $lblStatus.Text = "Connected"
        $lblStatus.ForeColor = [System.Drawing.Color]::Green
        Log "Connected to $($txtServer.Text) / $($txtDb.Text)"
        Load-Characters
    }
    catch {
        $lblStatus.Text = "Not connected"
        $lblStatus.ForeColor = [System.Drawing.Color]::Red
        Log ("CONNECT FAILED: " + $_.Exception.Message)
        Log "Tip: SQL service running? User 'rappelz' with empty password? Instance name right?"
    }
}

function Load-Characters {
    if ($script:Conn -eq $null) { Log "Not connected."; return }
    try {
        $q = "SELECT TOP 300 sid, name, lv, gold, permission FROM dbo.Character WHERE name LIKE @f ORDER BY lv DESC"
        $cmd = $script:Conn.CreateCommand()
        $cmd.CommandText = $q
        [void]$cmd.Parameters.AddWithValue("@f", "%" + $txtFilter.Text + "%")
        $dt = New-Object System.Data.DataTable
        $da = New-Object System.Data.SqlClient.SqlDataAdapter $cmd
        [void]$da.Fill($dt)
        $grid.DataSource = $dt
        if ($grid.Columns.Count -gt 0) {
            $grid.Columns['sid'].Width = 60
            $grid.Columns['name'].Width = 150
            $grid.Columns['lv'].Width = 60
            $grid.Columns['gold'].Width = 110
            $grid.Columns['permission'].Width = 70
        }
        Log "Loaded $($dt.Rows.Count) character(s)."
    }
    catch { Log ("LOAD FAILED: " + $_.Exception.Message) }
}

function Get-Sid {
    if ($script:SelectedSid -eq $null) { Log "Select a character first."; return $null }
    return $script:SelectedSid
}

function Require-Backup {
    if (-not $chkBackup.Checked) {
        Log "BLOCKED: tick [I have a backup] first."
        return $false
    }
    if ($script:Conn -eq $null) { Log "BLOCKED: not connected."; return $false }
    return $true
}

function Exec([string]$sql, $pars) {
    $cmd = $script:Conn.CreateCommand()
    $cmd.CommandText = $sql
    foreach ($k in $pars.Keys) { [void]$cmd.Parameters.AddWithValue($k, $pars[$k]) }
    try {
        $n = $cmd.ExecuteNonQuery()
        Log "OK ($n row)."
        return $true
    }
    catch { Log ("SQL FAILED: " + $_.Exception.Message); return $false }
}

# ---------------------------------------------------------------- actions
function Do-SetGold {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    $v = [int64]0; if (-not [int64]::TryParse($txtGold.Text, [ref]$v)) { Log "Gold must be a number."; return }
    $ok = Exec "UPDATE dbo.Character SET gold=@g WHERE sid=@sid" @{ '@g' = $v; '@sid' = $sid }
    if ($ok) { Log "gold = $v for $($script:SelectedName) (applies on next login)"; Load-Characters }
}

function Do-AddGold {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    $v = [int64]0; if (-not [int64]::TryParse($txtAddGold.Text, [ref]$v)) { Log "Amount must be a number."; return }
    $ok = Exec "UPDATE dbo.Character SET gold=gold+@g WHERE sid=@sid" @{ '@g' = $v; '@sid' = $sid }
    if ($ok) { Log "+$v gold for $($script:SelectedName)"; Load-Characters }
}

function Do-SetLevel {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    $v = 0; if (-not [int]::TryParse($txtLevel.Text, [ref]$v)) { Log "Level must be a number."; return }
    if ($v -lt 1 -or $v -gt 200) { Log "Level must be 1..200."; return }
    $ok = Exec "UPDATE dbo.Character SET lv=@l, max_reached_level=CASE WHEN max_reached_level<@l THEN @l ELSE max_reached_level END WHERE sid=@sid" @{ '@l' = $v; '@sid' = $sid }
    if ($ok) { Log "level = $v for $($script:SelectedName). Note: exp is not adjusted."; Load-Characters }
}

function Do-AddExp {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    $e = [int64]0; if (-not [int64]::TryParse($txtExp.Text, [ref]$e)) { Log "Exp must be a number."; return }
    $j = [int64]0; if (-not [int64]::TryParse($txtJp.Text, [ref]$j)) { Log "Jp must be a number."; return }
    $ok = Exec "UPDATE dbo.Character SET exp=exp+@e, jp=jp+@j, total_jp=total_jp+@j WHERE sid=@sid" @{ '@e' = $e; '@j' = $j; '@sid' = $sid }
    if ($ok) { Log "exp +$e, jp +$j for $($script:SelectedName)" }
}

function Do-SetPermission {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    $v = 0; if (-not [int]::TryParse($txtPerm.Text, [ref]$v)) { Log "Permission must be a number."; return }
    $ok = Exec "UPDATE dbo.Character SET permission=@p WHERE sid=@sid" @{ '@p' = $v; '@sid' = $sid }
    if ($ok) { Log "permission = $v for $($script:SelectedName)" ; Load-Characters }
}

function Do-Teleport {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    $x = 0; $y = 0; $z = 0; $layer = 1
    if (-not [int]::TryParse($txtX.Text, [ref]$x)) { Log "x must be a number."; return }
    if (-not [int]::TryParse($txtY.Text, [ref]$y)) { Log "y must be a number."; return }
    if (-not [int]::TryParse($txtZ.Text, [ref]$z)) { Log "z must be a number."; return }
    if (-not [int]::TryParse($txtLayer.Text, [ref]$layer)) { Log "layer must be a number."; return }
    $ok = Exec "UPDATE dbo.Character SET x=@x, y=@y, z=@z, layer=@l WHERE sid=@sid" @{ '@x' = $x; '@y' = $y; '@z' = $z; '@l' = $layer; '@sid' = $sid }
    if ($ok) { Log "teleport $($script:SelectedName) -> layer $layer ($x,$y,$z)" }
}

function Do-SetGoldAll {
    if (-not (Require-Backup)) { return }
    $v = [int64]0; if (-not [int64]::TryParse($txtGold.Text, [ref]$v)) { Log "Gold must be a number."; return }
    $ans = [System.Windows.Forms.MessageBox]::Show(
        "Set gold = $v for EVERY character in the database?", "Confirm",
        [System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($ans -ne 'Yes') { Log "cancelled"; return }
    $ok = Exec "UPDATE dbo.Character SET gold=@g WHERE delete_time IS NULL" @{ '@g' = $v }
    if ($ok) { Log "gold = $v for ALL characters"; Load-Characters }
}

function Do-BlockAccount {
    if (-not (Require-Backup)) { return }
    $sid = Get-Sid; if ($sid -eq $null) { return }
    try {
        $cmd = $script:Conn.CreateCommand()
        $cmd.CommandText = "SELECT account_id FROM dbo.Character WHERE sid=@sid"
        [void]$cmd.Parameters.AddWithValue("@sid", $script:SelectedSid)
        $acc = $cmd.ExecuteScalar()
        if ($acc -eq $null) { Log "account_id not found."; return }
        $val = 1; if (-not $chkBlock.Checked) { $val = 0 }
        $ok = Exec "UPDATE [Auth].[dbo].[Accounts] SET block=@b WHERE account_id=@a" @{ '@b' = $val; '@a' = $acc }
        if ($ok) { Log "account $acc block = $val" }
    }
    catch { Log ("BLOCK FAILED: " + $_.Exception.Message) }
}

# ---------------------------------------------------------------- form
$form = New-Object System.Windows.Forms.Form
$form.Text = "RZ-GM Tool v1.0  -  Rappelz 9.1"
$form.Size = New-Object System.Drawing.Size(940, 660)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

# --- connection row
$lbl1 = New-Object System.Windows.Forms.Label
$lbl1.Text = "Server"; $lbl1.Location = New-Object System.Drawing.Point(10, 14); $lbl1.Size = New-Object System.Drawing.Size(50, 20)
$form.Controls.Add($lbl1)

$txtServer = New-Object System.Windows.Forms.TextBox
$txtServer.Text = "DESKTOP-ICQ037B\SQLEXPRESS"
$txtServer.Location = New-Object System.Drawing.Point(62, 11); $txtServer.Size = New-Object System.Drawing.Size(230, 24)
$form.Controls.Add($txtServer)

$lbl2 = New-Object System.Windows.Forms.Label
$lbl2.Text = "DB"; $lbl2.Location = New-Object System.Drawing.Point(300, 14); $lbl2.Size = New-Object System.Drawing.Size(30, 20)
$form.Controls.Add($lbl2)

$txtDb = New-Object System.Windows.Forms.TextBox
$txtDb.Text = "Telecaster1"
$txtDb.Location = New-Object System.Drawing.Point(332, 11); $txtDb.Size = New-Object System.Drawing.Size(110, 24)
$form.Controls.Add($txtDb)

$lbl3 = New-Object System.Windows.Forms.Label
$lbl3.Text = "User"; $lbl3.Location = New-Object System.Drawing.Point(450, 14); $lbl3.Size = New-Object System.Drawing.Size(36, 20)
$form.Controls.Add($lbl3)

$txtUser = New-Object System.Windows.Forms.TextBox
$txtUser.Text = "rappelz"
$txtUser.Location = New-Object System.Drawing.Point(488, 11); $txtUser.Size = New-Object System.Drawing.Size(90, 24)
$form.Controls.Add($txtUser)

$lbl4 = New-Object System.Windows.Forms.Label
$lbl4.Text = "Pass"; $lbl4.Location = New-Object System.Drawing.Point(586, 14); $lbl4.Size = New-Object System.Drawing.Size(36, 20)
$form.Controls.Add($lbl4)

$txtPass = New-Object System.Windows.Forms.TextBox
$txtPass.UseSystemPasswordChar = $true
$txtPass.Location = New-Object System.Drawing.Point(624, 11); $txtPass.Size = New-Object System.Drawing.Size(90, 24)
$form.Controls.Add($txtPass)

$btnConnect = New-Object System.Windows.Forms.Button
$btnConnect.Text = "Connect"
$btnConnect.Location = New-Object System.Drawing.Point(722, 9); $btnConnect.Size = New-Object System.Drawing.Size(90, 26)
$btnConnect.Add_Click({ Connect-Db })
$form.Controls.Add($btnConnect)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Not connected"
$lblStatus.ForeColor = [System.Drawing.Color]::Red
$lblStatus.Location = New-Object System.Drawing.Point(818, 14); $lblStatus.Size = New-Object System.Drawing.Size(100, 20)
$form.Controls.Add($lblStatus)

# --- filter
$txtFilter = New-Object System.Windows.Forms.TextBox
$txtFilter.Location = New-Object System.Drawing.Point(62, 44); $txtFilter.Size = New-Object System.Drawing.Size(200, 24)
$form.Controls.Add($txtFilter)

$lblF = New-Object System.Windows.Forms.Label
$lblF.Text = "Name"
$lblF.Location = New-Object System.Drawing.Point(10, 47); $lblF.Size = New-Object System.Drawing.Size(50, 20)
$form.Controls.Add($lblF)

$btnLoad = New-Object System.Windows.Forms.Button
$btnLoad.Text = "Search"
$btnLoad.Location = New-Object System.Drawing.Point(268, 42); $btnLoad.Size = New-Object System.Drawing.Size(80, 26)
$btnLoad.Add_Click({ Load-Characters })
$form.Controls.Add($btnLoad)

$chkBackup = New-Object System.Windows.Forms.CheckBox
$chkBackup.Text = "I have a backup (required before any write)"
$chkBackup.Location = New-Object System.Drawing.Point(360, 45); $chkBackup.Size = New-Object System.Drawing.Size(320, 22)
$form.Controls.Add($chkBackup)

# --- grid
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(10, 78)
$grid.Size = New-Object System.Drawing.Size(560, 300)
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.MultiSelect = $false
$grid.AutoSizeColumnsMode = 'None'
$grid.Add_SelectionChanged({
    if ($grid.CurrentRow -ne $null) {
        $script:SelectedSid = $grid.CurrentRow.Cells['sid'].Value
        $script:SelectedName = $grid.CurrentRow.Cells['name'].Value
        $lblSel.Text = "Selected: $($script:SelectedName) (sid $($script:SelectedSid))"
    }
})
$form.Controls.Add($grid)

$lblSel = New-Object System.Windows.Forms.Label
$lblSel.Text = "Selected: none"
$lblSel.Location = New-Object System.Drawing.Point(10, 382); $lblSel.Size = New-Object System.Drawing.Size(560, 20)
$form.Controls.Add($lblSel)

# --- right panel
$x = 584
function New-Label($text, $y) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size(70, 20)
    $form.Controls.Add($l)
}
function New-Text($text, $y, $w) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Text = $text
    $t.Location = New-Object System.Drawing.Point(($x + 74), $y)
    $t.Size = New-Object System.Drawing.Size($w, 24)
    $form.Controls.Add($t)
    return $t
}
function New-Button($text, $y, $handler) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size(330, 26)
    $b.Add_Click($handler)
    $form.Controls.Add($b)
}

New-Label "Gold =" 84  | Out-Null
$txtGold   = New-Text "1000000" 84 120
New-Label "Add"    118 | Out-Null
$txtAddGold= New-Text "100000"  118 120

$y = 152
New-Button "Set gold (exact)"      $y { Do-SetGold }    | Out-Null
$y += 30
New-Button "Add gold"              $y { Do-AddGold }    | Out-Null
$y += 30

New-Label "Level =" ($y + 3) | Out-Null
$txtLevel = New-Text "200" $y 120
$y += 30
New-Button "Set level" $y { Do-SetLevel } | Out-Null
$y += 30

New-Label "Exp" ($y + 3) | Out-Null
$txtExp = New-Text "1000000" $y 60

$lblJp = New-Object System.Windows.Forms.Label
$lblJp.Text = "JP"
$lblJp.Location = New-Object System.Drawing.Point(($x + 190), ($y + 3))
$lblJp.Size = New-Object System.Drawing.Size(24, 20)
$form.Controls.Add($lblJp)

$txtJp = New-Object System.Windows.Forms.TextBox
$txtJp.Text = "0"
$txtJp.Location = New-Object System.Drawing.Point(($x + 214), $y)
$txtJp.Size = New-Object System.Drawing.Size(116, 24)
$form.Controls.Add($txtJp)
$y += 30
New-Button "Add exp / jp" $y { Do-AddExp } | Out-Null
$y += 30

New-Label "Perm =" ($y + 3) | Out-Null
$txtPerm = New-Text "0" $y 120
$y += 30
New-Button "Set permission" $y { Do-SetPermission } | Out-Null
$y += 30

# --- teleport block
$lblTp = New-Object System.Windows.Forms.Label
$lblTp.Text = "Teleport  x / y / z / layer"
$lblTp.Location = New-Object System.Drawing.Point(10, 410)
$lblTp.Size = New-Object System.Drawing.Size(200, 20)
$form.Controls.Add($lblTp)

$txtX = New-Object System.Windows.Forms.TextBox
$txtX.Text = "0"; $txtX.Location = New-Object System.Drawing.Point(10, 432); $txtX.Size = New-Object System.Drawing.Size(70, 24)
$form.Controls.Add($txtX)

$txtY = New-Object System.Windows.Forms.TextBox
$txtY.Text = "0"; $txtY.Location = New-Object System.Drawing.Point(86, 432); $txtY.Size = New-Object System.Drawing.Size(70, 24)
$form.Controls.Add($txtY)

$txtZ = New-Object System.Windows.Forms.TextBox
$txtZ.Text = "0"; $txtZ.Location = New-Object System.Drawing.Point(162, 432); $txtZ.Size = New-Object System.Drawing.Size(70, 24)
$form.Controls.Add($txtZ)

$txtLayer = New-Object System.Windows.Forms.TextBox
$txtLayer.Text = "1"; $txtLayer.Location = New-Object System.Drawing.Point(238, 432); $txtLayer.Size = New-Object System.Drawing.Size(50, 24)
$form.Controls.Add($txtLayer)

$btnTp = New-Object System.Windows.Forms.Button
$btnTp.Text = "Teleport"
$btnTp.Location = New-Object System.Drawing.Point(296, 430); $btnTp.Size = New-Object System.Drawing.Size(90, 26)
$btnTp.Add_Click({ Do-Teleport })
$form.Controls.Add($btnTp)

$chkBlock = New-Object System.Windows.Forms.CheckBox
$chkBlock.Text = "block account"
$chkBlock.Location = New-Object System.Drawing.Point(400, 433); $chkBlock.Size = New-Object System.Drawing.Size(120, 22)
$form.Controls.Add($chkBlock)

$btnBlock = New-Object System.Windows.Forms.Button
$btnBlock.Text = "Apply block flag"
$btnBlock.Location = New-Object System.Drawing.Point(520, 430); $btnBlock.Size = New-Object System.Drawing.Size(100, 26)
$btnBlock.Add_Click({ Do-BlockAccount })
$form.Controls.Add($btnBlock)

$btnAll = New-Object System.Windows.Forms.Button
$btnAll.Text = "Set gold for ALL characters"
$btnAll.Location = New-Object System.Drawing.Point(630, 430); $btnAll.Size = New-Object System.Drawing.Size(200, 26)
$btnAll.Add_Click({ Do-SetGoldAll })
$form.Controls.Add($btnAll)

# --- log
$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Multiline = $true
$txtLog.ScrollBars = 'Vertical'
$txtLog.ReadOnly = $true
$txtLog.Location = New-Object System.Drawing.Point(10, 466)
$txtLog.Size = New-Object System.Drawing.Size(900, 140)
$form.Controls.Add($txtLog)

Log "RZ-GM Tool v1.0 ready."
Log "1) Press Connect   2) Search a name   3) Tick the backup box   4) Use the buttons"
Log "Changes apply when the character logs in. Use the in-game board for live self-grants."

[void]$form.ShowDialog()
